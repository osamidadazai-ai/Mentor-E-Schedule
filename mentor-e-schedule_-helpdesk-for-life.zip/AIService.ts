import { GoogleGenAI, Type } from "@google/genai";

export interface AIContext {
  userProfile?: {
    name: string;
    email: string;
    role: string;
    purpose: string;
    primaryGoal: string;
    eloScore: number;
    level: string;
  } | null;
  tasks?: any[];
  deadlines?: any[];
  habits?: any[];
  reminders?: any[];
  reflections?: any[];
  calendar?: any[];
  recentSuggestions?: string[];
  history?: any[];
  memorySettings?: {
    rememberGoals?: boolean;
    rememberProjects?: boolean;
    rememberDiscussions?: boolean;
    rememberStyle?: boolean;
  };
}

let aiClient: GoogleGenAI | null = null;

export function getGenAIClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      throw new Error("GEMINI_API_KEY environment variable is required and must be configured.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

/**
 * Wraps a promise with a timeout.
 */
export function withTimeout<T>(promise: Promise<T>, timeoutMs: number = 30000): Promise<T> {
  return Promise.race([
    promise,
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error("Strategic transmission timed out due to latency constraints.")), timeoutMs)
    )
  ]);
}

/**
 * System instruction context builder.
 */
export function buildContextPrompt(context: AIContext): string {
  if (!context) return "";
  
  const parts: string[] = [];
  parts.push("=== CENTRALIZED USER & WORKSPACE INTELLIGENCE CONTEXT ===");
  
  if (context.userProfile) {
    const p = context.userProfile;
    parts.push(`[User Profile]
- Name: ${p.name || "User"}
- Professional Role/Identity: ${p.role || "Professional"}
- Career/Life Purpose: ${p.purpose || "Focus and productivity"}
- Primary Goal: ${p.primaryGoal || "Excellence"}
- ELO Score (Focus Momentum): ${p.eloScore || 100} (${p.level || "Starter"})`);
  }
  
  if (context.tasks && context.tasks.length > 0) {
    const activeTasks = context.tasks.filter((t: any) => !t.completed);
    const completedTasks = context.tasks.filter((t: any) => t.completed);
    parts.push(`[Task Board Status]
- Active/Incomplete Tasks (${activeTasks.length}):
${activeTasks.map((t: any) => `  * [${t.priority || "ROOK"}] "${t.title}" (Estimated: ${t.durationMinutes || "unspecified"}m, Start: ${t.startTime || "unspecified"}${t.dueDate ? `, Due: ${t.dueDate}` : ""})`).join("\n")}
- Recently Completed Tasks (${completedTasks.length}):
${completedTasks.slice(0, 5).map((t: any) => `  * "${t.title}" (Completed)`).join("\n")}`);
  }

  if (context.deadlines && context.deadlines.length > 0) {
    parts.push(`[Upcoming Deadlines]
${context.deadlines.map((d: any) => `  * Task: "${d.title}" due on ${d.dueDate} (Priority: ${d.priority})`).join("\n")}`);
  }

  if (context.habits && context.habits.length > 0) {
    parts.push(`[Active Habits & Streaks]
${context.habits.map((h: any) => `  * "${h.title}" (Current Streak: ${h.streakDays} days)`).join("\n")}`);
  }

  if (context.reflections && context.reflections.length > 0) {
    parts.push(`[Strategic Reflection & Blunder History]
${context.reflections.slice(0, 3).map((r: any) => `  * Failed task: "${r.taskTitle}" | Blocker: ${r.blocker} | Recommended Action: ${r.suggestedAction}`).join("\n")}`);
  }

  if (context.calendar && context.calendar.length > 0) {
    parts.push(`[Upcoming Calendar Events]
${context.calendar.map((c: any) => `  * Event: "${c.title}" on ${c.date} at ${c.time || "unspecified"}`).join("\n")}`);
  }

  if (context.recentSuggestions && context.recentSuggestions.length > 0) {
    parts.push(`[Recent System Recommendations]
${context.recentSuggestions.map((s: string) => `  * ${s}`).join("\n")}`);
  }

  if (context.memorySettings) {
    parts.push(`[Memory Settings]
- Remember Goals: ${context.memorySettings.rememberGoals ? "ENABLED" : "DISABLED"}
- Remember Projects: ${context.memorySettings.rememberProjects ? "ENABLED" : "DISABLED"}
- Remember Discussions: ${context.memorySettings.rememberDiscussions ? "ENABLED" : "DISABLED"}
- Remember Style: ${context.memorySettings.rememberStyle ? "ENABLED" : "DISABLED"}`);
  }

  parts.push("=== END OF CENTRALIZED CONTEXT ===");
  parts.push("IMPORTANT DIRECTIVE: Ground your response entirely in the above real-time workspace and profile context. Adjust recommendations based on current ELO, upcoming deadlines, and task load. Never reference system tags, context structures, database properties, or technical variables in your response. Speak naturally and context-aware.");
  
  return parts.join("\n\n");
}

export interface AIServiceCallParams {
  prompt: string;
  systemInstruction?: string;
  context?: AIContext;
  responseMimeType?: string;
  responseSchema?: any;
  fallbackGenerator: () => any;
  modelName?: string;
  timeoutMs?: number;
}

/**
 * AIService: Central gateway to call Google Gemini.
 * Implements prompts construction, context injection, validation, retries, timeout, JSON parsing, logging, and robust offline fallbacks.
 */
export const AIService = {
  /**
   * Generates content using Google Gemini with robust failover mechanisms.
   */
  async generateContent(params: AIServiceCallParams): Promise<any> {
    const {
      prompt,
      systemInstruction = "You are a professional executive mentor.",
      context,
      responseMimeType,
      responseSchema,
      fallbackGenerator,
      modelName = "gemini-3.1-flash-lite",
      timeoutMs = 30000
    } = params;

    console.log(`[AIService] Launching Gemini request using model: ${modelName}`);
    
    // Inject centralized context if provided
    let finalPrompt = prompt;
    if (context) {
      const contextBlock = buildContextPrompt(context);
      finalPrompt = `${contextBlock}\n\n[USER ACTION PROMPT]:\n${prompt}`;
    }

    let attempts = 0;
    const maxAttempts = 2;
    let currentModel = modelName;

    while (attempts < maxAttempts) {
      attempts++;
      try {
        const client = getGenAIClient();
        console.log(`[AIService] Attempt ${attempts} using model: ${currentModel}`);
        
        const responsePromise = client.models.generateContent({
          model: currentModel,
          contents: finalPrompt,
          config: {
            systemInstruction,
            responseMimeType,
            responseSchema,
          }
        });

        const response = await withTimeout(responsePromise, timeoutMs);
        const responseText = response.text || "";

        if (!responseText) {
          throw new Error("Empty response received from Gemini.");
        }

        if (responseMimeType === "application/json") {
          try {
            const parsed = JSON.parse(responseText.trim());
            console.log(`[AIService] Request succeeded and parsed successfully.`);
            return parsed;
          } catch (jsonErr) {
            console.warn(`[AIService] Received invalid JSON. Trying to repair or re-attempt. Raw text: ${responseText}`);
            throw new Error("Invalid JSON structure returned by model.");
          }
        }

        console.log(`[AIService] Text request succeeded.`);
        return responseText;

      } catch (err: any) {
        console.warn(`[AIService] Attempt ${attempts} failed for model ${currentModel}: ${err.message}`);
        if (currentModel !== "gemini-3.1-flash-lite" && attempts < maxAttempts) {
          console.log(`[AIService] Falling back to low-latency model 'gemini-3.1-flash-lite' for the next attempt.`);
          currentModel = "gemini-3.1-flash-lite";
        } else if (attempts >= maxAttempts) {
          console.error(`[AIService] All attempts exhausted. Resorting to local offline fallback generator.`);
          return fallbackGenerator();
        }
        // Brief pause before retry
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }

    return fallbackGenerator();
  },

  /**
   * Generates a streaming content response for chat operations.
   */
  async generateContentStream(params: {
    prompt: string;
    systemInstruction: string;
    context?: AIContext;
    modelName?: string;
    onChunk: (chunkText: string) => void;
    onDone: () => void;
    onError: (err: Error) => void;
  }) {
    const {
      prompt,
      systemInstruction,
      context,
      modelName = "gemini-3.1-flash-lite",
      onChunk,
      onDone,
      onError
    } = params;

    console.log(`[AIService] Starting streaming execution...`);

    let finalPrompt = prompt;
    if (context) {
      const contextBlock = buildContextPrompt(context);
      finalPrompt = `${contextBlock}\n\n[USER CHAT MESSAGE]:\n${prompt}`;
    }

    let attempts = 0;
    const maxAttempts = 2;
    let currentModel = modelName;

    while (attempts < maxAttempts) {
      attempts++;
      try {
        const client = getGenAIClient();
        console.log(`[AIService] Streaming attempt ${attempts} using model: ${currentModel}`);
        const responseStream = await client.models.generateContentStream({
          model: currentModel,
          contents: finalPrompt,
          config: {
            systemInstruction,
          }
        });

        for await (const chunk of responseStream) {
          const text = chunk.text || "";
          if (text) {
            onChunk(text);
          }
        }
        onDone();
        return; // Success, exit stream loop

      } catch (err: any) {
        console.warn(`[AIService] Streaming attempt ${attempts} failed for model ${currentModel}:`, err);
        if (currentModel !== "gemini-3.1-flash-lite" && attempts < maxAttempts) {
          console.log(`[AIService] Retrying stream with low-latency fallback 'gemini-3.1-flash-lite'`);
          currentModel = "gemini-3.1-flash-lite";
          continue;
        }
        console.error(`[AIService] Streaming failed permanently after ${attempts} attempts:`, err);
        onError(err);
        return;
      }
    }
  }
};
