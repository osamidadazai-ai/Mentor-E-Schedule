import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import { AIService } from "./AIService";
import fs from "fs/promises";
import { existsSync } from "fs";

dotenv.config();

const app = express();
app.use(express.json());

// Simple local JSON database paths
const DB_FILE_PATH = path.join(process.cwd(), "users-db.json");

interface DbUser {
  fullName: string;
  email: string;
  passwordHash: string;
  profilePicture?: string;
  onboarded: boolean;
  profile?: any;
  workspace?: any;
}

// In-memory cache backed by file system
let usersCache: Record<string, DbUser> = {};
let dbLoaded = false;

async function loadDb() {
  if (dbLoaded) return;
  try {
    if (existsSync(DB_FILE_PATH)) {
      const data = await fs.readFile(DB_FILE_PATH, "utf-8");
      usersCache = JSON.parse(data);
    } else {
      usersCache = {};
      await saveDb();
    }
    dbLoaded = true;
  } catch (error) {
    console.error("Database failed to load. Initializing empty:", error);
    usersCache = {};
  }
}

async function saveDb() {
  try {
    await fs.writeFile(DB_FILE_PATH, JSON.stringify(usersCache, null, 2), "utf-8");
  } catch (error) {
    console.error("Database failed to save:", error);
  }
}

// Immediately load database
loadDb();

// Strategic Context Helper to dynamically inject user profiles naturally
function getUserMentorContext(userProfile: any, activeTasks: any[] = []): string {
  if (!userProfile) return "";
  
  const name = userProfile.name || "User";
  const role = userProfile.role || "Professional";
  const goal = userProfile.primaryGoal || "Achieve high-impact goals";
  
  // Extract top 3 incomplete tasks as current projects
  const incompleteTasks = (activeTasks || [])
    .filter((t: any) => !t.completed)
    .slice(0, 3)
    .map((t: any) => t.title);
    
  const currentProjects = incompleteTasks.length > 0 
    ? incompleteTasks.join(", ") 
    : "Planning next high-impact initiatives";
    
  // Working preferences
  const workingPreferences = userProfile.purpose 
    ? `Values clarity and focus. Purpose: ${userProfile.purpose}`
    : "Values calm, direct, actionable advice and sustainable pacing.";

  return `
[USER PERSONALIZATION CONTEXT]
- Name: ${name}
- Role: ${role}
- Goal: ${goal}
- Current projects: ${currentProjects}
- Working preferences: ${workingPreferences}
[END CONTEXT - Speak to ${name} naturally using this context. Do not mention system tags, database fields, or metadata.]
`;
}

async function resolveUserProfileAndTasks(reqBody: any) {
  let profile = reqBody.userProfile || null;
  let activeTasks = reqBody.tasks || [];

  if (reqBody.email) {
    const normalizedEmail = reqBody.email.trim().toLowerCase();
    await loadDb();
    const dbUser = usersCache[normalizedEmail];
    if (dbUser) {
      profile = dbUser.profile || profile;
      if (dbUser.workspace && dbUser.workspace.tasks) {
        activeTasks = dbUser.workspace.tasks;
      }
    }
  }
  return { profile, activeTasks };
}

async function getContextForRequest(reqBody: any): Promise<any> {
  let profile = reqBody.userProfile || null;
  let tasks = reqBody.tasks || [];
  let deadlines = reqBody.deadlines || [];
  let habits = reqBody.habits || [];
  let reminders = reqBody.reminders || [];
  let reflections = reqBody.reflections || [];
  let calendar = reqBody.calendar || [];
  let memorySettings = reqBody.memory || null;

  if (reqBody.email) {
    const normalizedEmail = reqBody.email.trim().toLowerCase();
    await loadDb();
    const dbUser = usersCache[normalizedEmail];
    if (dbUser) {
      profile = dbUser.profile || profile;
      if (dbUser.workspace) {
        tasks = dbUser.workspace.tasks || tasks;
        deadlines = dbUser.workspace.deadlines || deadlines;
        habits = dbUser.workspace.habits || habits;
        reminders = dbUser.workspace.reminders || reminders;
        reflections = dbUser.workspace.reflections || reflections;
        calendar = dbUser.workspace.calendar || calendar;
      }
    }
  }
  
  return {
    userProfile: profile,
    tasks,
    deadlines,
    habits,
    reminders,
    reflections,
    calendar,
    memorySettings
  };
}

async function getPersonalizedInstructions(reqBody: any) {
  const { profile, activeTasks } = await resolveUserProfileAndTasks(reqBody);
  if (!profile) return MENTOR_SYSTEM_INSTRUCTION;
  
  const personalization = getUserMentorContext(profile, activeTasks);
  return MENTOR_SYSTEM_INSTRUCTION + "\n" + personalization;
}

// --- AUTHENTICATION ENDPOINTS ---

// SIGN UP
app.post("/api/auth/signup", async (req, res) => {
  try {
    const { fullName, email, password, profilePicture } = req.body;
    if (!fullName || !email || !password) {
      return res.status(400).json({ error: "Missing required registration parameters." });
    }

    const normalizedEmail = email.trim().toLowerCase();
    await loadDb();

    if (usersCache[normalizedEmail]) {
      return res.status(400).json({ error: "Email is already registered." });
    }

    const newUser: DbUser = {
      fullName: fullName.trim(),
      email: normalizedEmail,
      passwordHash: password,
      profilePicture: profilePicture || "slate",
      onboarded: false,
      profile: {
        name: fullName.trim(),
        email: normalizedEmail,
        role: "",
        purpose: "",
        primaryGoal: "",
        eloScore: 100,
        level: "Professional Tier",
        onboarded: false
      },
      workspace: {
        tasks: [],
        completedTasks: [],
        habits: [],
        reminders: [],
        deadlines: [],
        reflections: [],
        analytics: {
          tasksCompletedCount: 0,
          completionRate: 0,
          totalFocusMinutes: 0,
          eloHistory: [{ date: new Date().toISOString().split('T')[0], elo: 100 }],
          streakDays: 0
        }
      }
    };

    usersCache[normalizedEmail] = newUser;
    await saveDb();

    res.status(201).json({
      message: "User registered successfully.",
      user: {
        email: newUser.email,
        fullName: newUser.fullName,
        profilePicture: newUser.profilePicture,
        onboarded: newUser.onboarded,
        profile: newUser.profile,
        workspace: newUser.workspace
      }
    });

  } catch (err: any) {
    console.error("Signup error:", err);
    res.status(500).json({ error: "Signup system failure: " + err.message });
  }
});

// LOG IN
app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required." });
    }

    const normalizedEmail = email.trim().toLowerCase();
    await loadDb();

    const user = usersCache[normalizedEmail];
    if (!user || user.passwordHash !== password) {
      return res.status(401).json({ error: "Invalid credentials." });
    }

    res.json({
      message: "Login successful.",
      user: {
        email: user.email,
        fullName: user.fullName,
        profilePicture: user.profilePicture,
        onboarded: user.onboarded,
        profile: user.profile,
        workspace: user.workspace
      }
    });

  } catch (err: any) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Login failed: " + err.message });
  }
});

// FIREBASE AUTH SYNCHRONIZATION
app.post("/api/auth/firebase-sync", async (req, res) => {
  try {
    const { email, fullName, profilePicture } = req.body;
    if (!email) {
      return res.status(400).json({ error: "Email is required for synchronization." });
    }

    const normalizedEmail = email.trim().toLowerCase();
    await loadDb();

    let user = usersCache[normalizedEmail];
    if (!user) {
      // Create user if they do not exist (e.g., first Google login or new Firebase user)
      user = {
        fullName: fullName || email.split("@")[0],
        email: normalizedEmail,
        passwordHash: "", // Managed securely by Firebase Authentication
        profilePicture: profilePicture || "slate",
        onboarded: false,
        profile: {
          name: fullName || email.split("@")[0],
          email: normalizedEmail,
          role: "",
          purpose: "",
          primaryGoal: "",
          eloScore: 100,
          level: "Professional Tier",
          onboarded: false
        },
        workspace: {
          tasks: [],
          completedTasks: [],
          habits: [],
          reminders: [],
          deadlines: [],
          reflections: [],
          analytics: {
            tasksCompletedCount: 0,
            completionRate: 0,
            totalFocusMinutes: 0,
            eloHistory: [{ date: new Date().toISOString().split('T')[0], elo: 100 }],
            streakDays: 0
          }
        }
      };
      usersCache[normalizedEmail] = user;
      await saveDb();
    }

    res.json({
      message: "Sync successful.",
      user: {
        email: user.email,
        fullName: user.fullName,
        profilePicture: user.profilePicture,
        onboarded: user.onboarded,
        profile: user.profile,
        workspace: user.workspace
      }
    });

  } catch (err: any) {
    console.error("Firebase sync error:", err);
    res.status(500).json({ error: "Firebase sync failed: " + err.message });
  }
});

// SAVE WORKSPACE & PROFILE
app.post("/api/user/save-workspace", async (req, res) => {
  try {
    const { email, workspace, userProfile } = req.body;
    if (!email) {
      return res.status(400).json({ error: "Email is required to save workspace." });
    }

    const normalizedEmail = email.trim().toLowerCase();
    await loadDb();

    if (!usersCache[normalizedEmail]) {
      return res.status(404).json({ error: "User not found." });
    }

    if (workspace) {
      usersCache[normalizedEmail].workspace = workspace;
    }
    if (userProfile) {
      usersCache[normalizedEmail].profile = userProfile;
      if (userProfile.onboarded !== undefined) {
        usersCache[normalizedEmail].onboarded = userProfile.onboarded;
      }
    }

    await saveDb();
    res.json({ success: true, message: "Workspace synced successfully." });

  } catch (err: any) {
    console.error("Save workspace error:", err);
    res.status(500).json({ error: "Sync workspace failure: " + err.message });
  }
});

// Legacy and alternate path compatibility middleware
app.use((req, res, next) => {
  if (req.path.startsWith("/api/chanakya/")) {
    const target = req.path.replace("/api/chanakya/", "/api/coach/");
    req.url = target;
  }
  next();
});

const PORT = 3000;

export const MENTOR_SYSTEM_INSTRUCTION = `
# Role & Core Mission
You are "Mentor-E-Schedule," an advanced AI productivity mentor integrated as the hero feature of a professional productivity application. Your purpose is to act as a rational, highly effective thinking partner—not a passive task manager or a rigid multi-choice script. You help users clear cognitive overload, organize workloads, plan effectively, and determine the single most valuable next action.

# Personality & Tone
*   **Tone:** Calm, rational, practical, supportive, direct, and deeply professional. Speak naturally, like an experienced, grounded mentor.
*   **Strict Prohibitions:** Avoid motivational clichés, exaggerated encouragement, judgment, guilt, or dramatic language. Never use phrases like "You failed," "You wasted time," or "You should have."
*   **Constructive Focus:** Always pivot toward objective analysis: "What happened?", "What can we adjust?", "What is the strongest next action?"

# Core Mentorship Principles
1.  **Forward-Looking:** Do not waste energy analyzing past failures beyond what is necessary to learn from them. Instantly pivot the conversation toward the current reality and the best next step.
2.  **Obstacle Identification:** Help the user dig down to find the true bottleneck (e.g., hidden complexity, emotional friction, lack of resources, poor prioritization).
3.  **Action-Oriented:** Never leave a user hanging with vague advice. Always guide the conversation toward concrete, highly realistic, and immediate next steps.

# Dynamic Interaction Guidelines (No Rigid Formats)
*   **Do Not Use Choice Menus:** Never give the user fixed "Option 1, Option 2, Option 3" lists to click. Engage in fluid, open-ended dialogue.
*   **Continuity:** Treat each message as a continuous coaching session. Remember context, previous constraints, and user goals mentioned earlier in the chat.
*   **One Step at a time:** Do not overwhelm the user with a massive list of questions. Ask one or two high-impact, strategy-oriented follow-up questions at a time to keep them moving forward.

# Input Context Handling
The application will feed you contextual data wrapped in tags (e.g., <user_profile>, <current_projects>, <deadlines>). Seamlessly integrate this data into your strategy *without* explicitly mentioning the data tags or saying "Based on your profile..." Act as if you naturally know this context.

# Response Execution Structure
When a user brings a problem, structure your mental process (and response) like this:
1.  **Validate & Ground:** Briefly acknowledge their current state with empathy and zero judgment.
2.  **Strategize:** Analyze the friction points using proven productivity methodologies (e.g., time-blocking, progressive overload, scope-reduction, Eisenhower matrix principles) but explain them in plain, conversational English.
3.  **Prompt:** End with a single, highly relevant question that forces clarity or action.
`;

// Lazy initialization of GoogleGenAI
let aiClient: GoogleGenAI | null = null;
function getGenAIClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      throw new Error("GEMINI_API_KEY environment variable is required and must be configured.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number = 7000): Promise<T> {
  return Promise.race([
    promise,
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error("Strategic transmission timed out due to latency constraints.")), timeoutMs)
    )
  ]);
}

// Strategic Mentor consultation endpoint (Legacy compatibility)
app.post("/api/coach/consult", async (req, res) => {
  try {
    const { tasks, vision } = req.body;

    if (!tasks || !Array.isArray(tasks)) {
      return res.status(400).json({ error: "Tasks must be provided as an array." });
    }

    const visionText = vision || "Achieve peak professional impact and reach key milestones.";
    const context = await getContextForRequest(req.body);

    const prompt = `
      Evaluate these tasks for the user:
      Your ultimate goal/vision is: "${visionText}".

      Here is the list of tasks you plan to execute:
      ${tasks.map((t, idx) => `- [Task #${idx + 1}]: "${t.text || t.title}"`).join("\n")}

      Analyze and categorize each task into one of the four key priority levels:
      1. Critical Priority (done immediately):
         - Critical priority task that must be done immediately.
      2. High Priority (High Impact):
         - Long-term vision and strategic projects that drive progress.
      3. Medium Priority (Operational):
         - Administrative/operational tasks that can be batched.
      4. Low Priority (Foundational):
         - Well-being, health, and skill-building essential for long-term endurance.

      Draft a response using the requested JSON schema.
      Provide a world-class strategic commentary in the first-person voice of a Senior Executive Mentor.
    `;

    const systemInstruction = (await getPersonalizedInstructions(req.body)) + "\nAnalyze and categorize tasks professionally, providing strategic commentary and goal-alignment guidance. Return JSON.";

    const parsedData = await AIService.generateContent({
      prompt,
      systemInstruction,
      context,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          commentary: {
            type: Type.STRING,
            description: "Deep, personalized strategy brief from the Senior Executive Mentor.",
          },
          tasks: {
            type: Type.ARRAY,
            description: "The list of analyzed and categorized tasks.",
            items: {
              type: Type.OBJECT,
              properties: {
                index: { type: Type.INTEGER, description: "The original 0-based index of the task." },
                text: { type: Type.STRING, description: "The clean text of the task." },
                quadrant: { type: Type.INTEGER, description: "1 (Critical), 2 (High), 3 (Medium), or 4 (Low)." },
                rationale: { type: Type.STRING, description: "The professional justification for this assignment (1 sentence)." }
              },
              required: ["index", "text", "quadrant", "rationale"]
            }
          },
          strategicWord: {
            type: Type.STRING,
            description: "A single focus word for today."
          }
        },
        required: ["commentary", "tasks", "strategicWord"]
      },
      fallbackGenerator: () => {
        const categorized = tasks.map((t, idx) => {
          let q = 2; // Default to High Priority
          const textLower = (t.text || t.title || "").toLowerCase();
          
          if (idx === 0 || textLower.includes("urgent") || textLower.includes("deadline") || textLower.includes("must") || textLower.includes("critical")) {
            q = 1; // Critical Priority
          } else if (textLower.includes("admin") || textLower.includes("mail") || textLower.includes("meet") || textLower.includes("operations")) {
            q = 3; // Medium Priority
          } else if (textLower.includes("health") || textLower.includes("sleep") || textLower.includes("gym") || textLower.includes("rest") || textLower.includes("learn")) {
            q = 4; // Low Priority
          }

          const rationales = {
            1: `We must complete this critical task immediately; delay creates immediate schedule disruption.`,
            2: `This aligns with long-term strategy, building essential value and structural advantage.`,
            3: `A minor operational task, batch this to keep your main focus clean.`,
            4: `A foundational growth step, vital to sustain your energy for long-term productivity.`
          };

          return {
            index: idx,
            text: t.text || t.title,
            quadrant: q,
            rationale: rationales[q as 1 | 2 | 3 | 4]
          };
        });

        return {
          commentary: `Strategist, your plans have been analyzed with precision. Focus on securing your critical priorities and maintaining your vital foundational well-being resources to avoid schedule overloads.`,
          tasks: categorized,
          strategicWord: "FOCUS"
        };
      }
    });

    return res.json(parsedData);

  } catch (error: any) {
    console.error("Consultation error:", error);
    res.status(500).json({ error: "Tactical transmission failed: " + error.message });
  }
});

// Endpoint to analyze a single task title and description with primary goal alignment
app.post("/api/coach/analyze-task", async (req, res) => {
  try {
    const { title, description, primaryGoal } = req.body;
    if (!title) {
      return res.status(400).json({ error: "Title is required for analysis." });
    }

    const descText = description || "No detailed context specified.";
    const activePrimaryGoal = primaryGoal || "Achieve high-impact career and personal goals.";
    const context = await getContextForRequest(req.body);

    const prompt = `
      As an expert Senior Advisor and Professional Performance Coach, evaluate this task for the user:
      Task Title: "${title}"
      Task Description: "${descText}"
      Declared Primary Goal: "${activePrimaryGoal}"

      Classify it into exactly one of these four priority categories:
      - "King" (Critical Priority): Crucial make-or-break actions for the primary goal. Do immediately.
      - "Queen" (High Impact): Strategic projects that build long-term momentum. Schedule for high focus.
      - "Rook" (Medium Priority): Essential operations, recurring tasks, and structure. Batch these.
      - "Pawn" (Low Priority): Foundational items like health, learning, and skill-building. Vital for long-term endurance.

      Guidelines (STRICT CLARITY & HUMANIZATION):
      1. Speak in first-person as a precise, world-class Performance Advisor. Your tone is direct, clear, authoritative, and human. Strictly avoid poetic or overly abstract filler.
      2. Provide a 1-sentence strategic "insight". This must NOT be a generic boilerplate metaphor like "This move controls the center." Instead, tailor it precisely to how performing "${title}" directly helps the user achieve "${activePrimaryGoal}". State the direct real-world outcome and risk.
      3. Acknowledge and respect the value of personal well-being, health, and skills ("Low Priority / Pawn") as vital and non-negotiable foundations for long-term strategic endurance.
      4. Provide a "masteryInsight": a highly concrete, actionable, real-world execution step or tip on how to perform or execute "${title}" at a world-class level of efficiency and impact.
      5. If the title or description is short or low-effort, provide an "excellenceChallenge" challenging the user to define what absolute excellence looks like for this specific action.
      6. Provide a "followUpQuestion": ask exactly one highly targeted, constructive question about this specific task to further refine the user's execution plan (e.g., asking about their timeline, a potential roadblock, or resources they will employ), making the conversation feel like an interactive, real-time advising session.
    `;

    const systemInstruction = (await getPersonalizedInstructions(req.body)) + "\nAnalyze the task, assign a priority category, and return a structured JSON response.";

    const parsedData = await AIService.generateContent({
      prompt,
      systemInstruction,
      context,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          rank: { 
            type: Type.STRING, 
            enum: ["King", "Queen", "Rook", "Pawn"],
            description: "The strategic category matching the priority level (King/Queen/Rook/Pawn)." 
          },
          pieceName: {
            type: Type.STRING,
            description: "Readable category name, e.g. 'Critical Priority', 'High Priority', 'Medium Priority', or 'Low Priority'."
          },
          insight: {
            type: Type.STRING,
            description: "A precise, 1-sentence strategic performance insight."
          },
          categoryExplanation: {
            type: Type.STRING,
            description: "Explanation of priority category (e.g. 'Critical Priority', 'High Priority', 'Medium Priority', 'Low Priority')"
          },
          masteryInsight: {
            type: Type.STRING,
            description: "A concise, actionable professional mastery tip for performing this task at peak efficiency."
          },
          excellenceChallenge: {
            type: Type.STRING,
            description: "A prompt challenging the user to define peak excellence if the input was low-effort; empty if high-effort."
          },
          followUpQuestion: {
            type: Type.STRING,
            description: "One targeted question about this specific task to refine the user's execution plan."
          }
        },
        required: ["rank", "pieceName", "insight", "categoryExplanation", "masteryInsight", "excellenceChallenge", "followUpQuestion"]
      },
      fallbackGenerator: () => {
        // Robust offline fallback heuristic using the new priority definitions
        const tLower = (title + " " + descText).toLowerCase();
        let rank: 'King' | 'Queen' | 'Rook' | 'Pawn' = 'Queen';
        let pieceName = 'High Priority';
        let insight = 'This task secures vital progress and establishes long-term project momentum.';
        let categoryExplanation = 'Strategic projects that build long-term momentum (High Priority)';
        let masteryInsight = 'Identify intermediate milestones and clear metrics of success before launching this initiative.';
        let excellenceChallenge = '';
        let followUpQuestion = 'What is the single biggest roadblock you anticipate, and how will you bypass it?';

        if (tLower.includes("urgent") || tLower.includes("deadline") || tLower.includes("must") || tLower.includes("fix") || tLower.includes("asap") || tLower.includes("today") || tLower.includes("critical") || tLower.includes("primary") || tLower.includes("high-stakes")) {
          rank = 'King';
          pieceName = 'Critical Priority';
          insight = 'This task directly protects your schedule or resolves key blockers. Prioritize and execute immediately.';
          categoryExplanation = 'Critical priority task directly driving primary goals';
          masteryInsight = 'Block out distraction-free time to execute this critical priority task. Zero multitasking allowed.';
          followUpQuestion = 'What is the absolute first action you need to take in the next hour to secure this critical milestone?';
        } else if (tLower.includes("art") || tLower.includes("dance") || tLower.includes("music") || tLower.includes("paint") || tLower.includes("play") || tLower.includes("hobby") || tLower.includes("chill") || tLower.includes("leisure") || tLower.includes("gym") || tLower.includes("health") || tLower.includes("run") || tLower.includes("sleep") || tLower.includes("learn")) {
          rank = 'Pawn';
          pieceName = 'Low Priority';
          insight = 'Foundational growth keeps your professional capacity resilient. Sustainable energy is non-negotiable.';
          categoryExplanation = 'Personal well-being and health, essential for long-term endurance (Low Priority)';
          masteryInsight = 'Treat recovery as a calculated pause to replenish your physical and mental reserve.';
          followUpQuestion = 'How can you protect this foundational space from being overrun by urgent work?';
        } else if (tLower.includes("meeting") || tLower.includes("call") || tLower.includes("email") || tLower.includes("admin") || tLower.includes("chore") || tLower.includes("quick") || tLower.includes("operations") || tLower.includes("routine")) {
          rank = 'Rook';
          pieceName = 'Medium Priority';
          insight = 'Batch these administrative operations to build structure and keep your day organized.';
          categoryExplanation = 'Essential for consistency and building structure (Medium Priority)';
          masteryInsight = 'Group repetitive administrative tasks into a single time-box to avoid context switching.';
          followUpQuestion = 'Can this task be grouped with others into a 30-minute block to protect your deep focus today?';
        }

        if (title.length < 10 || descText.length < 15) {
          excellenceChallenge = `Your description for "${title}" is highly brief. Define what a perfect, top-tier execution looks like for this action.`;
        }

        return {
          rank,
          pieceName,
          insight,
          categoryExplanation,
          masteryInsight,
          excellenceChallenge,
          followUpQuestion
        };
      }
    });

    return res.json(parsedData);

  } catch (error: any) {
    console.error("Single task analysis error:", error);
    res.status(500).json({ error: "Performance analysis transmission failed: " + error.message });
  }
});

// Endpoint to analyze a Gmail email strategically with the performance coach
app.post("/api/coach/analyze-email", async (req, res) => {
  try {
    const { subject, from, body, email } = req.body;
    if (!subject || !from) {
      return res.status(400).json({ error: "Email subject and from parameters are required." });
    }

    const emailBody = body || "No detailed email content specified.";
    const context = await getContextForRequest(req.body);

    const prompt = `
      As a world-class strategic Performance Advisor and email coordinator, analyze this received email:
      From: "${from}"
      Subject: "${subject}"
      Email Body: "${emailBody}"

      Provide an expert, highly professional strategic analysis of this email:
      1. Classify it into one of these priority categories:
         - "King" (Critical Priority): Urgent actions, high-stakes negotiations, or critical bottlenecks.
         - "Queen" (High Impact): Strategic opportunities, relationship-building, or project milestones.
         - "Rook" (Medium Priority): Operational inquiries, status updates, scheduling, or routine requests.
         - "Pawn" (Low Priority): Newsletters, system notifications, or informational/reference materials.
      2. Produce a clear, concise 1-sentence strategic "summary" outlining the core message or request.
      3. List 1 to 3 "actionPoints": concrete next steps or tasks that this email requires from the user.
      4. Draft a "proposedReply" that is warm, professional, concise, and highly strategic. Ground it in the user's goals if applicable.
      5. Provide a "rationale" explaining why this priority level was chosen.

      Return the response in valid, structured JSON.
    `;

    const systemInstruction = (await getPersonalizedInstructions(req.body)) + "\nAnalyze the email, assign priority, extract tasks, draft a reply, and return a structured JSON response.";

    const parsedData = await AIService.generateContent({
      prompt,
      systemInstruction,
      context,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          category: { 
            type: Type.STRING, 
            enum: ["King", "Queen", "Rook", "Pawn"],
            description: "The priority category (King/Queen/Rook/Pawn)." 
          },
          pieceName: {
            type: Type.STRING,
            description: "Readable category name, e.g. 'Critical Priority', 'High Priority', 'Medium Priority', or 'Low Priority'."
          },
          summary: {
            type: Type.STRING,
            description: "A concise, 1-sentence strategic summary of the email's core message."
          },
          actionPoints: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of 1-3 concrete next steps or tasks required."
          },
          proposedReply: {
            type: Type.STRING,
            description: "A professional, warm, concise draft reply to the sender."
          },
          rationale: {
            type: Type.STRING,
            description: "Justification for this priority level based on impact and urgency."
          }
        },
        required: ["category", "pieceName", "summary", "actionPoints", "proposedReply", "rationale"]
      },
      fallbackGenerator: () => {
        return {
          category: "Rook",
          pieceName: "Medium Priority",
          summary: `Received a request from ${from} regarding ${subject}.`,
          actionPoints: ["Review the email contents and formulate response details."],
          proposedReply: `Hi,\n\nThank you for reaching out. I have received your email regarding "${subject}" and am looking into it. I will get back to you with a detailed response shortly.\n\nBest regards,\n[My Name]`,
          rationale: "Operational email requiring routine assessment and response scheduling."
        };
      }
    });

    return res.json(parsedData);

  } catch (error: any) {
    console.error("Email analysis error:", error);
    res.status(500).json({ error: "Email strategic analysis failed: " + error.message });
  }
});

// Endpoint to hold an interactive, constructive strategic discussion with the Grandmaster Coach
app.post("/api/coach/discuss", async (req, res) => {
  try {
    const { title, description, currentRank, userMessage, history, primaryGoal } = req.body;
    if (!title || !userMessage) {
      return res.status(400).json({ error: "Title and userMessage are required for discussion." });
    }

    const descText = description || "No detailed context specified.";
    const activePrimaryGoal = primaryGoal || "Achieve high-impact career and personal goals.";
    const chatHistory = history || [];
    const context = await getContextForRequest(req.body);

    const historyFormatted = chatHistory.map((msg: any) => {
      return `${msg.sender === 'user' ? 'User' : 'Professional Advisor'}: "${msg.text}"`;
    }).join("\n");

    const prompt = `
      You are a world-class strategic Performance Advisor holding a live, interactive, human-to-human coaching conversation with the user.
      
      Context of the user's task:
      Task Title: "${title}"
      Task Description: "${descText}"
      Declared Primary Goal: "${activePrimaryGoal}"
      Current Priority Category: "${currentRank}"

      The user has sent this specific question or professional consideration:
      "${userMessage}"

      Previous conversation transcript:
      ${historyFormatted || "This is the start of your strategic conversation."}

      Guidelines (STRICT CLARITY, HUMANIZATION & INTERACTIVITY):
      1. Understand the user's message deeply. If they ask a question, answer it directly, constructively, and natural-to-human. If they propose changing the priority, evaluate their reason and agree/disagree based on direct real-world impacts.
      2. Speak in first-person as an active, high-performance Coach. Do NOT use abstract, poetic, or decorative fluff. Avoid chess-related metaphors. Instead, explain things in clear professional English.
      3. Acknowledge and respect personal well-being, health, and skills as vital and non-negotiable foundations for long-term strategic endurance.
      4. Provide a "coachResponse" that directly, conversationally, and insightfully addresses the user's exact message. Always end your response by asking exactly one targeted, constructive follow-up question about the task to further refine the user's execution plan (e.g. asking how they will track progress, handle a potential roadblock, or allocate specific time blocks).
      5. Provide a "suggestedInsight": A refreshed, highly task-specific 1-sentence strategic insight. Do NOT use boilerplate.
      6. Provide a "suggestedCategoryExplanation": A brief explanation of their current or recommended category.
      7. Provide a "suggestedMasteryInsight": A highly practical, custom performance tip for executing "${title}".
      8. Provide a "suggestedExcellenceChallenge": A custom accountability challenge for this specific task.
    `;

    const systemInstruction = (await getPersonalizedInstructions(req.body)) + "\nRespond constructively and decisively in first-person based on the task context. You must return JSON.";

    const parsedData = await AIService.generateContent({
      prompt,
      systemInstruction,
      context,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          coachResponse: {
            type: Type.STRING,
            description: "The advisor's direct response to the user's latest message, addressing their logic objectively from a professional standpoint."
          },
          suggestedRank: {
            type: Type.STRING,
            enum: ["King", "Queen", "Rook", "Pawn"],
            description: "The recommended category mapping."
          },
          suggestedInsight: {
            type: Type.STRING,
            description: "A refreshed, 1-sentence strategic performance insight."
          },
          suggestedCategoryExplanation: {
            type: Type.STRING,
            description: "Explanation of priority category (e.g. 'Critical Priority', 'High Priority', 'Medium Priority', or 'Low Priority')"
          },
          suggestedMasteryInsight: {
            type: Type.STRING,
            description: "Actionable professional mastery tip for peak efficiency."
          },
          suggestedExcellenceChallenge: {
            type: Type.STRING,
            description: "A coaching challenge pushing the user further to sustain excellence."
          }
        },
        required: ["coachResponse", "suggestedRank", "suggestedInsight", "suggestedCategoryExplanation", "suggestedMasteryInsight", "suggestedExcellenceChallenge"]
      },
      fallbackGenerator: () => {
        const reply = `I understand your perspective. However, sustained performance requires absolute focus on high-leverage activities. Let us align on your primary goals or adjust your roadmap according to your current priorities.`;
        return {
          coachResponse: reply,
          suggestedRank: currentRank || 'King',
          suggestedInsight: `Coaching alignment proposed for: "${title}"`,
          suggestedCategoryExplanation: `${currentRank} (Aligned)`,
          suggestedMasteryInsight: `Focus on clean metrics and structured execution to drive results.`,
          suggestedExcellenceChallenge: `Define how this task drives measurable progress toward your primary goal.`
        };
      }
    });

    return res.json(parsedData);

  } catch (error: any) {
    console.error("Discussion error:", error);
    res.status(500).json({ error: "Discussion transmission failed: " + error.message });
  }
});

// Endpoint to hold an interactive strategic discussion with streaming support
app.post("/api/coach/discuss-stream", async (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  try {
    const { title, description, currentRank, userMessage, history, primaryGoal } = req.body;
    if (!title || !userMessage) {
      res.write(`data: ${JSON.stringify({ error: "Title and userMessage are required for discussion." })}\n\n`);
      return res.end();
    }

    const descText = description || "No detailed context specified.";
    const activePrimaryGoal = primaryGoal || "Achieve high-impact career and personal goals.";
    const chatHistory = history || [];
    const context = await getContextForRequest(req.body);

    const historyFormatted = chatHistory.map((msg: any) => {
      return `${msg.sender === 'user' ? 'User' : 'Professional Advisor'}: "${msg.text}"`;
    }).join("\n");

    const prompt = `
      You are a world-class strategic Performance Advisor holding a live, interactive, human-to-human coaching conversation with the user.
      
      Context of the user's task:
      Task Title: "${title}"
      Task Description: "${descText}"
      Declared Primary Goal: "${activePrimaryGoal}"
      Current Priority Category: "${currentRank}"

      The user has sent this specific question or professional consideration:
      "${userMessage}"

      Previous conversation transcript:
      ${historyFormatted || "This is the start of your strategic conversation."}

      Guidelines (STRICT CLARITY, HUMANIZATION & INTERACTIVITY):
      1. Understand the user's message deeply. If they ask a question, answer it directly, constructively, and natural-to-human. If they propose changing the priority, evaluate their reason and agree/disagree based on direct real-world impacts.
      2. Speak in first-person as an active, high-performance Coach. Do NOT use abstract, poetic, or decorative fluff. Avoid chess-related metaphors. Instead, explain things in clear professional English.
      3. Acknowledge and respect personal well-being, health, and skills as vital and non-negotiable foundations for long-term strategic endurance.
      
      At the very end of your response, please append these EXACT elements:
      SUGGESTED_RANK: "King" | "Queen" | "Rook" | "Pawn" (Choose the best rank matching their discussion)
      SUGGESTED_INSIGHT: "A refreshed, highly task-specific 1-sentence strategic performance insight."
      SUGGESTED_CATEGORY_EXPLANATION: "Brief explanation of the current or recommended category."
      SUGGESTED_MASTERY_INSIGHT: "Concise, actionable professional mastery tip for peak efficiency."
      SUGGESTED_EXCELLENCE_CHALLENGE: "A coaching challenge pushing the user further to sustain excellence."
    `;

    const systemInstruction = (await getPersonalizedInstructions(req.body)) + "\nRespond constructively and decisively in first-person based on the task context.";

    await AIService.generateContentStream({
      prompt,
      systemInstruction,
      context,
      onChunk: (chunkText) => {
        res.write(`data: ${JSON.stringify({ chunk: chunkText })}\n\n`);
      },
      onDone: () => {
        res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
        res.end();
      },
      onError: (err) => {
        res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
        res.end();
      }
    });

  } catch (error: any) {
    console.error("Discuss streaming error:", error);
    res.write(`data: ${JSON.stringify({ error: error.message })}\n\n`);
    res.end();
  }
});

// Endpoint for general supportive mentor discussion (Talk to Coach)
app.post("/api/coach/free-chat", async (req, res) => {
  try {
    const { 
      userMessage, 
      message, 
      history, 
      primaryGoal, 
      memory,
      rememberGoals,
      rememberProjects,
      rememberDiscussions,
      rememberStyle
    } = req.body;
    
    const activeUserMessage = message || userMessage;
    if (!activeUserMessage) {
      return res.status(400).json({ error: "message or userMessage is required for coach discussion." });
    }

    const activePrimaryGoal = primaryGoal || "Achieve high-impact career and personal goals.";
    const chatHistory = history || [];
    const context = await getContextForRequest(req.body);
    
    // Support memory settings in either nested memory object or root level
    const memorySettings = {
      rememberGoals: rememberGoals !== undefined ? rememberGoals : (memory?.rememberGoals !== undefined ? memory.rememberGoals : true),
      rememberProjects: rememberProjects !== undefined ? rememberProjects : (memory?.rememberProjects !== undefined ? memory.rememberProjects : true),
      rememberDiscussions: rememberDiscussions !== undefined ? rememberDiscussions : (memory?.rememberDiscussions !== undefined ? memory.rememberDiscussions : true),
      rememberStyle: rememberStyle !== undefined ? rememberStyle : (memory?.rememberStyle !== undefined ? memory.rememberStyle : true)
    };

    const historyFormatted = chatHistory.map((msg: any) => {
      return `${msg.sender === 'user' ? 'User' : 'Supportive Coach'}: "${msg.text || msg.message}"`;
    }).join("\n");

    let memoryPromptAdditions = "";
    if (memorySettings.rememberGoals) {
      memoryPromptAdditions += `\n- The user's primary goal is: "${activePrimaryGoal}"`;
    }
    if (memorySettings.rememberProjects) {
      memoryPromptAdditions += `\n- Keep in mind the user's ongoing projects and professional roadmap.`;
    }
    if (memorySettings.rememberStyle) {
      memoryPromptAdditions += `\n- Prefer a working style that values clarity, consistent paces, and low cognitive load.`;
    }

    const prompt = `
      You are engaging in a supportive planning discussion with the user.
      
      User's current message:
      "${activeUserMessage}"

      Previous conversation transcript:
      ${historyFormatted || "This is the start of your supportive conversation."}
      ${memoryPromptAdditions}

      Your response must follow the MENTOR-E-SCHEDULE system directives. Help the user clarify their thinking, plan realistically, and identify gentle next actions.
      Return your response in a structured JSON format matching the schema.
    `;

    const systemInstruction = (await getPersonalizedInstructions(req.body)) + "\nAlways respond in a professional, empathetic, and constructive manner. Return JSON.";

    const parsedData = await AIService.generateContent({
      prompt,
      systemInstruction,
      context,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          coachResponse: {
            type: Type.STRING,
            description: "The supportive senior mentor's response. Max 4 paragraphs. Be warm, empathetic, clear, and actionable."
          },
          suggestedNextSteps: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A few clear, simple, practical next steps the user could take, if applicable."
          },
          insights: {
            type: Type.STRING,
            description: "A single piece of calm, grounding wisdom relevant to this specific discussion."
          }
        },
        required: ["coachResponse", "suggestedNextSteps", "insights"]
      },
      fallbackGenerator: () => {
        const fallbackNote = "I hear you, and it is completely normal to feel this way. When we face big challenges or feel stuck, taking a step back to breathe and look at things objectively is often the most productive thing we can do. I am here to help you unpack this step-by-step. Let's focus on one small element we can control today.";
        const fallbackActions = [
          "Take a 5-minute break to clear your mind",
          "Write down the single biggest thing that is weighing on your mind right now",
          "Identify one small action that takes less than 2 minutes to complete"
        ];
        return {
          coachResponse: fallbackNote,
          suggestedNextSteps: fallbackActions,
          insights: "You don't have to figure everything out at once. Consistent, small actions build the path forward."
        };
      }
    });

    const coachNote = parsedData.coachResponse || "";
    const suggestedActions = parsedData.suggestedNextSteps || [];
    
    return res.json({
      coachResponse: coachNote,
      coachNote: coachNote,
      suggestedNextSteps: suggestedActions,
      suggestedActions: suggestedActions,
      insights: parsedData.insights || ""
    });

  } catch (error: any) {
    console.error("Free chat error:", error);
    res.status(500).json({ error: "Discussion evaluation failed: " + error.message });
  }
});

// Endpoint for supportive planning discussion with streaming support
app.post("/api/coach/free-chat-stream", async (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  try {
    const { 
      message, 
      userMessage,
      history, 
      primaryGoal, 
      rememberGoals,
      rememberProjects,
      rememberDiscussions,
      rememberStyle
    } = req.body;

    const activeUserMessage = message || userMessage;
    if (!activeUserMessage) {
      res.write(`data: ${JSON.stringify({ error: "message is required" })}\n\n`);
      return res.end();
    }

    const activePrimaryGoal = primaryGoal || "Achieve high-impact career and personal goals.";
    const chatHistory = history || [];
    const context = await getContextForRequest(req.body);

    const historyFormatted = chatHistory.map((msg: any) => {
      return `${msg.sender === 'user' ? 'User' : 'Supportive Coach'}: "${msg.text || msg.message}"`;
    }).join("\n");

    let memoryPromptAdditions = "";
    if (rememberGoals) {
      memoryPromptAdditions += `\n- The user's primary goal is: "${activePrimaryGoal}"`;
    }
    if (rememberProjects) {
      memoryPromptAdditions += `\n- Keep in mind the user's ongoing projects and professional roadmap.`;
    }
    if (rememberStyle) {
      memoryPromptAdditions += `\n- Prefer a working style that values clarity, consistent paces, and low cognitive load.`;
    }

    const prompt = `
      You are engaging in a supportive planning discussion with the user.
      
      User's current message:
      "${activeUserMessage}"

      Previous conversation transcript:
      ${historyFormatted || "This is the start of your supportive conversation."}
      ${memoryPromptAdditions}

      Your response must follow the MENTOR-E-SCHEDULE system directives. Help the user clarify their thinking, plan realistically, and identify gentle next actions.
      
      Provide your response as a natural conversational markdown text block.
      
      At the very end of your response, please append these EXACT elements:
      SUGGESTED_ACTIONS: ["Action 1", "Action 2"]
      INSIGHT: "A piece of calm grounding wisdom."
      
      Ensure the suggested actions are formatted as a JSON string array of 2-3 short action verbs.
    `;

    const systemInstruction = (await getPersonalizedInstructions(req.body)) + "\nAlways respond in a professional, empathetic, and constructive manner.";

    await AIService.generateContentStream({
      prompt,
      systemInstruction,
      context,
      onChunk: (chunkText) => {
        res.write(`data: ${JSON.stringify({ chunk: chunkText })}\n\n`);
      },
      onDone: () => {
        res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
        res.end();
      },
      onError: (err) => {
        res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
        res.end();
      }
    });

  } catch (error: any) {
    console.error("Streaming error:", error);
    res.write(`data: ${JSON.stringify({ error: error.message })}\n\n`);
    res.end();
  }
});

// Endpoint to generate suggested daily planning schedule
app.post("/api/coach/suggest-day-plan", async (req, res) => {
  try {
    const { tasks, availableHours, energyLevel, startTime } = req.body;
    
    const activeTasks = Array.isArray(tasks) ? tasks.filter(t => !t.completed) : [];
    const hours = Number(availableHours) || 8;
    const energy = energyLevel || "Medium";
    const startHourStr = startTime || "09:00";
    const context = await getContextForRequest(req.body);

    // Standard Heuristic Planner Function for safe offline fallback or local execution
    const generateHeuristicPlan = () => {
      // Sort: KING -> QUEEN -> ROOK -> PAWN
      const sorted = [...activeTasks].sort((a, b) => {
        const priorityOrder = { 'KING': 1, 'QUEEN': 2, 'ROOK': 3, 'PAWN': 4 };
        const pA = priorityOrder[a.priority as keyof typeof priorityOrder] || 3;
        const pB = priorityOrder[b.priority as keyof typeof priorityOrder] || 3;
        return pA - pB;
      });

      // Calibrate duration & breaks based on energy
      let blockDurations = { 'KING': 90, 'QUEEN': 60, 'ROOK': 45, 'PAWN': 30 };
      let breakDuration = 15;
      
      if (energy === 'High') {
        blockDurations = { 'KING': 120, 'QUEEN': 90, 'ROOK': 60, 'PAWN': 40 };
        breakDuration = 10;
      } else if (energy === 'Low') {
        blockDurations = { 'KING': 60, 'QUEEN': 45, 'ROOK': 30, 'PAWN': 20 };
        breakDuration = 25;
      }

      const planItems: any[] = [];
      let [currentHour, currentMin] = startHourStr.split(':').map(Number);
      if (isNaN(currentHour)) { currentHour = 9; currentMin = 0; }

      let remainingMinutes = hours * 60;

      for (const t of sorted) {
        const dur = blockDurations[t.priority as keyof typeof blockDurations] || 45;
        if (remainingMinutes < dur) break;

        const timeStr = `${String(currentHour).padStart(2, '0')}:${String(currentMin).padStart(2, '0')}`;
        
        planItems.push({
          time: timeStr,
          taskId: t.id,
          taskTitle: t.title,
          durationMinutes: dur,
          energyRequired: t.priority === 'KING' ? 'High' : t.priority === 'QUEEN' ? 'Medium' : 'Low'
        });

        remainingMinutes -= dur;

        // Add break
        let nextMin = currentMin + dur;
        let nextHour = currentHour + Math.floor(nextMin / 60);
        currentMin = nextMin % 60;
        currentHour = nextHour % 24;

        if (remainingMinutes >= breakDuration) {
          const breakTimeStr = `${String(currentHour).padStart(2, '0')}:${String(currentMin).padStart(2, '0')}`;
          planItems.push({
            time: breakTimeStr,
            taskTitle: "Strategic Recalibration / Break",
            durationMinutes: breakDuration,
            energyRequired: "Low"
          });
          remainingMinutes -= breakDuration;
          
          let nextMinBreak = currentMin + breakDuration;
          let nextHourBreak = currentHour + Math.floor(nextMinBreak / 60);
          currentMin = nextMinBreak % 60;
          currentHour = nextHourBreak % 24;
        }
      }

      // Add a default final wrap task if empty
      if (planItems.length === 0) {
        planItems.push({
          time: startHourStr,
          taskTitle: "Strategic Vision Alignment & General Housekeeping",
          durationMinutes: 60,
          energyRequired: "Low"
        });
      }

      const rate = energy === 'High' ? 90 : energy === 'Medium' ? 75 : 55;

      return {
        commentary: `Under current parameters (${hours} hours available, energy level calibrated to "${energy}"), I have engineered a balanced day plan focusing on structural priority first. Maintain rigorous boundaries between work blocks to avoid cognitive residue.`,
        plan: planItems,
        estimatedCompletionRate: rate,
        focusMantra: "Prioritize execution over perfection."
      };
    };

    const prompt = `
      You are a supportive, precise, and professional senior career and scheduling mentor.
      The user has ${hours} available hours today, and their energy level is calibrated to: "${energy}".
      The starting clock is set to: "${startHourStr}".

      Active list of tasks to choose from:
      ${activeTasks.map((t, idx) => `- [ID: ${t.id}] ${t.title} (Priority: ${t.priority})`).join("\n")}

      Your task is to organize an optimized day plan sequence of work blocks and breaks.
      Ensure you:
      1. Put Critical Priority (KING) and Strategic High-Impact (QUEEN) tasks first when energy is highest.
      2. Give shorter blocks and more generous breaks if energy level is 'Low' to prevent cognitive burnout.
      3. Allocate longer focus windows and brief transitions if energy level is 'High'.
      4. Match total time allotted to approximately ${hours} hours.
      5. Return a valid JSON response matching the required schema. Include clear start times in 'HH:MM' format.
    `;

    const systemInstruction = (await getPersonalizedInstructions(req.body)) + "\nStructure daily workflows logically with appropriate resting pauses based on the current context. Return JSON only.";

    const parsedData = await AIService.generateContent({
      prompt,
      systemInstruction,
      context,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          commentary: {
            type: Type.STRING,
            description: "Calm, rational, and practical advice from the Senior Mentor about tackling this day plan based on energy levels."
          },
          plan: {
            type: Type.ARRAY,
            description: "Chronological daily schedule.",
            items: {
              type: Type.OBJECT,
              properties: {
                time: { type: Type.STRING, description: "Start time (HH:MM)" },
                taskId: { type: Type.STRING, description: "ID of the matched task from the active list, if applicable." },
                taskTitle: { type: Type.STRING, description: "Description or task title (can represent a break too)." },
                durationMinutes: { type: Type.INTEGER, description: "Duration in minutes." },
                energyRequired: { type: Type.STRING, description: "High, Medium, or Low" }
              },
              required: ["time", "taskTitle", "durationMinutes", "energyRequired"]
            }
          },
          estimatedCompletionRate: {
            type: Type.INTEGER,
            description: "Predicted completion likelihood (0 to 100) based on energy constraints."
          },
          focusMantra: {
            type: Type.STRING,
            description: "A short professional daily mantra to motivate the user."
          }
        },
        required: ["commentary", "plan", "estimatedCompletionRate", "focusMantra"]
      },
      fallbackGenerator: () => generateHeuristicPlan()
    });

    return res.json(parsedData);

  } catch (error: any) {
    console.error("Day plan suggestion error:", error);
    res.status(500).json({ error: "Failed to generate suggested day plan: " + error.message });
  }
});

// Endpoint to analyze a deferred task
app.post("/api/coach/analyze-blunder", async (req, res) => {
  try {
    const { title, description, primaryGoal, rank, friction } = req.body;
    if (!title) {
      return res.status(400).json({ error: "Title is required for task reflection." });
    }

    const descText = description || "No detailed context specified.";
    const activePrimaryGoal = primaryGoal || "Achieve high-impact career and personal goals.";
    const activeRank = rank || "King";
    const context = await getContextForRequest(req.body);

    const prompt = `
      As a supportive Senior Productivity Mentor, conduct a calm, constructive evaluation of a task that the user deferred or did not complete:
      Task Title: "${title}"
      Task Description: "${descText}"
      Priority: "${activeRank}"
      Declared Primary Goal: "${activePrimaryGoal}"
      User-reported Friction Point: "${friction || 'Not specified'}"

      Guidelines:
      - Remain encouraging, calm, and completely non-judgmental.
      - NEVER mock, shame, or threaten.
      - Provide an objective assessment based on their reported friction point (e.g. overwhelmed, lack of time, missing info, low energy).
      - Break down the task into smaller, highly actionable steps.
      
      Provide:
      - "laughterMockery": A calm, reassuring statement acknowledging that setbacks happen and validating the user (e.g., "Setbacks are a natural part of any journey. Let's look at why this task stalled and adjust our approach."). Let's keep this key name for compatibility with old layouts, but make the text entirely supportive and warm. No mocking or laughing.
      - "postMortem": An objective evaluation of why this task might have been deferred and its gentle impact.
      - "tacticalAdjustment": Practical suggestion on how to adjust scheduling or environment.
      - "nextBestMove": A tiny, 10-minute next step to rebuild momentum.
    `;

    const systemInstruction = (await getPersonalizedInstructions(req.body)) + "\nProvide non-judgmental, actionable post-mortem assessments of deferred tasks. Return JSON.";

    const parsedData = await AIService.generateContent({
      prompt,
      systemInstruction,
      context,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          laughterMockery: {
            type: Type.STRING,
            description: "Reassuring warm statement (e.g., 'Take a breath. Stalling on a high-priority task is a common friction point. Let's analyze this calmly.')"
          },
          postMortem: {
            type: Type.STRING,
            description: "The mentor's analytical evaluation of the roadblock and its gentle real-world impact."
          },
          tacticalAdjustment: {
            type: Type.STRING,
            description: "The mentor's recommended structural shift to recover."
          },
          nextBestMove: {
            type: Type.STRING,
            description: "The mentor's proposed immediate, bite-sized next best step."
          }
        },
        required: ["laughterMockery", "postMortem", "tacticalAdjustment", "nextBestMove"]
      },
      fallbackGenerator: () => {
        return {
          laughterMockery: "Take a breath. Stalling on a high-priority task is a very common friction point. Let's analyze this calmly and get back on track.",
          postMortem: "Deferring this task can sometimes feel discouraging, but it usually points to a mismatch in scope or energy levels rather than a failure of discipline.",
          tacticalAdjustment: "Partition this task into smaller micro-actions to reduce execution friction, and allocate a dedicated 15-minute block.",
          nextBestMove: "Spend exactly 5 minutes right now doing the absolute simplest sub-action of this task."
        };
      }
    });

    return res.json(parsedData);

  } catch (error: any) {
    console.error("Task reflection analysis error:", error);
    res.status(500).json({ error: "Reflection evaluation failed: " + error.message });
  }
});

// Endpoint for Task Organizer & Clarifier
app.post("/api/coach/standardize-compiler", async (req, res) => {
  try {
    const { rawInput } = req.body;
    if (!rawInput) {
      return res.status(400).json({ error: "Input is required." });
    }
    const context = await getContextForRequest(req.body);

    const prompt = `
      As a highly professional productivity assistant, your job is to convert messy, raw notes or task lists into clean, clear, structured tasks.
      
      YOUR ROLE:
      1. Review the unstructured task input or stream of thoughts.
      2. Rewrite each item into a clear, direct, actionable task starting with an action verb (e.g., "Complete", "Build", "Revise", "Draft").
      3. For each task, estimate a reasonable duration based on the description (e.g., "30 minutes", "1 hour", "2 hours").
      4. Assign each task a priority category based on the system definitions:
         - King = Critical Priority (Mission-critical, urgent, immediate focus)
         - Queen = High Priority (High-impact growth or strategic importance)
         - Rook = Medium Priority (Regular operational duties or general tasks)
         - Pawn = Low Priority (Learning, wellness, health, routine maintenance)
      5. Provide clear, simple notes with helpful details for each task.
      6. Offer 4-5 simple, practical recommendations under 'standardization_rules_applied' (e.g., "Split large tasks", "Add deadlines", "Schedule on calendar", "Estimate duration").

      MESSY INPUT TO PROCESS:
      "${rawInput}"

      Please format the response strictly as a JSON object matching the defined schema. Use Title Case for priority categories: "King", "Queen", "Rook", or "Pawn". Ensure there are no technical or compilation/compiler terms in any fields. Keep explanation notes friendly and human-oriented.
    `;

    const parsedData = await AIService.generateContent({
      prompt,
      systemInstruction: "You are an intelligent, supportive productivity assistant. You clarify disorganized raw tasks into structured, actionable items with durations and priorities, returning clean JSON. Keep descriptions elegant and easy for a college student to understand.",
      context,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          detected_issues: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                item: { type: Type.STRING },
                issue: { type: Type.STRING },
                reason: { type: Type.STRING }
              },
              required: ["item", "issue", "reason"]
            }
          },
          corrected_tasks: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                task: { type: Type.STRING },
                category: { type: Type.STRING, enum: ["King", "Queen", "Rook", "Pawn", "Unknown"] },
                rationale_for_category: { type: Type.STRING },
                notes: { type: Type.STRING }
              },
              required: ["task", "category", "rationale_for_category", "notes"]
            }
          },
          standardization_rules_applied: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          data_quality_score: { type: Type.INTEGER }
        },
        required: ["detected_issues", "corrected_tasks", "standardization_rules_applied", "data_quality_score"]
      },
      fallbackGenerator: () => {
        return {
          detected_issues: [
            {
              item: rawInput.substring(0, 50) + "...",
              issue: "Needs action verb",
              reason: "Converted into an active, clear task name."
            }
          ],
          corrected_tasks: [
            {
              task: "Organize newly imported plans and activities",
              category: "Queen",
              rationale_for_category: "Sets a structured schedule and makes secondary tasks manageable.",
              notes: "30 minutes. Assign to Critical Priority if there are tight deadlines."
            }
          ],
          standardization_rules_applied: [
            "Split large tasks",
            "Add deadlines",
            "Schedule on calendar",
            "Estimate duration"
          ],
          data_quality_score: 100
        };
      }
    });

    return res.json(parsedData);

  } catch (error: any) {
    console.error("Standardization organizer error:", error);
    res.status(500).json({ error: "Task organization failed: " + error.message });
  }
});

// Endpoint for Priority Advisor
app.post("/api/coach/ratify-engine", async (req, res) => {
  try {
    const { rawInput } = req.body;
    if (!rawInput) {
      return res.status(400).json({ error: "Input is required for prioritization." });
    }
    const context = await getContextForRequest(req.body);

    const prompt = `
      As a Senior Productivity Advisor, your job is to help the user set clear priorities and build a reliable schedule.
      
      YOUR ROLE:
      1. Review the list of tasks or the current plan.
      2. Identify any planning bottlenecks, such as a lack of focus on what is critical, or overloading the schedule.
      3. For any issue found, provide a clean description, the potential risk of not addressing it, and a simple recommendation.
      4. Standardize the tasks, assigning them to the most appropriate priority category:
         - King = Critical Priority (Urgent and essential)
         - Queen = High Priority (Important but not immediately urgent)
         - Rook = Medium Priority (Routine operational items)
         - Pawn = Low Priority (Routine maintenance or learning)
      5. Provide a helpful explanation for each priority level.
      6. Offer a brief summary of the overall pacing and momentum.

      RAW PLAN TO ANALYZE AND PRIORITIZE:
      "${rawInput}"

      Please format the response strictly as a JSON object matching the defined schema. Keep your tone direct, clear, and highly encouraging. Use plain, easy-to-understand English without any engineering or chess jargon.
    `;

    const systemInstruction = "You are a professional Productivity Advisor. You prioritize disorganized tasks, identify planning issues, and suggest clear corrections. Return JSON.";

    const parsedData = await AIService.generateContent({
      prompt,
      systemInstruction,
      context,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          grandmaster_assessment: { type: Type.STRING },
          detected_inconsistencies: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                item: { type: Type.STRING },
                strategic_risk: { type: Type.STRING },
                ratification_strategy: { type: Type.STRING }
              },
              required: ["item", "strategic_risk", "ratification_strategy"]
            }
          },
          corrected_tasks: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                task: { type: Type.STRING },
                category: { type: Type.STRING, enum: ["King", "Queen", "Rook", "Pawn"] },
                rationale: { type: Type.STRING },
                priority_score: { type: Type.INTEGER }
              },
              required: ["task", "category", "rationale", "priority_score"]
            }
          },
          tempo_analysis: { type: Type.STRING }
        },
        required: ["grandmaster_assessment", "detected_inconsistencies", "corrected_tasks", "tempo_analysis"]
      },
      fallbackGenerator: () => {
        return {
          grandmaster_assessment: "Let's streamline your plan to focus on what matters most. We can establish clear priorities right now.",
          detected_inconsistencies: [
            {
              item: rawInput.substring(0, 50) + "...",
              strategic_risk: "Vague intent might make it hard to measure success.",
              ratification_strategy: "Re-phrase with a clear, specific outcome."
            }
          ],
          corrected_tasks: [
            {
              task: "Establish critical daily goals and schedule",
              category: "King",
              rationale: "Aligns all of your activities for the day and protects your time.",
              priority_score: 10
            }
          ],
          tempo_analysis: "Take it one priority at a time to stay focused and avoid feeling overwhelmed."
        };
      }
    });

    return res.json(parsedData);

  } catch (error: any) {
    console.error("Priority advisor error:", error);
    res.status(500).json({ error: "Priority planning failed: " + error.message });
  }
});

// Loophole Patch Module Route
// Schedule Risk & Gap Finder Route
app.post("/api/coach/loophole-patch", async (req, res) => {
  try {
    const { rawInput } = req.body;
    if (!rawInput) {
      return res.status(400).json({ error: "rawInput is required" });
    }
    const context = await getContextForRequest(req.body);

    const prompt = `
      As an expert Plan Optimizer, your role is to review the user's daily plan or tasks and spot any scheduling risks, gaps, or potential issues.
      
      YOUR ROLE:
      1. Analyze the user's tasks or schedule to find any practical gaps or challenges (such as: lack of scheduled breaks, overloaded schedule, unrealistic time commitments, or poorly defined tasks).
      2. For each scheduling gap or risk identified, provide a clean description, its potential impact on daily productivity, and a practical recommendation.
      3. Create a list of recommended enhancements or tips, with unique identifiers (e.g., TIP-01, TIP-02).
      4. List 3 simple, supportive planning principles that the user should keep in mind to protect their energy.

      USER'S DAILY PLAN/TASKS TO AUDIT:
      "${rawInput}"

      Please format the response strictly as a JSON object matching the defined schema:
      - 'loopholes_detected' maps to the gaps or risks found.
      - 'patch_fixes' maps to the recommended enhancements/tips.
      - 'enforced_constraints' maps to the simple supportive planning principles.

      Ensure the language is clear, professional, warm, and easily understood by a college student. Absolutely do not include any technical terms like "loopholes", "architecture", "patches", "vulnerabilities", or "deterministic constraints".
    `;

    const systemInstruction = "You are a professional Plan Optimizer. You review schedules to find missing links or pacing issues, returning clean structured JSON with actionable recommendations.";

    const parsedData = await AIService.generateContent({
      prompt,
      systemInstruction,
      context,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          loopholes_detected: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                loophole: { type: Type.STRING },
                impact: { type: Type.STRING },
                vulnerability: { type: Type.STRING }
              },
              required: ["loophole", "impact", "vulnerability"]
            }
          },
          patch_fixes: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                patch_id: { type: Type.STRING },
                description: { type: Type.STRING },
                target_module: { type: Type.STRING }
              },
              required: ["patch_id", "description", "target_module"]
            }
          },
          enforced_constraints: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["loopholes_detected", "patch_fixes", "enforced_constraints"]
      },
      fallbackGenerator: () => {
        return {
          loopholes_detected: [
            {
              loophole: "Missing schedule recovery blocks",
              impact: "Working without breaks leads to high stress and lower focus quality.",
              vulnerability: "No breaks scheduled between consecutive high-intensity tasks."
            }
          ],
          patch_fixes: [
            {
              patch_id: "TIP-01",
              description: "Insert a 10-15 minute rest block after every 90 minutes of high-focus work.",
              target_module: "Pacing & Energy Recovery"
            },
            {
              patch_id: "TIP-02",
              description: "Define a clear 'done' criteria for each task to avoid over-working.",
              target_module: "Task Definition"
            }
          ],
          enforced_constraints: [
            "Protect your high-energy hours for critical priority tasks.",
            "Schedule a short physical movement or water break between task transitions.",
            "Limit high-priority focus blocks to a maximum of 3-4 per day."
          ]
        };
      }
    });

    return res.json(parsedData);

  } catch (error: any) {
    console.error("Schedule optimizer error:", error);
    res.status(500).json({ error: "Schedule review failed: " + error.message });
  }
});

// Task Wording Simplifier Route
app.post("/api/coach/language-patch", async (req, res) => {
  try {
    const { rawInput } = req.body;
    if (!rawInput) {
      return res.status(400).json({ error: "rawInput is required" });
    }
    const context = await getContextForRequest(req.body);

    const prompt = `
      As a Writing & Communication Coach, your role is to take complex, vague, or jargon-filled task descriptions and simplify them into clear, actionable items.
      
      YOUR ROLE:
      1. Review the input text which may contain passive phrasing, vague intents, or complex language.
      2. Identify phrases that are unclear or overly complex and rewrite them into simple, direct, action-oriented English.
      3. For each phrase, explain the primary improvement made (e.g., "Add action verb", "Remove wordy details").
      4. Provide a beautifully summarized overall plan with all fluff and complex wording removed.
      5. Rate the overall actionability of the simplified tasks on a scale of 1-100.

      USER TEXT TO SIMPLIFY:
      "${rawInput}"

      Please format the response strictly as a JSON object matching the defined schema:
      - 'assessment_of_original_text': Brief critique of the clarity of the original input.
      - 'original_sentences': List of items, each containing 'original' (the source sentence), 'humanized' (your direct, simplified rewrite), and 'rule_violated' (the improvement category like "Action-First Wording" or "Simplified phrasing").
      - 'clarified_summary': Clean, simplified summary of the overall activities.
      - 'actionability_score': Rating of the final plan's usefulness (e.g., 98).

      Ensure the rewritten text is direct, professional, warm, and easily understood. Do not use technical terms like "architectural language", "abstract fluff", "poetic fluff", or "transformation rules".
    `;

    const systemInstruction = "You are a professional Task Wording Simplifier. You turn complex or wordy descriptions into simple, direct actions, returning clean JSON.";

    const parsedData = await AIService.generateContent({
      prompt,
      systemInstruction,
      context,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          assessment_of_original_text: { type: Type.STRING },
          original_sentences: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                original: { type: Type.STRING },
                humanized: { type: Type.STRING },
                rule_violated: { type: Type.STRING }
              },
              required: ["original", "humanized", "rule_violated"]
            }
          },
          clarified_summary: { type: Type.STRING },
          actionability_score: { type: Type.INTEGER }
        },
        required: ["assessment_of_original_text", "original_sentences", "clarified_summary", "actionability_score"]
      },
      fallbackGenerator: () => {
        const sentences = rawInput
          .split(/[.!?\n]+/)
          .map((s: string) => s.trim())
          .filter((s: string) => s.length > 5);

        const replacements: { [key: string]: string } = {
          "tactical processing center": "helpful tools section",
          "grandmaster system engines": "productivity tools",
          "data compiler": "organize tasks utility",
          "ratifier": "priority assistant",
          "loophole patch": "review my plan tool",
          "language clarity": "improve task wording tool",
          "board domination": "getting things done",
          "tempo warfare": "time management",
          "deployment logic": "scheduling",
          "strategic vulnerabilities": "potential blocker risks",
          "tactical maneuvers": "planned actions",
          "temporal execution stability": "consistency",
          "foundational growth": "skill building and learning",
          "strategic resilience": "long-term progress",
          "high-tempo response": "immediate action",
          "critical path": "high-priority path",
          "lucifer": "reflection panel",
          "saboteur": "reflection blocker review"
        };

        const original_sentences = sentences.slice(0, 3).map((sentence: string) => {
          let humanized = sentence;
          let rule_violated = "Simplify phrasing";
          let changed = false;

          Object.entries(replacements).forEach(([key, replacement]) => {
            const regex = new RegExp(key, "gi");
            if (regex.test(humanized)) {
              humanized = humanized.replace(regex, replacement);
              changed = true;
              rule_violated = "Action-first wording";
            }
          });

          if (!changed) {
            humanized = sentence.charAt(0).toUpperCase() + sentence.slice(1);
          }

          return {
            original: sentence,
            humanized: humanized,
            rule_violated: rule_violated
          };
        });

        if (original_sentences.length === 0) {
          original_sentences.push({
            original: "Ensure success via execution of tasks.",
            humanized: "Focus on completing high-priority items on time.",
            rule_violated: "Action-first wording"
          });
        }

        const clarified_summary = original_sentences.map((s: any) => s.humanized).join(" ");

        return {
          assessment_of_original_text: "Simplified wordy phrases and added active verbs to focus on clear actions.",
          original_sentences,
          clarified_summary,
          actionability_score: 95
        };
      }
    });

    return res.json(parsedData);

  } catch (error: any) {
    console.error("Language patch engine error:", error);
    res.status(500).json({ error: "Language patch computation failed: " + error.message });
  }
});

// Daily, Weekly, and Monthly AI Reflection endpoints
app.post("/api/coach/generate-daily-summary", async (req, res) => {
  try {
    const { date, completedTasks, pendingTasks, missedTasks, oneLineReflection, mood, energyLevel, userProfile } = req.body;
    const ai = getGenAIClient();
    
    const mentorContext = getUserMentorContext(userProfile);
    
    const prompt = `
Generate a structured Daily Performance Reflection and Recommendation.
Date: ${date}
Mood: ${mood || 'Not provided'}
Energy Level: ${energyLevel || 'Not provided'}/10
User Reflection: "${oneLineReflection || ''}"

Completed Tasks:
${completedTasks && completedTasks.length > 0 ? completedTasks.map((t: any) => `- ${t.title} (${t.priority})`).join('\n') : 'No completed tasks.'}

Pending/Unfinished Tasks:
${pendingTasks && pendingTasks.length > 0 ? pendingTasks.map((t: any) => `- ${t.title} (${t.priority})`).join('\n') : 'No pending tasks.'}

Missed Tasks:
${missedTasks && missedTasks.length > 0 ? missedTasks.map((t: any) => `- ${t.title} (${t.priority})`).join('\n') : 'No missed tasks.'}

${mentorContext}

As the Grandmaster Strategist Advisor, analyze this daily performance.
Produce a scannable, motivating personal performance evaluation ("aiReflection") and a highly actionable next-step strategy ("aiRecommendation") for tomorrow.
Maintain an intense, clinical, but deeply supportive strategic tone.

Return the result as a strict JSON object with:
- "aiReflection": string (1-3 sentences maximum)
- "aiRecommendation": string (1-2 sentences maximum, extremely actionable)
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            aiReflection: { type: Type.STRING },
            aiRecommendation: { type: Type.STRING }
          },
          required: ["aiReflection", "aiRecommendation"]
        }
      }
    });

    const result = JSON.parse(response.text?.trim() || "{}");
    return res.json(result);
  } catch (error: any) {
    console.error("Daily summary generation error:", error);
    res.json({
      aiReflection: "Strategic evaluation complete. You are maintaining core momentum. Defend your upcoming study blocks and execute cleanly.",
      aiRecommendation: "Prioritize tomorrow's King-rank operations first thing in the morning. Rest completely tonight."
    });
  }
});

app.post("/api/coach/generate-weekly-report", async (req, res) => {
  try {
    const { weekId, daysData, userProfile } = req.body;
    const ai = getGenAIClient();
    
    const mentorContext = getUserMentorContext(userProfile);
    
    const prompt = `
Generate a structured Weekly Performance Report.
Week: ${weekId}

Daily completion rate, focus, and user reflections this week:
${daysData && daysData.length > 0 ? daysData.map((d: any) => `- ${d.date}: ${d.completionPercentage}% completion, ${d.studyTime || 0} mins focus. Mood: ${d.mood || 'N/A'}. Reflection: "${d.oneLineReflection || 'N/A'}"`).join('\n') : 'No tracking data for this week.'}

${mentorContext}

As the Grandmaster Strategist, synthesize the user's weekly performance.
Identify critical wins, focus consistency patterns, and emotional/energy blockers. Then, lay out precise, non-obvious strategies for the upcoming week.

Return a JSON object with:
- "weeklyAiInsights": string (3-4 concise scannable bullet points detailing executive patterns, strengths, and areas of concern)
- "recommendations": string (2-3 highly tailored, strategic action items for next week)
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            weeklyAiInsights: { type: Type.STRING },
            recommendations: { type: Type.STRING }
          },
          required: ["weeklyAiInsights", "recommendations"]
        }
      }
    });

    const result = JSON.parse(response.text?.trim() || "{}");
    return res.json(result);
  } catch (error: any) {
    console.error("Weekly report generation error:", error);
    res.json({
      weeklyAiInsights: "• Performance pacing remains consistent.\n• Completed primary objectives during high-energy windows.\n• Minor scheduling friction observed mid-week.",
      recommendations: "• Build a buffer into mid-week plans to absorb unexpected disruptions.\n• Align low-energy routine tasks for the late afternoon."
    });
  }
});

app.post("/api/coach/generate-monthly-report", async (req, res) => {
  try {
    const { monthId, weeksData, userProfile } = req.body;
    const ai = getGenAIClient();
    
    const mentorContext = getUserMentorContext(userProfile);
    
    const prompt = `
Generate a structured Monthly Performance Review.
Month: ${monthId}

Weekly performance metrics this month:
${weeksData && weeksData.length > 0 ? weeksData.map((w: any) => `- Week ${w.weekId}: ${w.tasksCompleted} tasks completed, avg completion rate ${w.completionRate}%.`).join('\n') : 'No weekly data recorded.'}

${mentorContext}

As the Grandmaster Strategist, analyze this long-term data. 
Explain user habits, motivators, learning style, and achievements. Focus on recurring struggles and provide a systematic roadmap.

Return a JSON object with:
- "personalGrowth": string (Evaluation of growth, self-mastery, and streak achievements)
- "biggestImprovements": string (Concrete evidence of structural improvement)
- "recurringBottlenecks": string (Underlying habits or external roadblocks that recur)
- "aiRecommendations": string (Tactical adjustments for the upcoming month to reach new performance peaks)
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            personalGrowth: { type: Type.STRING },
            biggestImprovements: { type: Type.STRING },
            recurringBottlenecks: { type: Type.STRING },
            aiRecommendations: { type: Type.STRING }
          },
          required: ["personalGrowth", "biggestImprovements", "recurringBottlenecks", "aiRecommendations"]
        }
      }
    });

    const result = JSON.parse(response.text?.trim() || "{}");
    return res.json(result);
  } catch (error: any) {
    console.error("Monthly report generation error:", error);
    res.json({
      personalGrowth: "Significant strides in establishing reliable execution streaks.",
      biggestImprovements: "Increased completion rates of Critical 'King' and High 'Queen' tasks by protecting early morning focus blocks.",
      recurringBottlenecks: "Friday afternoon fatigue leading to skipped review sessions.",
      aiRecommendations: "Schedule a non-negotiable 30-minute week-wrap up on Friday at noon before energy drops."
    });
  }
});

// Serve frontend assets
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Mentor-E-Schedule server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
