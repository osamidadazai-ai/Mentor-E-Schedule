# GPT PROMPT: SCHEDULE-E-SHATRANJ V3 ARCHITECTURE AUDIT & REFACTORING GUIDE

Copy and paste this entire prompt into ChatGPT to help you audit, debug, and implement the transition of **Schedule-E-Shatranj** to a professional, premium productivity platform.

---

```markdown
You are a Principal Software Architect, Senior UX Specialist, and Expert Full-Stack Developer specializing in React 18, TypeScript, Tailwind CSS, Express, and Google Gen AI SDK integrations.

I need your help to perform a comprehensive architectural audit and redesign of my application, **"Schedule-E-Shatranj"**, moving from a gamified "Chess Strategy Simulator" with hostile mocking elements to a professional, highly usable, offline-resilient productivity platform (resembling a blend of **Todoist + Google Calendar + Notion + Supportive AI Strategic Mentor**).

Below is the complete progress, current status core, architectural layout, identified loopholes, and our V3 product specifications. Review this data thoroughly to help me refactor and secure the application.

---

## 1. V3 PRODUCT REALIGNMENT & PHILOSOPHY

### Core Principle
* *"A grandmaster does not waste energy lamenting previous moves. The board position is the only reality. Identify the strongest next move."*
* **Target Experience**: Clean, supportive, high-utility planner. AI acts as an optional strategic mentor, not a nagging controller.
* **Tone**: Calm, rational, encouraging, and direct.
* **Strict Negative Constraints**: NO mocking, NO fear-based mechanics, NO autonomous task manipulation by AI. Completely remove the "Lucifer" Saboteur system.

### Chess Theme Rules (Deterministic Mapping)
The Chess ranks are ONLY labels and should remain subtle. Do not display confusing internal values (such as CENTER, MID, EDGE, TEMPO, BOARD POSITION) to the user. Use clear priority titles:
* **KING** (Priority Score 9–10, Tempo HIGH, Board Position CENTER) → **Priority: Critical**
* **QUEEN** (Priority Score 7–8, Tempo MEDIUM, Board Position CENTER) → **Priority: High Impact**
* **ROOK** (Priority Score 4–6, Tempo MEDIUM, Board Position MID) → **Priority: Important Maintenance**
* **PAWN** (Priority Score 1–3, Tempo LOW, Board Position EDGE) → **Priority: Small Growth Tasks**

---

## 2. THE CURRENT ARCHITECTURE & FILES

### File Tree
1. `package.json`: Contains React 18, Vite, Tailwind CSS, Express, and `@google/genai` (Vite dev proxy port: 3000).
2. `server.ts`: Full Express backend serving Vite client in dev, compiled standalone bundle (`dist/server.cjs`) in production. Features dynamic proxy router middleware to seamlessly route `/api/chanakya/*` paths to `/api/coach/*`.
3. `src/types.ts`: Defines interfaces for `Task`, `ChessRank` (King, Queen, Rook, Pawn), and engine types.
4. `src/App.tsx`: The primary entry/dashboard controller containing local state hooks for tasks and the main UI tabs.
5. `src/components/LayerPortal.tsx`: Guest & Google onboarding sign-in gates.
6. `src/components/LayerBoard.tsx`: Grouped chessboard layout displaying tasks under their respective priority ranks.
7. `src/components/LayerCouncil.tsx`: The optional panel for consultations with the strategic mentor.
8. `src/components/LayerEngines.tsx`: The previous heavy development engines (Compiler, Ratifier, Loophole Patch, Language Clarity).
9. `src/components/LayerSaboteur.tsx`: Aggressive procrastination monitor / Lucifer engine featuring hostile mockery (Must be completely removed or rewritten to ReflectionPanel).

### Backend Endpoints (`server.ts`)
* `/api/coach/consult`: General planning queries.
* `/api/coach/analyze-task`: Task breakdown/parsing.
* `/api/coach/discuss`: Interactive planning and chat context.
* `/api/coach/analyze-blunder`: Evaluates incomplete tasks.
* `/api/coach/standardize-compiler`: Compiles/standardizes text lists to task JSON.
* `/api/coach/ratify-engine`: Evaluates ELO and priority calculations.
* `/api/coach/loophole-patch`: Identifies productivity loopholes.
* `/api/coach/language-patch`: Re-phrases task titles to be clear and action-oriented.

---

## 3. IDENTIFIED LOOPHOLES & RISK DIRECTIVES

Please analyze the code for these loopholes and generate patches to resolve them:

### A. State Management & Thread Safety (CRITICAL)
* **Problem**: State transitions are handled raw inside `App.tsx` and across various individual modules. Multiple quick API responses (e.g., Compiler, Ratifier, or AI Recommendations) result in race conditions, state drift, and overwrites of offline `localStorage` tasks.
* **Fix**: Establish a centralized Zustand state store with transactional CRUD actions, strict TS models, and deterministic mutations.

### B. Procrastination & Mockery Backlash (HIGH)
* **Problem**: `LayerSaboteur.tsx` (Lucifer) relies on insults ("HA-HA-HA! You've completely sabotaged your board!") which violates user trust and increases friction.
* **Fix**: Replace `LayerSaboteur.tsx` entirely with a **ReflectionPanel** / **ReviewPanel**. It should act as an objective, non-emotional recovery tool asking constructive questions (e.g., "What was the main blocker?", "How can we make this task smaller?").

### C. Offline Fallback & API Resilience (HIGH)
* **Problem**: The application depends heavily on fetching from Gemini models. If the server is offline or Gemini times out, empty string returns cause JSON parsing failures, freezing the client.
* **Fix**: Ensure every AI interaction has a structured try-catch fallback utilizing robust, local deterministic parser functions.

### D. Component Monolith (MEDIUM)
* **Problem**: `App.tsx` and `LayerEngines.tsx` are monolithic blocks. This triggers redundant re-renders and degrades performance on responsive calendars and drag-and-drop lists.
* **Fix**: Restructure into a modular feature hierarchy (e.g., `src/features/tasks/`, `src/features/schedule/`, etc.).

---

## 4. CODE & REFACTORING PLAN SPECIFICATIONS

Please write the following code assets and guide me through the refactoring process:

### Task 1: Central Zustand State Store (`src/stores/useProductivityStore.ts`)
Provide a production-ready Zustand store supporting:
1. State definitions for `onboardingProfile` (Name, Age, Role, Goal), `tasks` (Task array), `userElo` (number), and `systemStatus` ("OPTIMAL" | "RISK").
2. Core CRUD actions for tasks:
   - `addTask` (applies the strict Chess Rank and Tempo priority mapping automatically).
   - `updateTaskStatus` (Pending, In Progress, Completed, Deferred). If a Critical (King) task is completed, increment ELO. If deferred/missed, decrement ELO.
   - `setProfile` (persisting Guest Mode and user goals).
3. Secure auto-synchronization and persistence using Zustand `persist` middleware targeting `localStorage` with error boundaries.

### Task 2: Refactoring `LayerSaboteur.tsx` to `ReflectionPanel.tsx`
Provide a complete component rewrite that:
1. Obtains the neglected task, presenting it objectively.
2. Offers a form with predefined friction questions: "What was the main friction?" (Options: Overwhelmed, Lack of Time, Missing Info, Low Energy).
3. Invokes the updated `/api/coach/analyze-blunder` (which must be calm, strategic, and practical).
4. Includes actionable buttons to:
   - **Divide & Conquer**: Decompose into 2 smaller, highly concrete actions.
   - **Reschedule**: Allocate a dedicated 15-minute slot in the local calendar.
   - **Delegate/Defer**: Gracefully mark as Deferred without ELO penalties.

### Task 3: The Refactored "Ask Coach" Experience (`src/components/CoachPanel.tsx`)
Create an elegant, optional Coach Panel component where:
1. The user talks to the mentor directly without automated popups interrupting their workflow.
2. Provides quick-trigger prompts: "How should I structure today?", "Help me simplify my Critical priority task", "Review my week".
3. Displays recommendations in a dedicated **Coach Note** container.
4. Includes a **Consent-First action executor**: If the coach suggests adding or rescheduling a task, display a card showing the suggested parameters alongside an "Apply Suggestion" button. The AI MUST NOT auto-mutate the state without the user clicking this.

### Task 4: Supportive Express API Middleware (`server.ts` updates)
Rewrite the backend endpoints to enforce the senior mentor tone. Example prompt payload templates for Gemini:
* **Current Position**: State of the user's plan.
* **Root Cause**: Objective friction analysis.
* **Next Best Move**: Directly actionable immediate step.
* **Execution Plan**: Minimal, distraction-free roadmap.

---

Let's begin. First, supply the complete, fully-typed Zustand state store, followed by the `ReflectionPanel` and `CoachPanel` component definitions.
```
