# UNIFIED MASTER PROMPT FOR CHATGPT & GEMINI: SCHEDULE-E-SHATRANJ V3 REFACTORING & REDESIGN

Copy and paste the entire prompt below into ChatGPT, Gemini, or any advanced LLM to completely brief them on the current scenario of the application, the exact architectural state, the identified loopholes, and the V3 UI/UX product realignment.

---

```markdown
You are a Principal Software Architect, Senior UX Researcher, and Expert Full-Stack Developer specializing in React 18, TypeScript, Tailwind CSS, Express, and Google Gen AI SDK integrations.

I need your help to perform a comprehensive architectural audit and execute a production-grade redesign of my application, **"Schedule-E-Shatranj"**. We are moving it from a gamified "Chess Strategy Simulator" with hostile/mocking elements to a highly professional, clean, offline-resilient daily planner (resembling a blend of **Todoist + Google Calendar + Notion + Supportive AI Strategic Mentor**).

Below is the complete scenario, codebase specifications, identified loopholes, and V3 realignment directives.

---

## 1. V3 PRODUCT REALIGNMENT PHILOSOPHY (CRITICAL)

### Core Principle
* *"A grandmaster does not waste energy lamenting previous moves. The board position is the only reality. Identify the strongest next move."*
* **The Daily Usability Test**: For every feature, recommendation, and screen, ask: *"Would a student realistically open this application every day to plan their work?"* If the answer is no, simplify or reject it.
* **Tone**: Calm, rational, encouraging, direct, and supportive.
* **Strict Negative Constraints**: NO mocking, NO "Lucifer" Saboteur engines, NO automated task mutation by AI, and NO fear-based mechanics.

### Chess Theme Rules (Deterministic Mapping)
The chess theme must remain subtle and act purely as lightweight category labels. Never display confusing internal concepts (such as `CENTER`, `MID`, `EDGE`, `TEMPO`, `BOARD_POSITION`, `LAYER_ORIGINS`). Use clear human-readable priority titles:
* **KING** (Priority Score 9–10, Tempo HIGH, Position CENTER) → **Priority: Critical**
* **QUEEN** (Priority Score 7–8, Tempo MEDIUM, Position CENTER) → **Priority: High Impact**
* **ROOK** (Priority Score 4–6, Tempo MEDIUM, Position MID) → **Priority: Important Maintenance**
* **PAWN** (Priority Score 1–3, Tempo LOW, Position EDGE) → **Priority: Small Growth Tasks**

### Component & Terminology Reframe
Rename heavy, cognitive-load-inducing developer terminology with plain, human labels:
* `LayerCouncil` → `CoachPanel` (Dedicated non-intrusive mentor chat)
* `LayerSaboteur` → `ReflectionPanel` (Objective recovery panel, no mockery)
* `LayerEngines` → `ProductivityTools` (Organize, suggest, review)
* `Compiler` → `Organize Tasks`
* `Ratifier` → `Priority Assistant`
* `Loophole Patch` → `Review My Plan`
* `Language Clarity` → `Improve Task Wording`
* `Strategic Risk` → `Status` (e.g., "Everything is on track" instead of "NO ACTIVE RISK")
* `Grandmaster Commentary` → `Coach Note` or `Coach Suggestion`

---

## 2. THE CURRENT ARCHITECTURE & FLOWS

### Codebase Components
1. `package.json`: Configured for React 18 with Vite, Tailwind CSS, Express backend, and `@google/genai` SDK. Dev server binds to host `0.0.0.0` on port `3000`.
2. `server.ts`: Express backend handling Vite middleware in development and serving compiled static outputs (`dist/`) in production. Houses the Google Gen AI integration pipelines and API proxy endpoints under `/api/coach/*`. Includes a dynamic path proxy router routing `/api/chanakya/*` safely to `/api/coach/*`.
3. `src/types.ts`: Holds primitive interfaces for `Task`, `ChessRank` (King, Queen, Rook, Pawn), and engine types.
4. `src/App.tsx`: Currently serves as the core dashboard controller managing local state hooks for onboarding, tasks, active tabs, and ELO metrics.
5. `src/components/LayerPortal.tsx`: Handles Guest Mode and Google login onboarding gates.
6. `src/components/LayerBoard.tsx`: Renders the chessboard grouped priorities view.
7. `src/components/LayerCouncil.tsx`: Dedicated workspace consultation chat.
8. `src/components/LayerEngines.tsx`: Houses the processing pipeline buttons (Compiler, Ratifier, Loophole Patch, Language Clarity).
9. `src/components/LayerSaboteur.tsx`: Aggressive procrastination monitor / Lucifer engine featuring hostile commentary (Must be completely removed/rewritten to a calm ReflectionPanel).

---

## 3. LOOPHOLES, SECURITY RISKS, & DIRECTIVES TO SOLVE

Please analyze our architecture and provide concrete solutions to these identified loopholes:

### A. State Management & Thread Safety (CRITICAL)
* **Problem**: State transitions are handled raw inside local React hooks across different components. Simultaneous API responses (e.g., compile task, calculate priority, update status) trigger race conditions and overwrite the client's `localStorage` tasks.
* **Fix**: Design a centralized, fully typed Zustand store (`src/stores/useProductivityStore.ts`) featuring transactional CRUD operations, deep JSON schema validation, and safe localStorage persistence with error boundaries.

### B. Procrastination Backlash (HIGH)
* **Problem**: The current `LayerSaboteur.tsx` (Lucifer) relies on high-friction hostile mockery, which destroys user trust and causes daily churn.
* **Fix**: Completely rewrite `LayerSaboteur.tsx` into a supportive **ReflectionPanel**. If a user misses/neglects a task, the system should ask supportive questions (e.g., "What was the main blocker? Lack of time, low energy, missing information?") and present direct, low-friction recovery actions:
  - **Divide & Conquer**: Break the task into 2 small sub-tasks.
  - **Allocate Time**: Block 15 minutes in the local calendar.
  - **Graceful Defer**: Shift the task to next week without ELO penalties.

### C. Offline Fallback & API Resilience (HIGH)
* **Problem**: If the Express backend fails or the Gemini model rate-limits or times out, the front-end breaks or freezes due to empty JSON parsing.
* **Fix**: Establish clear `try-catch` structures with static, local deterministic fallbacks for every tool. The user must be able to perform all core actions (adding tasks, scheduling, analytics) without an active internet connection.

### D. UX & Navigational Friction (MEDIUM)
* **Problem**: The landing screen is currently focused on the processing "Engines" and raw metrics, confusing new users.
* **Fix**: Reorganize the primary workspace to load a **Dashboard** as the main home view displaying: Today's Tasks, Upcoming Tasks, Local Calendar/Time Blocks, and a Completion Progress metric. Put all AI-assisted tools under a separate, clearly labeled "Productivity Tools" section.

---

## 4. WHAT I NEED YOU TO IMPLEMENT

Please supply step-by-step guidance and complete code files for:

### 1. Robust Zustand State Store (`src/stores/useProductivityStore.ts`)
Write the code for a fully-typed state store managing:
- `userProfile` (Name, Role, Goals, and onboarding status).
- `tasks` (CRUD actions with deterministic priority mappings).
- `userElo` (Increments on completing Critical tasks, decrements gracefully on missed ones).
- Local storage synchronization using Zustand `persist` middleware.

### 2. Supportive AI Coach Gateway Integration (`server.ts` Prompt Engineering)
Provide refactored system instructions for our Gemini API routes. Ensure the prompt constraints force Gemini to:
- Adopt the **Supportive Senior Mentor Persona** (calm, strategic, constructive).
- Return structured, strictly valid JSON matching the user's priority levels (Critical, High, Medium, Low).
- Never modify or write to task arrays directly; only provide recommended action JSONs for user consent.

### 3. "Ask Coach" Panel (`src/components/CoachPanel.tsx`)
Create a modern, non-intrusive chat sidebar or panel where:
- The user can ask for scheduling help, advice on procrastination, or task simplification.
- Includes a **Consent-First** visual block: If the mentor suggests a new task, show an "Apply Suggested Task" card allowing the user to explicitly add it with one click.

### 4. Reflection Recovery Interface (`src/components/ReflectionPanel.tsx`)
Provide the code for the replacement of the Saboteur/Lucifer panel. Build a beautiful, calming card-based component for tactical reviews and recovery plans.
```
