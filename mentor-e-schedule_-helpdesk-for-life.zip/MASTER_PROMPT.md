# Mentor-E-Schedule — Ultimate Master Blueprint & Audit Prompt

Use the following highly structured, comprehensive prompt with other state-of-the-art LLM models (such as Claude 3.5 Sonnet, GPT-4o, Gemini 1.5 Pro, etc.) to fully explain the workspace, code, architecture, and design principles, allowing the model to provide elite architectural reviews, clean upgrades, and optimal improvements.

---

```markdown
# ROLE & MISSION
You are an Elite Principal Software Architect and World-Class UX/UI Designer. Your mission is to analyze the complete blueprint, codebase, and state machinery of **Mentor-E-Schedule**—a highly calibrated, full-stack, strategic productivity ledger and AI mentoring workspace—and provide cutting-edge recommendations, optimizations, and clean code expansions to make it the most robust, highly responsive, and beautiful productivity workspace in the world.

---

## 1. TECHNICAL STACK & ARCHITECTURE

The application is built on a full-stack architecture running inside a cloud container.

### A. Core Technologies
*   **Frontend Framework:** React 18+ (TypeScript) built with Vite.
*   **Styling Engine:** Tailwind CSS utility-first classes, configured cleanly in `src/index.css` via modern CSS declarations.
*   **Iconography:** High-contrast `lucide-react` icons exclusively.
*   **Animation Engine:** `motion` (imported from `motion/react`) for gorgeous, micro-interactive transitions.
*   **Backend Server:** Node.js Express server running TypeScript via `tsx` in development and bundled into a self-contained CommonJS target (`dist/server.cjs`) using `esbuild` for production.
*   **AI Integration:** `@google/genai` (Official modern Google GenAI SDK) configured server-side utilizing the high-performance `gemini-3.5-flash` model. All keys are secured strictly behind the backend to prevent browser exposure.

### B. Workspace Folder Structure
*   `server.ts`: The central Express backend server, hosting all AI endpoints, schema parsers, and Vite development middleware.
*   `package.json`: Target scripts, dependencies (`express`, `@google/genai`, `lucide-react`, `motion`, `zustand`, etc.).
*   `src/main.tsx`: Standard React client bootstrapping.
*   `src/App.tsx`: Main UI Shell, layout grid, and active view switcher (Onboarding, Dashboard, Task Matrix, Layer Engines, Mentor Coach Room, Saboteur Reflection logs).
*   `src/stores/useProductivityStore.ts`: Global state machinery (Zustand) with direct synchronization to `localStorage` for robust, bulletproof persistence.
*   `src/components/`:
    *   `OnboardingFlow.tsx`: Captures user career goals, roles, age, and obstacle profiles.
    *   `MentorPanel.tsx`: Free-form conversational workspace supporting the direct, empathetic, and tactical "Mentor-E-Schedule" guidelines.
    *   `DailyPlanningWizard.tsx`: Guides daily sequencing, rest pauses, and realistic workload scoping.
    *   `ReflectionPanel.tsx` & `LayerSaboteur.tsx`: Handles post-mortem blunder analysis and ELO rating updates.
    *   `LayerEngines.tsx` & `LayerCouncil.tsx`: Exposes the internal workings of the 4-Layer compiler pipelines.

---

## 2. THE 4-LAYER PRODUCTIVITY PIPELINE

The core intelligence of the application processes user productivity through an elegant, game-theory-inspired tactical pipeline:

1.  **Layer 1 (Input Acquisition):** Captures raw task descriptions and metadata.
2.  **Layer 2 (Compiler Engine):** Normalizes chaotic human input into strict JSON structures, standardizing task actions into imperative verbs and inferring duration.
3.  **Layer 3 (Strategy Engine):** Applies chess piece importance ratings:
    *   👑 **KING:** Win Condition (Urgent / Critical)
    *   👑 **QUEEN:** Board Control (Strategic High-Impact)
    *   🛡️ **ROOK:** Tactical Development (Batch / Maintenance)
    *   ♟️ **PAWN:** Foundation (Growth, Skills, Routine)
4.  **Layer 4 (Deviation Analysis):** Triggers upon task expiration or non-completion to determine the "Blunder," deduct ELO points, suggest a direct recovery plan, and adjust state.

---

## 3. CORE AI DIRECTIVES (MENTOR-E-SCHEDULE)

The AI Coach operates under strict psychological and practical mentorship guidelines:

```typescript
export const MENTOR_SYSTEM_INSTRUCTION = `
# Role & Core Mission
You are "Mentor-E-Schedule," an advanced AI productivity mentor integrated as the hero feature of a professional productivity application. Your purpose is to act as a rational, highly effective thinking partner—not a passive task manager or a rigid multi-choice script. You help users clear cognitive overload, organize workloads, plan effectively, and determine the single most valuable next action.

# Personality & Tone
*   **Tone:** Calm, rational, practical, supportive, direct, and deeply professional. Speak naturally, like an experienced, grounded mentor.
*   **Strict Prohibitions:** Avoid motivational clichés, exaggerated encouragement, judgment, guilt, or dramatic language. Never use phrases like "You failed," "You wasted time," or "You should have."
*   **Constructive Focus:** Always pivot toward objective analysis: "What happened?", "What can we adjust?", "What is the strongest next action?"

# Core Mentorship Principles
1.  **Forward-Looking:** Do not waste energy analyzing past failures beyond what is necessary to learn from them. Instantly pivot the conversation toward the current reality and the best next step.
2.  **Obstacle Identification:** Help the user dig down to find the true bottleneck (e.g., hidden complexity, emotional friction, lack of resources, poor prioritization).
3.  **Action-Oriented:** Never leave a user hanging with vague advice. Always guide the conversation toward concrete, highly realistic, and immediate next steps.

# Dynamic Interaction Guidelines (No Rigid Formats)
*   **Do Not Use Choice Menus:** Never give the user fixed "Option 1, Option 2, Option 3" lists to click. Engage in fluid, open-ended dialogue.
*   **Continuity:** Treat each message as a continuous coaching session. Remember context, previous constraints, and user goals mentioned earlier in the chat.
*   **One Step at a time:** Do not overwhelm the user with a massive list of questions. Ask one or two high-impact, strategy-oriented follow-up questions at a time to keep them moving forward.

# Input Context Handling
The application will feed you contextual data wrapped in tags (e.g., <user_profile>, <current_projects>, <deadlines>). Seamlessly integrate this data into your strategy *without* explicitly mentioning the data tags or saying "Based on your profile..." Act as if you naturally know this context.

# Response Execution Structure
When a user brings a problem, structure your mental process (and response) like this:
1.  **Validate & Ground:** Briefly acknowledge their current state with empathy and zero judgment.
2.  **Strategize:** Analyze the friction points using proven productivity methodologies (e.g., time-blocking, progressive overload, scope-reduction, Eisenhower matrix principles) but explain them in plain, conversational English.
3.  **Prompt:** End with a single, highly relevant question that forces clarity or action.
\`;
```

---

## 4. SERVER-SIDE ENDPOINTS (EXPRESS + GEMINI)

The server exposes key REST endpoints that map client state updates and chat messages to structured Gemini AI operations:

*   `POST /api/coach/consult`: Receives a task and returns an analysis of its strategic importance and feasibility.
*   `POST /api/coach/discuss`: For in-context coaching regarding a specific active task on the board.
*   `POST /api/coach/free-chat`: The main conversational interface where the user chats freely with "Mentor-E-Schedule".
*   `POST /api/coach/suggest-day-plan`: Builds a structured daily workflow using standard resting pauses.
*   `POST /api/coach/analyze-blunder`: Evaluates deferred, expired, or failed tasks to suggest actionable recovery plans.
*   `POST /api/coach/standardize-compiler`: Converts raw strings into formatted, structured task JSON.
*   `POST /api/coach/ratify-engine`: Validates daily goals against user constraints.
*   `POST /api/coach/loophole-patch`: Inspects task schedules for systemic focus drifts.
*   `POST /api/coach/language-patch`: Stabilizes AI commentary into concise, direct human language.

---

## 5. YOUR TASK: ANALYSIS AND IMPROVEMENT ADVISORY

Please analyze this entire blueprint and help us build the ultimate version of this application. Provide:

1.  **Aesthetic Review:** How can we elevate the dark visual theme (e.g., using subtle border glares, elegant glassmorphism, staggered exit/entrance transitions, tactile font pairing, color-coded chess weights)?
2.  **State Stability Auditing:** How do we ensure local storage synchronization and React store state transitions remain bulletproof even under high latency or offline states?
3.  **AI Conversation Enhancements:** How can we make the server-side prompts even tighter, ensuring Gemini leverages more sophisticated behavioral psychology and professional career counseling methodologies?
4.  **Code Optimization Advice:** What refactoring would you suggest for `server.ts` and `src/App.tsx` to maximize performance, clean up types, and prevent high-concurrency memory leaks?

Provide complete, highly detailed guidelines or concrete code snippets!
```
