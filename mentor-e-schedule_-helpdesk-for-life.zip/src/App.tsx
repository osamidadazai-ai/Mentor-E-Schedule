import React, { useState, useEffect, useMemo } from 'react';
import { Task, ChessRank } from './types';
import { LayerPortal } from './components/LayerPortal';
import { LayerCouncil } from './components/LayerCouncil';
import { LayerBoard } from './components/LayerBoard';
import { LayerSaboteur } from './components/LayerSaboteur';
import { LayerEngines } from './components/LayerEngines';
import { Dashboard } from './components/Dashboard';
import { OnboardingFlow } from './components/OnboardingFlow';
import { LandingPage } from './components/LandingPage';
import { MentorPanel } from './components/MentorPanel';
import { AnalyticsPanel } from './components/AnalyticsPanel';
import { DailyReflectionSystem } from './components/DailyReflectionSystem';
import { LayerGmail } from './components/LayerGmail';
import { useProductivityStore } from './stores/useProductivityStore';
import { authService } from './services/authService';
import { useDebouncedEffect } from './hooks/useDebouncedEffect';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldCheck, Zap, RefreshCw, LayoutDashboard, Calendar, ListTodo, 
  BarChart, User, MessageSquare, Award, Sparkles, Plus, X, Trash2, 
  CheckCircle, ChevronLeft, ChevronRight, Clock, HelpCircle, Settings, LogOut, FileText,
  BookOpen, Mail
} from 'lucide-react';

const PRELOADED_TASKS: Task[] = [
  {
    id: 'pt-1',
    title: 'Deploy Production Build of Core Software Project',
    description: 'Final check of all integration routes and server configs. Must be pushed by end of business today.',
    completed: false,
    rank: 'King',
    pieceName: 'Critical Priority',
    insight: 'Pushing this release secures the foundation of your core system, preventing high-stakes downtime today.',
    categoryExplanation: 'Critical priority directly driving primary goals',
    masteryInsight: 'Block out an uninterrupted 90-minute slot. Zero multitasking to ensure flawless execution.',
    excellenceChallenge: '',
    createdAt: Date.now() - 3600000,
  },
  {
    id: 'pt-2',
    title: 'Architect API Scaling Strategy & DB Blueprints',
    description: 'Plan the upcoming migration from temporary local store to a durable cloud persistence database layer.',
    completed: false,
    rank: 'Queen',
    pieceName: 'High Priority',
    insight: 'Mapping out durable database blueprints removes the risk of losing critical user data during future scaling phases.',
    categoryExplanation: 'Strategic projects that drive high impact',
    masteryInsight: 'Establish clean milestones and define key results before starting to ensure team alignment.',
    excellenceChallenge: '',
    createdAt: Date.now() - 7200000,
  }
];

export default function App() {
  const storeTasks = useProductivityStore(s => s.tasks);

  // Stable Task list derived declaratively from Zustand Store
  const tasks = useMemo<Task[]>(() => {
    const activeStoreTasks = storeTasks && storeTasks.length > 0 ? storeTasks : [];
    
    // Fallback if the store is empty
    const baseTasks = activeStoreTasks.length > 0 ? activeStoreTasks : (() => {
      const saved = localStorage.getItem('mentor_tasks_professional_coaching');
      return saved ? JSON.parse(saved) : PRELOADED_TASKS;
    })();

    return baseTasks.map((st: any) => {
      const rank = st.rank || (st.priority === 'KING' ? 'King' : st.priority === 'QUEEN' ? 'Queen' : st.priority === 'ROOK' ? 'Rook' : 'Pawn');
      return {
        id: st.id,
        title: st.title,
        description: st.description || '',
        completed: st.completed,
        rank,
        pieceName: st.pieceName || `${rank} Move`,
        insight: st.insight || '',
        categoryExplanation: st.categoryExplanation || '',
        primaryGoal: st.primaryGoal || '',
        masteryInsight: st.masteryInsight || '',
        excellenceChallenge: st.excellenceChallenge || '',
        createdAt: st.createdAt ? new Date(st.createdAt).getTime() : Date.now(),
        analyzing: st.analyzing,
        isProposed: st.isProposed,
        proposedRank: st.proposedRank,
        followUpQuestion: st.followUpQuestion
      } as Task;
    });
  }, [storeTasks]);

  const [currentLayer, setCurrentLayer] = useState<'dashboard' | 'calendar' | 'board' | 'engines' | 'mentor' | 'analytics' | 'portal' | 'council' | 'saboteur' | 'gmail' | 'reflections'>('dashboard');
  const [currentTaskId, setCurrentTaskId] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Auth, state, and sync actions from store
  const currentUser = useProductivityStore(s => s.currentUser);
  const logout = useProductivityStore(s => s.logout);
  const syncWorkspace = useProductivityStore(s => s.syncWorkspace);
  const updateUserProfile = useProductivityStore(s => s.updateUserProfile);
  const storeUserProfile = useProductivityStore(s => s.userProfile);
  const storeHabits = useProductivityStore(s => s.habits);
  const storeReminders = useProductivityStore(s => s.reminders);
  const addTask = useProductivityStore(s => s.addTask);
  const setCurrentUser = useProductivityStore(s => s.setCurrentUser);
  const authInitialized = useProductivityStore(s => s.authInitialized);
  const setAuthInitialized = useProductivityStore(s => s.setAuthInitialized);

  const isSyncing = useProductivityStore(s => s.isSyncing);
  const lastSyncedAt = useProductivityStore(s => s.lastSyncedAt);
  const autoSyncEnabled = useProductivityStore(s => s.autoSyncEnabled ?? true);
  const toggleAutoSync = useProductivityStore(s => s.toggleAutoSync);

  // Profile Editor Modal States
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [profileName, setProfileName] = useState(storeUserProfile?.name || '');
  const [profileAge, setProfileAge] = useState(storeUserProfile?.age || '');
  const [profileRole, setProfileRole] = useState(storeUserProfile?.role || '');
  const [profileGoal, setProfileGoal] = useState(storeUserProfile?.primaryGoal || '');
  const [profilePurpose, setProfilePurpose] = useState(storeUserProfile?.purpose || '');
  const [profileAvatar, setProfileAvatar] = useState(currentUser?.profilePicture || 'slate');

  // New Task Modal States
  const [showNewTaskModal, setShowNewTaskModal] = useState(false);
  const [newTaskName, setNewTaskName] = useState('');
  const [newTaskDesc, setNewTaskDesc] = useState('');
  const [newTaskDueDate, setNewTaskDueDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [newTaskPriority, setNewTaskPriority] = useState<'KING' | 'QUEEN' | 'ROOK' | 'PAWN'>('QUEEN');
  const [newTaskDuration, setNewTaskDuration] = useState('30');
  const [newTaskCategory, setNewTaskCategory] = useState('Work');
  const [newTaskNotes, setNewTaskNotes] = useState('');

  // Right Sidebar mini-consultation state
  const [miniConsultText, setMiniConsultText] = useState('');

  // Calendar tab offset state
  const [calendarOffset, setCalendarOffset] = useState(0);

  // Listen to Firebase auth state changes
  useEffect(() => {
    const unsubscribe = authService.subscribeToAuth(async (user) => {
      if (user) {
        // Retrieve and compare stored user session with active Firebase session
        const storeUser = useProductivityStore.getState().currentUser;
        if (!storeUser || storeUser.email !== user.email) {
          try {
            const response = await fetch('/api/auth/firebase-sync', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                email: user.email,
                fullName: user.displayName || user.email?.split('@')[0] || 'User',
                profilePicture: 'royal'
              })
            });
            if (response.ok) {
              const data = await response.json();
              setCurrentUser({
                email: data.user.email,
                name: data.user.fullName,
                profilePicture: data.user.profilePicture,
                onboarded: data.user.onboarded
              }, data.user.profile || null, data.user.workspace || null);
            }
          } catch (err) {
            console.error('Session synchronization failed:', err);
          }
        }
      } else {
        // Discard local user session if Firebase Auth state is unauthenticated
        const storeUser = useProductivityStore.getState().currentUser;
        if (storeUser) {
          logout();
        }
      }
      setAuthInitialized?.(true);
    });

    return () => unsubscribe();
  }, [setCurrentUser, logout, setAuthInitialized]);

  // Centralized debounced Cloud Workspace Synchronization
  useDebouncedEffect(() => {
    if (currentUser && autoSyncEnabled) {
      syncWorkspace();
    }
  }, 1500, [storeTasks, storeUserProfile, storeHabits, storeReminders]);

  // Initialize Zustand store on first load if it is empty but local tasks exist
  useEffect(() => {
    const currentStoreTasks = useProductivityStore.getState().tasks;
    if (currentStoreTasks.length === 0) {
      const saved = localStorage.getItem('mentor_tasks_professional_coaching');
      const base = saved ? JSON.parse(saved) : PRELOADED_TASKS;
      const mappedStore = base.map((t: any) => {
        const priority = t.rank ? (t.rank.toUpperCase() as 'KING' | 'QUEEN' | 'ROOK' | 'PAWN') : 'QUEEN';
        return {
          id: t.id,
          title: t.title,
          description: t.description || undefined,
          priority,
          completed: t.completed,
          createdAt: t.createdAt ? new Date(t.createdAt).toISOString() : new Date().toISOString(),
          rank: t.rank || (priority === 'KING' ? 'King' : priority === 'QUEEN' ? 'Queen' : priority === 'ROOK' ? 'Rook' : 'Pawn'),
          pieceName: t.pieceName,
          insight: t.insight,
          categoryExplanation: t.categoryExplanation,
          primaryGoal: t.primaryGoal,
          masteryInsight: t.masteryInsight,
          excellenceChallenge: t.excellenceChallenge,
          analyzing: t.analyzing,
          isProposed: t.isProposed,
          proposedRank: t.proposedRank,
          followUpQuestion: t.followUpQuestion
        };
      });
      useProductivityStore.setState({ tasks: mappedStore });
    }
  }, []);

  // Sync to localStorage for backward compatibility
  useEffect(() => {
    if (tasks.length > 0) {
      localStorage.setItem('mentor_tasks_professional_coaching', JSON.stringify(tasks));
      localStorage.setItem('chess_tasks_grandmaster_coaching', JSON.stringify(tasks));
    }
  }, [tasks]);

  // Custom AI alignment submission
  const handleAddTask = async (title: string, description: string, primaryGoal: string) => {
    const taskId = `move-${Date.now()}`;
    
    const storeTask = {
      id: taskId,
      title,
      description,
      primaryGoal,
      completed: false,
      analyzing: true,
      isProposed: true,
      createdAt: new Date().toISOString(),
      priority: 'QUEEN' as const
    };

    const currentTasks = useProductivityStore.getState().tasks;
    useProductivityStore.setState({ tasks: [storeTask, ...currentTasks] });
    setCurrentTaskId(taskId);
    setCurrentLayer('council');
    setIsAnalyzing(true);

    try {
      const response = await fetch('/api/coach/analyze-task', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title, description, primaryGoal })
      });

      if (!response.ok) {
        throw new Error('Analysis failed');
      }

      const data = await response.json();
      const rank = data.rank as ChessRank;

      const currentTasksNow = useProductivityStore.getState().tasks;
      useProductivityStore.setState({
        tasks: currentTasksNow.map((t) =>
          t.id === taskId
            ? {
                ...t,
                proposedRank: rank,
                pieceName: data.pieceName,
                insight: data.insight,
                categoryExplanation: data.categoryExplanation,
                masteryInsight: data.masteryInsight,
                excellenceChallenge: data.excellenceChallenge,
                followUpQuestion: data.followUpQuestion,
                analyzing: false
              }
            : t
        )
      });
      setIsAnalyzing(false);
    } catch (err) {
      console.warn('API error. Using local fallback:', err);
      
      const combined = (title + ' ' + description).toLowerCase();
      let rank: ChessRank = 'Queen';
      let pieceName = 'High Priority';
      let insight = 'This task secures vital productivity space and establishes long-term growth.';
      let categoryExplanation = 'Strategic projects that drive high impact';
      let masteryInsight = 'Identify intermediate milestones and clear metrics of success before launching.';
      let excellenceChallenge = '';
      let followUpQuestion = 'What is the single biggest roadblock you anticipate, and how will you bypass it?';

      if (combined.includes('urgent') || combined.includes('deadline') || combined.includes('must') || combined.includes('fix') || combined.includes('asap') || combined.includes('today') || combined.includes('critical')) {
        rank = 'King';
        pieceName = 'Critical Priority';
        insight = 'This task directly protects your schedule or secures key results. Prioritize and execute immediately.';
        categoryExplanation = 'Critical priority task directly driving primary goals';
        masteryInsight = 'Block out distraction-free time to execute this critical task. Zero multitasking allowed.';
        followUpQuestion = 'What is the absolute first action you need to take in the next hour to secure this critical task?';
      } else if (combined.includes('art') || combined.includes('dance') || combined.includes('music') || combined.includes('paint') || combined.includes('play') || combined.includes('hobby') || combined.includes('chill') || combined.includes('leisure') || combined.includes('gym') || combined.includes('health')) {
        rank = 'Pawn';
        pieceName = 'Low Priority';
        insight = 'Foundational growth keeps your energy resilient. Sustainable energy is non-negotiable.';
        categoryExplanation = 'Personal well-being and health, essential for long-term endurance';
        masteryInsight = 'Treat recovery as a calculated pause to replenish your physical and mental reserve.';
        followUpQuestion = 'How can you protect this foundational space from being overrun by urgent work?';
      } else if (combined.includes('meeting') || combined.includes('call') || combined.includes('email') || combined.includes('admin') || combined.includes('chore') || combined.includes('quick')) {
        rank = 'Rook';
        pieceName = 'Medium Priority';
        insight = 'Batch these operational tasks to build structure and keep your day organized.';
        categoryExplanation = 'Essential for consistency and building structure';
        masteryInsight = 'Group repetitive administrative tasks into a single time-box to avoid context switching.';
        followUpQuestion = 'Can this task be grouped with others into a 30-minute block to protect your deep focus today?';
      }

      if (title.length < 10 || description.length < 15) {
        excellenceChallenge = `Your description for "${title}" is highly brief. Define what a perfect, high-level execution looks like for this task.`;
      }

      const currentTasksNow = useProductivityStore.getState().tasks;
      useProductivityStore.setState({
        tasks: currentTasksNow.map((t) =>
          t.id === taskId
            ? {
                ...t,
                proposedRank: rank,
                pieceName,
                insight,
                categoryExplanation,
                masteryInsight,
                excellenceChallenge,
                followUpQuestion,
                analyzing: false
              }
            : t
        )
      });
      setIsAnalyzing(false);
    }
  };

  const handleConfirmTask = (
    id: string,
    rankToUse: ChessRank,
    customInsight?: string,
    customCategoryExplanation?: string,
    customMasteryInsight?: string,
    customExcellenceChallenge?: string
  ) => {
    const pieceNames = {
      'King': 'Critical Priority',
      'Queen': 'High Priority',
      'Rook': 'Medium Priority',
      'Pawn': 'Low Priority',
    };
    const categoryExplanations = {
      'King': 'Critical priority task directly driving primary goals',
      'Queen': 'Strategic projects that drive high impact',
      'Rook': 'Essential for consistency and building structure',
      'Pawn': 'Personal well-being and health, essential for long-term endurance',
    };

    const currentTasks = useProductivityStore.getState().tasks;
    useProductivityStore.setState({
      tasks: currentTasks.map((t) =>
        t.id === id
          ? {
              ...t,
              isProposed: false,
              rank: rankToUse,
              priority: rankToUse.toUpperCase() as 'KING' | 'QUEEN' | 'ROOK' | 'PAWN',
              pieceName: pieceNames[rankToUse],
              categoryExplanation: customCategoryExplanation || categoryExplanations[rankToUse],
              proposedRank: undefined,
              insight: customInsight || t.insight || `May this task secure your schedule under the priority of ${rankToUse}.`,
              masteryInsight: customMasteryInsight !== undefined ? customMasteryInsight : t.masteryInsight,
              excellenceChallenge: customExcellenceChallenge !== undefined ? customExcellenceChallenge : t.excellenceChallenge
            }
          : t
      )
    });
    setCurrentTaskId(null);
    setCurrentLayer('board');
  };

  const handleRejectTask = (id: string) => {
    const currentTasks = useProductivityStore.getState().tasks;
    useProductivityStore.setState({
      tasks: currentTasks.filter((t) => t.id !== id)
    });
    setCurrentTaskId(null);
    setCurrentLayer('dashboard');
  };

  const handleToggleTask = (id: string) => {
    const currentTasks = useProductivityStore.getState().tasks;
    useProductivityStore.setState({
      tasks: currentTasks.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    });
  };

  const handleDeleteTask = (id: string) => {
    const currentTasks = useProductivityStore.getState().tasks;
    useProductivityStore.setState({
      tasks: currentTasks.filter((t) => t.id !== id)
    });
  };

  const handleClearAll = () => {
    if (window.confirm("Do you wish to clear all moves from the Strategic Board Registry?")) {
      useProductivityStore.setState({ tasks: [] });
      setCurrentTaskId(null);
      setCurrentLayer('dashboard');
    }
  };

  const handleTriggerBlunder = (task: Task) => {
    const currentTasks = useProductivityStore.getState().tasks;
    if (!currentTasks.some((t) => t.id === task.id)) {
      const priority = task.rank ? (task.rank.toUpperCase() as 'KING' | 'QUEEN' | 'ROOK' | 'PAWN') : 'QUEEN';
      const storeTaskItem = {
        id: task.id,
        title: task.title,
        description: task.description || undefined,
        priority,
        completed: task.completed,
        createdAt: task.createdAt ? new Date(task.createdAt).toISOString() : new Date().toISOString(),
        rank: task.rank,
        pieceName: task.pieceName,
        insight: task.insight,
        categoryExplanation: task.categoryExplanation,
        primaryGoal: task.primaryGoal,
        masteryInsight: task.masteryInsight,
        excellenceChallenge: task.excellenceChallenge,
        analyzing: task.analyzing,
        isProposed: task.isProposed,
        proposedRank: task.proposedRank,
        followUpQuestion: task.followUpQuestion
      };
      useProductivityStore.setState({ tasks: [storeTaskItem, ...currentTasks] });
    }
    setCurrentTaskId(task.id);
    setCurrentLayer('saboteur');
  };

  const handleAcknowledgeBlunder = (action: 'recover' | 'delete') => {
    const currentTasks = useProductivityStore.getState().tasks;
    if (currentTaskId) {
      if (action === 'delete') {
        useProductivityStore.setState({
          tasks: currentTasks.filter((t) => t.id !== currentTaskId)
        });
      } else if (action === 'recover') {
        useProductivityStore.setState({
          tasks: currentTasks.map((t) =>
            t.id === currentTaskId ? { ...t, completed: false } : t
          )
        });
      }
    }
    setCurrentTaskId(null);
    setCurrentLayer('board');
  };

  const handleDeployTasks = (newTasksList: Omit<Task, 'id' | 'createdAt' | 'completed'>[]) => {
    const formatted = newTasksList.map((t) => {
      const pieceNames = {
        'King': 'Critical Priority',
        'Queen': 'High Priority',
        'Rook': 'Medium Priority',
        'Pawn': 'Low Priority',
      };
      const rankToUse = t.rank || 'Queen';
      const priority = rankToUse.toUpperCase() as 'KING' | 'QUEEN' | 'ROOK' | 'PAWN';
      return {
        ...t,
        id: `move-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        completed: false,
        createdAt: new Date().toISOString(),
        priority,
        pieceName: pieceNames[rankToUse]
      };
    });

    const currentTasks = useProductivityStore.getState().tasks;
    useProductivityStore.setState({ tasks: [...formatted, ...currentTasks] });
  };

  // Direct Modal Save Action
  const handleQuickSaveTask = () => {
    if (!newTaskName.trim()) return;
    
    const taskData = {
      title: newTaskName.trim(),
      description: newTaskDesc.trim() + (newTaskNotes.trim() ? `\n\nNotes: ${newTaskNotes.trim()}` : ''),
      priority: newTaskPriority,
      dueDate: newTaskDueDate,
      startTime: '10:00',
      durationMinutes: parseInt(newTaskDuration) || 30,
      primaryGoal: newTaskCategory
    };

    addTask(taskData);
    
    // Clear States
    setNewTaskName('');
    setNewTaskDesc('');
    setNewTaskNotes('');
    setNewTaskPriority('QUEEN');
    setNewTaskDuration('30');
    setNewTaskCategory('Work');
    setShowNewTaskModal(false);

    // Route to Tasks Board to inspect newly added task
    setCurrentLayer('board');
  };

  // AI Calibration Modal Save Action
  const handleAICalibrateTask = () => {
    if (!newTaskName.trim()) return;

    handleAddTask(
      newTaskName.trim(),
      newTaskDesc.trim() + (newTaskNotes.trim() ? `\n\nNotes: ${newTaskNotes.trim()}` : ''),
      newTaskCategory
    );

    // Clear and close
    setNewTaskName('');
    setNewTaskDesc('');
    setNewTaskNotes('');
    setNewTaskPriority('QUEEN');
    setNewTaskDuration('30');
    setNewTaskCategory('Work');
    setShowNewTaskModal(false);
  };

  const handleMiniConsultSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!miniConsultText.trim()) return;
    
    // Switch to Mentor layer and pass the message or trigger
    setCurrentLayer('mentor');
    setMiniConsultText('');
  };

  const AVATAR_CLASSES: Record<string, string> = {
    slate: 'bg-slate-600',
    amber: 'bg-amber-600',
    emerald: 'bg-emerald-600',
    royal: 'bg-indigo-600'
  };

  const handleSaveProfile = async () => {
    updateUserProfile({
      name: profileName.trim(),
      age: profileAge.trim(),
      role: profileRole,
      primaryGoal: profileGoal.trim(),
      purpose: profilePurpose.trim()
    });
    
    if (currentUser) {
      useProductivityStore.setState({
        currentUser: {
          ...currentUser,
          name: profileName.trim(),
          profilePicture: profileAvatar
        }
      });
    }

    setShowProfileModal(false);
    
    setTimeout(() => {
      syncWorkspace();
    }, 500);
  };

  // Safe retrieve of days of active week for Calendar layer
  const getCalendarDays = () => {
    const days = [];
    const today = new Date();
    today.setDate(today.getDate() + (calendarOffset * 7));
    const day = today.getDay();
    const diff = today.getDate() - day + (day === 0 ? -6 : 1);
    const monday = new Date(today.setDate(diff));

    for (let i = 0; i < 7; i++) {
      const nextDay = new Date(monday);
      nextDay.setDate(monday.getDate() + i);
      days.push(nextDay);
    }
    return days;
  };

  const calendarDays = getCalendarDays();

  // Find current task for Layer 2
  const councilTask = currentTaskId ? tasks.find(t => t.id === currentTaskId) : null;
  const userProfile = useProductivityStore((s) => s.userProfile);

  if (!authInitialized) {
    return (
      <div className="min-h-screen w-full bg-[#070709] text-gray-200 flex flex-col items-center justify-center font-mono">
        <div className="relative flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#D4AF37] to-amber-600 flex items-center justify-center text-black font-black text-lg shadow-[0_4px_20px_rgba(245,158,11,0.25)] animate-bounce">
            M
          </div>
          <div className="flex flex-col items-center gap-1.5">
            <span className="font-serif text-sm font-bold tracking-widest text-gray-100 uppercase animate-pulse">
              Mentor-E-Schedule
            </span>
            <span className="text-[10px] text-gray-500 uppercase tracking-wider">
              Authenticating session...
            </span>
          </div>
          <div className="w-8 h-8 rounded-full border-2 border-amber-500/20 border-t-amber-500 animate-spin mt-4"></div>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <LandingPage />;
  }

  if (!userProfile?.onboarded) {
    return <OnboardingFlow />;
  }

  return (
    <div className="min-h-screen bg-[#07080a] text-[#e2e8f0] font-sans antialiased flex flex-col justify-between selection:bg-[#D4AF37]/30 selection:text-white" id="app-root">
      
      {/* 1. TOP DECORATIVE GRADIENT ACCENT BAR */}
      <div className="h-[3px] bg-gradient-to-r from-amber-600 via-[#D4AF37] to-amber-600 shadow-[0_2px_8px_rgba(212,175,55,0.4)] shrink-0"></div>

      {/* 2. MAIN APPLICATION TOP NAVIGATION BAR */}
      <header className="w-full bg-[#0c0d12] border-b border-gray-850/80 px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-4 shrink-0 shadow-md">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-br from-amber-500/20 to-amber-600/5 rounded-xl border border-amber-500/25 shadow-inner">
            <ShieldCheck className="w-5 h-5 text-[#D4AF37]" />
          </div>
          <div>
            <h1 className="font-serif text-lg text-white tracking-wider uppercase font-extrabold flex items-center gap-1.5" id="header-main-title">
              Mentor-E-Schedule
            </h1>
            <p className="text-[10px] text-gray-500 font-medium">Strategic Planning Ledger & Guidance Workspace</p>
          </div>
        </div>

        {/* Tab Item Links in Top Nav */}
        <nav className="flex flex-wrap items-center gap-1 bg-[#12131a]/60 p-1 rounded-xl border border-gray-800/80">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'calendar', label: 'Calendar', icon: Calendar },
            { id: 'board', label: 'Tasks', icon: ListTodo },
            { id: 'engines', label: 'Productivity Tools', icon: Zap },
            { id: 'mentor', label: 'Mentor', icon: MessageSquare },
            { id: 'reflections', label: 'Reflections', icon: BookOpen },
            { id: 'gmail', label: 'Gmail Stream', icon: Mail },
            { id: 'analytics', label: 'Analytics', icon: BarChart }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = currentLayer === tab.id || (tab.id === 'board' && currentLayer === 'portal');
            return (
              <button
                key={tab.id}
                onClick={() => setCurrentLayer(tab.id as any)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-[10px] font-sans font-bold uppercase tracking-wider transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#D4AF37] font-extrabold shadow-sm'
                    : 'text-gray-400 hover:text-gray-200 border border-transparent hover:bg-white/[0.02]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right side controls & New Task Button */}
        <div className="flex items-center gap-3">
          
          {/* Cloud Synchronizer Widget */}
          <button
            onClick={() => syncWorkspace()}
            disabled={isSyncing}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#12131a] border border-gray-800 text-[9px] font-mono font-bold uppercase tracking-wider transition-all cursor-pointer ${
              isSyncing ? 'text-amber-400' : 'text-gray-400 hover:text-gray-200'
            }`}
            title="Synchronize to Cloud persistence"
          >
            <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">{isSyncing ? 'Syncing' : 'Sync'}</span>
          </button>

          {/* Edit Profile Widget */}
          <button
            onClick={() => {
              setProfileName(storeUserProfile.name);
              setProfileAge(storeUserProfile.age || '');
              setProfileRole(storeUserProfile.role);
              setProfileGoal(storeUserProfile.primaryGoal);
              setProfilePurpose(storeUserProfile.purpose);
              setProfileAvatar(currentUser?.profilePicture || 'slate');
              setShowProfileModal(true);
            }}
            className="flex items-center gap-2 p-1 bg-[#12131a]/60 border border-gray-800 rounded-xl hover:bg-gray-800/10 transition-all text-left cursor-pointer"
            title="Profile details"
          >
            <div className={`w-7 h-7 rounded-lg ${
              currentUser?.profilePicture === 'amber' ? 'bg-amber-600' :
              currentUser?.profilePicture === 'emerald' ? 'bg-emerald-600' :
              currentUser?.profilePicture === 'royal' ? 'bg-indigo-600' : 'bg-slate-600'
            } flex items-center justify-center text-white text-[11px] font-black`}>
              {(storeUserProfile.name || currentUser?.name || "U")[0].toUpperCase()}
            </div>
          </button>

          {/* Sign Out Button */}
          <button
            onClick={async () => {
              try {
                await authService.logout();
                logout();
              } catch (err) {
                console.error("Logout failed:", err);
              }
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#12131a] border border-gray-800 text-[9px] font-mono font-bold uppercase tracking-wider text-rose-400 hover:text-rose-300 hover:bg-rose-950/10 transition-all cursor-pointer"
            title="Sign Out of Session"
          >
            <LogOut className="w-3 h-3" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>

          {/* "+ New Task" Button */}
          <button
            onClick={() => setShowNewTaskModal(true)}
            className="bg-[#D4AF37] hover:bg-amber-500 text-black text-[10px] font-bold uppercase tracking-wider px-4 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-[0_2px_8px_rgba(212,175,55,0.15)]"
          >
            <Plus className="w-3.5 h-3.5 stroke-[3px]" />
            <span>New Task</span>
          </button>
        </div>
      </header>

      {/* 3. APP BODY WITH THREE-COLUMN LAYOUT STRUCTURE */}
      <div className="w-full flex-grow flex flex-col lg:flex-row overflow-hidden relative">
        
        {/* LEFT SIDEBAR (COLLAPSIBLE / DESKTOP OPTIONAL) */}
        <aside className="w-full lg:w-[220px] bg-[#0c0d12]/40 border-r border-gray-850/80 px-5 py-6 shrink-0 space-y-6 hidden md:block">
          {/* User profile card indicator */}
          <div className="space-y-3 border-b border-gray-850 pb-5">
            <div className="flex items-center gap-3">
              <div className={`w-9 h-9 rounded-xl ${
                currentUser?.profilePicture === 'amber' ? 'bg-amber-600' :
                currentUser?.profilePicture === 'emerald' ? 'bg-emerald-600' :
                currentUser?.profilePicture === 'royal' ? 'bg-indigo-600' : 'bg-slate-600'
              } flex items-center justify-center text-white text-sm font-black`}>
                {(storeUserProfile.name || currentUser?.name || "U")[0].toUpperCase()}
              </div>
              <div className="min-w-0">
                <h4 className="text-xs font-bold text-gray-200 truncate">{storeUserProfile.name}</h4>
                <span className="text-[9px] font-mono text-gray-500 block truncate">{storeUserProfile.role}</span>
              </div>
            </div>

            {/* Simple local status */}
            <div className="p-3 bg-black/30 border border-gray-850 rounded-xl space-y-1">
              <span className="text-[8px] font-mono text-gray-500 uppercase tracking-wider block">Rating Level</span>
              <div className="text-xs font-serif font-black text-amber-400">{storeUserProfile.eloScore} ELO</div>
              <p className="text-[9px] text-gray-400 font-medium leading-none line-clamp-1">{storeUserProfile.level}</p>
            </div>
          </div>

          {/* Nav Shortcut Section */}
          <div className="space-y-2">
            <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest block font-bold">Workspace Navigation</span>
            <div className="space-y-1">
              {[
                { layer: 'dashboard', label: 'Workspace Dashboard', icon: LayoutDashboard },
                { layer: 'board', label: 'Strategic Plan Registry', icon: ListTodo },
                { layer: 'engines', label: 'AI Planning Toolbox', icon: Zap },
                { layer: 'mentor', label: 'Advisor Discussion', icon: MessageSquare }
              ].map((link, i) => {
                const Icon = link.icon;
                const isActive = currentLayer === link.layer;
                return (
                  <button
                    key={i}
                    onClick={() => setCurrentLayer(link.layer as any)}
                    className={`w-full flex items-center gap-2 p-2 px-3 rounded-lg text-[10px] font-bold text-left transition-all cursor-pointer ${
                      isActive 
                        ? 'bg-amber-500/5 text-amber-300 border-l-2 border-[#D4AF37]' 
                        : 'text-gray-400 hover:text-gray-200 hover:bg-white/[0.01]'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{link.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick status values */}
          <div className="space-y-2.5 pt-4 border-t border-gray-850">
            <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest block font-bold">System Integrity</span>
            <div className="flex items-center justify-between text-[10px] text-gray-400 font-mono">
              <span>Coaching Core</span>
              <span className="text-[#D4AF37] font-semibold">Active</span>
            </div>
            <div className="flex items-center justify-between text-[10px] text-gray-400 font-mono">
              <span>Cloud Ledger</span>
              <span className="text-emerald-500 font-semibold">Synced</span>
            </div>
          </div>
        </aside>

        {/* MAIN CONTAINER CONTENT VIEWPORT */}
        <main className="flex-grow overflow-y-auto px-6 py-6 min-h-[70vh] bg-[#07080a] relative scrollbar-thin">
          <AnimatePresence mode="wait">
            
            {/* Dashboard View */}
            {currentLayer === 'dashboard' && (
              <Dashboard
                key="dashboard"
                onNavigateToMentor={() => setCurrentLayer('engines')}
                onNavigateToBoard={() => setCurrentLayer('board')}
              />
            )}

            {/* Calendar View */}
            {currentLayer === 'calendar' && (
              <div className="w-full space-y-6" key="calendar">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h3 className="font-serif text-2xl font-black text-gray-100 uppercase tracking-wide">
                      Tactical Week Schedule
                    </h3>
                    <p className="text-xs text-gray-400">
                      Sequence, balance, and configure your entire weekly operations at high resolution.
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 bg-[#12131a] p-1 rounded-xl border border-gray-800">
                    <button
                      onClick={() => setCalendarOffset(prev => prev - 1)}
                      className="p-1.5 bg-black/40 hover:bg-gray-800 rounded-lg text-gray-400 transition-all cursor-pointer"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setCalendarOffset(0)}
                      className="px-3 py-1 bg-black/40 hover:bg-gray-800 rounded-lg text-[10px] font-mono text-gray-300 font-bold transition-all cursor-pointer"
                    >
                      Current Week
                    </button>
                    <button
                      onClick={() => setCalendarOffset(prev => prev + 1)}
                      className="p-1.5 bg-black/40 hover:bg-gray-800 rounded-lg text-gray-400 transition-all cursor-pointer"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Main 7 Columns View */}
                <div className="grid grid-cols-1 lg:grid-cols-7 gap-4">
                  {calendarDays.map((dayDate, i) => {
                    const formattedISO = dayDate.toISOString().split('T')[0];
                    const isToday = formattedISO === new Date().toISOString().split('T')[0];
                    
                    const weekdayName = dayDate.toLocaleDateString('en-US', { weekday: 'long' });
                    const monthDayName = dayDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

                    // Find tasks for this day
                    const dayTasks = tasks.filter(t => t.dueDate === formattedISO);

                    return (
                      <div 
                        key={i} 
                        className={`p-4 rounded-2xl border flex flex-col justify-between min-h-[300px] bg-[#0b0c10]/80 transition-all ${
                          isToday 
                            ? 'border-amber-500/40 bg-amber-500/[0.02]' 
                            : 'border-gray-850 hover:border-gray-800'
                        }`}
                      >
                        <div className="border-b border-gray-850 pb-2 space-y-0.5">
                          <span className={`text-[10px] uppercase font-mono font-black ${
                            isToday ? 'text-amber-400' : 'text-gray-400'
                          }`}>{weekdayName}</span>
                          <span className="text-xs text-gray-500 font-semibold block">{monthDayName}</span>
                        </div>

                        {/* List Tasks for this day */}
                        <div className="flex-grow py-3 space-y-2 overflow-y-auto max-h-[180px] scrollbar-none">
                          {dayTasks.map(task => (
                            <div 
                              key={task.id}
                              className={`p-2 rounded-xl bg-black/40 border text-left space-y-1 text-[10px] ${
                                task.completed 
                                  ? 'border-gray-900 opacity-50 text-gray-500' 
                                  : task.rank === 'King' 
                                    ? 'border-rose-500/25 text-rose-300' 
                                    : task.rank === 'Queen'
                                      ? 'border-amber-500/25 text-amber-200'
                                      : 'border-gray-800 text-gray-300'
                              }`}
                            >
                              <div className="flex items-center gap-1.5 justify-between">
                                <span className="font-bold line-clamp-1">{task.title}</span>
                                {task.completed && (
                                  <span className="text-[8px] uppercase font-mono text-emerald-400 font-black">OK</span>
                                )}
                              </div>
                              {task.startTime && (
                                <span className="text-gray-500 block font-mono text-[8px]">{task.startTime} ({task.durationMinutes || 30}m)</span>
                              )}
                            </div>
                          ))}
                          {dayTasks.length === 0 && (
                            <div className="text-[10px] text-gray-600 italic text-center py-8">No operations scheduled</div>
                          )}
                        </div>

                        <div className="text-[9px] font-mono text-gray-500 border-t border-gray-850/40 pt-2 text-right">
                          {dayTasks.length} {dayTasks.length === 1 ? 'Task' : 'Tasks'}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Portal Submission View */}
            {currentLayer === 'portal' && (
              <LayerPortal 
                key="portal" 
                onSubmit={handleAddTask} 
                isAnalyzing={isAnalyzing} 
                onViewBoard={() => setCurrentLayer('board')}
              />
            )}

            {/* Council Strategic Review View */}
            {currentLayer === 'council' && (
              <LayerCouncil 
                key="council" 
                task={councilTask || null} 
                onApprove={handleConfirmTask} 
                onReject={handleRejectTask}
                isAnalyzing={isAnalyzing}
              />
            )}

            {/* Tasks Board View */}
            {currentLayer === 'board' && (
              <LayerBoard 
                key="board" 
                tasks={tasks} 
                onToggleTask={handleToggleTask} 
                onDeleteTask={handleDeleteTask} 
                onReturnToPortal={() => setCurrentLayer('portal')}
                onClearAll={handleClearAll}
                onTriggerBlunder={handleTriggerBlunder}
              />
            )}

            {/* Saboteur Blunder View */}
            {currentLayer === 'saboteur' && councilTask && (
              <LayerSaboteur 
                key="saboteur"
                task={councilTask}
                onAcknowledge={handleAcknowledgeBlunder}
              />
            )}

            {/* Productivity Tools View */}
            {currentLayer === 'engines' && (
              <LayerEngines
                key="engines"
                primaryGoal={tasks[0]?.primaryGoal || 'Achieve peak professional impact and reach key milestones'}
                onDeployTasks={(deployed) => {
                  handleDeployTasks(deployed);
                  setCurrentLayer('board');
                }}
                onReturnToBoard={() => setCurrentLayer('board')}
              />
            )}

            {/* Talk to Mentor View */}
            {currentLayer === 'mentor' && (
              <div className="w-full h-full min-h-[500px]" key="mentor">
                <div className="space-y-1 mb-4">
                  <h3 className="font-serif text-2xl font-black text-gray-100 uppercase tracking-wide">
                    Talk to Mentor Advisor
                  </h3>
                  <p className="text-xs text-gray-400">
                    Conduct direct planning discussions, secure performance insights, or resolve operational context struggles.
                  </p>
                </div>
                <MentorPanel />
              </div>
            )}

            {/* Analytics View */}
            {currentLayer === 'analytics' && (
              <AnalyticsPanel key="analytics" />
            )}

            {/* Reflections View */}
            {currentLayer === 'reflections' && (
              <DailyReflectionSystem key="reflections" />
            )}

            {/* Gmail Ingestion View */}
            {currentLayer === 'gmail' && (
              <LayerGmail key="gmail" />
            )}

          </AnimatePresence>
        </main>

        {/* RIGHT SIDEBAR (AI ADVISOR CONSOLE & SUGGESTIONS) */}
        <aside className="w-full lg:w-[260px] bg-[#0c0d12]/40 border-l border-gray-850/80 px-5 py-6 shrink-0 space-y-6 hidden xl:block">
          
          {/* Section: Live Advice */}
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-amber-400">
              <Sparkles className="w-4 h-4 shrink-0" />
              <span className="text-[9px] font-mono uppercase tracking-widest font-black">Live Advisor Advice</span>
            </div>

            <div className="bg-[#0f1015] border border-gray-850 rounded-2xl p-4 space-y-3 shadow-md">
              <div className="space-y-1">
                <span className="text-[8px] font-mono text-gray-500 uppercase tracking-wider block font-bold">Daily Priority Alert</span>
                <p className="text-[11px] text-gray-300 font-serif font-bold leading-snug">
                  {tasks.filter(t => !t.completed && t.rank === 'King').length > 0 
                    ? "Verify your critical 'King' execution block." 
                    : "Pacing is optimal. Focus on standard maintenance."
                  }
                </p>
              </div>

              <p className="text-[10px] text-gray-450 leading-relaxed">
                {tasks.filter(t => !t.completed && t.rank === 'King').length > 0 
                  ? "You have active critical priorities on the board. Make sure to complete them systematically before tackling background growth."
                  : "Sustainable daily routines are essential. Consider logging foundational habits or scheduling tomorrow's agenda early."
                }
              </p>
            </div>
          </div>

          {/* Section: Quick Consult input form */}
          <div className="space-y-3 border-t border-gray-850 pt-5">
            <div className="flex items-center gap-1.5 text-amber-400">
              <MessageSquare className="w-4 h-4 shrink-0" />
              <span className="text-[9px] font-mono uppercase tracking-widest font-black">Quick Consult</span>
            </div>

            <form onSubmit={handleMiniConsultSubmit} className="space-y-2">
              <textarea
                value={miniConsultText}
                onChange={(e) => setMiniConsultText(e.target.value)}
                placeholder="Ask the Advisor a quick question..."
                className="w-full bg-[#08080a] border border-gray-800 focus:border-[#D4AF37]/50 rounded-xl p-3 text-[10.5px] text-gray-300 placeholder-gray-600 focus:outline-none transition-all resize-none h-20"
              />
              <button
                type="submit"
                className="w-full py-2 bg-gradient-to-r from-amber-600 to-amber-500 hover:brightness-110 text-black text-[9px] font-bold uppercase tracking-wider rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
              >
                <span>Consult Mentor</span>
              </button>
            </form>
          </div>

          {/* Strategy Tip widget */}
          <div className="p-3.5 bg-amber-500/5 border border-amber-500/10 rounded-xl space-y-1.5">
            <span className="text-[8px] font-mono text-amber-400 uppercase tracking-widest block font-black">System Notice</span>
            <p className="text-[10px] text-gray-400 leading-normal">
              Click the **Productivity Tools** tab at the top to access specialized planning engines.
            </p>
          </div>

        </aside>

      </div>

      {/* 4. APPLICATION SYSTEM FOOTER */}
      <footer className="w-full border-t border-gray-850/60 py-4 bg-[#0a0a0c] text-center text-[9px] text-gray-600 font-mono shrink-0">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <span>
            © 2026 Mentor-E-Schedule — Strategic Productivity Workspace.
          </span>
          <span className="flex items-center gap-1.5 text-gray-500">
            <span>Durable Ledger Mode</span>
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
            <span>Cloud Sync Active</span>
          </span>
        </div>
      </footer>

      {/* 5. CENTERED NEW TASK OVERLAY MODAL */}
      <AnimatePresence>
        {showNewTaskModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-xl bg-[#111218] border border-gray-850 rounded-3xl overflow-hidden shadow-2xl text-left font-sans"
            >
              {/* Modal Header */}
              <div className="p-5 border-b border-gray-850/80 bg-black/10 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#D4AF37] animate-pulse"></div>
                  <h3 className="font-serif text-sm font-extrabold uppercase tracking-wider text-gray-200">
                    Add Strategic Task
                  </h3>
                </div>
                <button
                  onClick={() => setShowNewTaskModal(false)}
                  className="text-gray-500 hover:text-gray-300 transition-all p-1.5 rounded-lg hover:bg-white/5 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Body Forms */}
              <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto scrollbar-thin">
                
                {/* Task Title */}
                <div className="space-y-1.5">
                  <label className="text-[9.5px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                    Task Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={newTaskName}
                    onChange={(e) => setNewTaskName(e.target.value)}
                    placeholder="e.g., Finalize API migration code & database schemas"
                    className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl px-3.5 py-2.5 text-xs text-gray-200 focus:outline-none transition-all placeholder-gray-600"
                  />
                </div>

                {/* Description */}
                <div className="space-y-1.5">
                  <label className="text-[9.5px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                    Strategic Description
                  </label>
                  <textarea
                    value={newTaskDesc}
                    onChange={(e) => setNewTaskDesc(e.target.value)}
                    rows={2}
                    placeholder="Provide a brief explanation of what needs to be solved..."
                    className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl px-3.5 py-2.5 text-xs text-gray-200 focus:outline-none transition-all placeholder-gray-600 resize-none"
                  />
                </div>

                {/* Dual Column priority / due date */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Due Date */}
                  <div className="space-y-1.5">
                    <label className="text-[9.5px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                      Due Date
                    </label>
                    <input
                      type="date"
                      value={newTaskDueDate}
                      onChange={(e) => setNewTaskDueDate(e.target.value)}
                      className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl px-3 py-2.5 text-xs text-gray-200 focus:outline-none transition-all text-left"
                    />
                  </div>

                  {/* Priority / Rank Selection */}
                  <div className="space-y-1.5">
                    <label className="text-[9.5px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                      Priority Level
                    </label>
                    <select
                      value={newTaskPriority}
                      onChange={(e) => setNewTaskPriority(e.target.value as any)}
                      className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl px-3 py-2.5 text-xs text-gray-200 focus:outline-none transition-all"
                    >
                      <option value="KING">🔴 Critical Priority</option>
                      <option value="QUEEN">🔶 High Priority</option>
                      <option value="ROOK">🔷 Medium Priority</option>
                      <option value="PAWN">🟢 Low Priority</option>
                    </select>
                  </div>

                </div>

                {/* Dual Column estimated minutes / category */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Duration minutes */}
                  <div className="space-y-1.5">
                    <label className="text-[9.5px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                      Estimated Duration (Minutes)
                    </label>
                    <select
                      value={newTaskDuration}
                      onChange={(e) => setNewTaskDuration(e.target.value)}
                      className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl px-3 py-2.5 text-xs text-gray-200 focus:outline-none transition-all"
                    >
                      <option value="15">15 Minutes</option>
                      <option value="30">30 Minutes</option>
                      <option value="45">45 Minutes</option>
                      <option value="60">1 Hour</option>
                      <option value="90">1.5 Hours</option>
                      <option value="120">2 Hours</option>
                      <option value="240">4 Hours</option>
                    </select>
                  </div>

                  {/* Category Label */}
                  <div className="space-y-1.5">
                    <label className="text-[9.5px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                      Workspace Category
                    </label>
                    <input
                      type="text"
                      value={newTaskCategory}
                      onChange={(e) => setNewTaskCategory(e.target.value)}
                      placeholder="e.g., Development, Marketing, Study"
                      className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl px-3.5 py-2.5 text-xs text-gray-200 focus:outline-none transition-all placeholder-gray-600"
                    />
                  </div>

                </div>

                {/* Extra Notes */}
                <div className="space-y-1.5">
                  <label className="text-[9.5px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                    Execution Notes & Context
                  </label>
                  <textarea
                    value={newTaskNotes}
                    onChange={(e) => setNewTaskNotes(e.target.value)}
                    rows={2}
                    placeholder="Enter secondary alignment criteria or context guidelines..."
                    className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl px-3.5 py-2.5 text-xs text-gray-200 focus:outline-none transition-all placeholder-gray-600 resize-none"
                  />
                </div>

              </div>

              {/* Modal Footer actions */}
              <div className="p-5 border-t border-gray-850/80 bg-black/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <button
                  type="button"
                  onClick={() => setShowNewTaskModal(false)}
                  className="px-4 py-2 bg-transparent text-gray-500 hover:text-gray-300 text-xs font-mono uppercase tracking-wider cursor-pointer border border-transparent hover:bg-white/5 rounded-xl transition-all self-start sm:self-auto"
                >
                  Cancel
                </button>

                <div className="flex items-center gap-3 self-end sm:self-auto">
                  {/* Direct Save Button */}
                  <button
                    type="button"
                    onClick={handleQuickSaveTask}
                    disabled={!newTaskName.trim()}
                    className="px-5 py-2.5 bg-gray-900 border border-gray-800 hover:border-gray-700 hover:bg-gray-800 disabled:opacity-40 text-gray-300 font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer"
                  >
                    Direct Save
                  </button>

                  {/* Strategic AI Alignment Button */}
                  <button
                    type="button"
                    onClick={handleAICalibrateTask}
                    disabled={!newTaskName.trim()}
                    className="px-5 py-2.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:brightness-110 disabled:opacity-40 text-black font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-lg shadow-amber-500/5 flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>AI Calibrate</span>
                  </button>
                </div>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 6. CENTERED PROFILE EDITING MODAL BACKDROP */}
      <AnimatePresence>
        {showProfileModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-lg bg-[#111218] border border-gray-850 rounded-3xl overflow-hidden shadow-2xl text-left"
            >
              <div className="p-5 border-b border-gray-850 bg-black/10 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#D4AF37] animate-pulse"></div>
                  <h3 className="font-serif text-xs font-bold uppercase tracking-wider text-amber-400">
                    Edit Strategic Profile
                  </h3>
                </div>
                <button
                  onClick={() => setShowProfileModal(false)}
                  className="text-gray-500 hover:text-gray-300 transition-all text-xs font-mono uppercase tracking-wider cursor-pointer"
                >
                  Close
                </button>
              </div>

              <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto scrollbar-thin">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                    className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl px-3.5 py-2.5 text-xs text-gray-200 focus:outline-none transition-all"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                    Age / Professional Cohort
                  </label>
                  <input
                    type="text"
                    value={profileAge}
                    onChange={(e) => setProfileAge(e.target.value)}
                    placeholder="e.g., 22 or Student Cohort"
                    className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl px-3.5 py-2.5 text-xs text-gray-200 focus:outline-none transition-all"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                    Your Current Professional Role
                  </label>
                  <select
                    value={profileRole}
                    onChange={(e) => setProfileRole(e.target.value)}
                    className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl px-3 py-2.5 text-xs text-gray-200 focus:outline-none transition-all"
                  >
                    <option value="Student">Student</option>
                    <option value="Professional">Professional</option>
                    <option value="Entrepreneur">Entrepreneur</option>
                    <option value="Freelancer">Freelancer</option>
                    <option value="Job Seeker">Job Seeker</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                    Primary Development Focus or Target Goal
                  </label>
                  <input
                    type="text"
                    value={profileGoal}
                    onChange={(e) => setProfileGoal(e.target.value)}
                    placeholder="e.g., Python & SQL Mastery, Data Analyst Preparation"
                    className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl px-3.5 py-2.5 text-xs text-gray-200 focus:outline-none transition-all"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                    Purpose / Working Style Preference
                  </label>
                  <textarea
                    value={profilePurpose}
                    onChange={(e) => setProfilePurpose(e.target.value)}
                    rows={3}
                    placeholder="e.g., Direct practical advice, focusing on building high-impact habits and maintaining daily work sequences."
                    className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl px-3.5 py-2.5 text-xs text-gray-200 focus:outline-none transition-all resize-none"
                  />
                </div>

                <div className="space-y-2 pt-1">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                    Workspace Theme / Profile Avatar
                  </label>
                  <div className="grid grid-cols-4 gap-2.5">
                    {Object.keys(AVATAR_CLASSES).map((preset) => {
                      const nameMap: Record<string, string> = {
                        slate: 'Slate',
                        amber: 'Amber',
                        emerald: 'Emerald',
                        royal: 'Royal'
                      };
                      return (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => setProfileAvatar(preset)}
                          className={`p-2 rounded-xl border flex flex-col items-center gap-1.5 cursor-pointer transition-all ${
                            profileAvatar === preset 
                              ? 'border-amber-500 bg-amber-500/5' 
                              : 'border-gray-800 bg-[#08080a] hover:border-gray-700'
                          }`}
                        >
                          <div className={`w-6 h-6 rounded-lg ${AVATAR_CLASSES[preset]} flex items-center justify-center text-white text-[9px] font-bold shadow-sm`}>
                            {nameMap[preset][0]}
                          </div>
                          <span className="text-[8.5px] font-mono text-gray-400">{nameMap[preset]}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div className="p-5 border-t border-gray-850 bg-black/10 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowProfileModal(false)}
                  className="px-4 py-2 border border-gray-850 bg-transparent hover:bg-gray-800/40 text-xs font-mono font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer text-gray-400"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveProfile}
                  className="px-5 py-2 bg-[#D4AF37] hover:bg-amber-500 text-black font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-[0_2px_10px_rgba(212,175,55,0.1)]"
                >
                  Save Profile
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
