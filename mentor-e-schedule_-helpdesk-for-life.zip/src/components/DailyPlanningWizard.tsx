import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar, 
  Clock, 
  Zap, 
  Brain, 
  Edit3, 
  Check, 
  Save, 
  Play, 
  Plus, 
  Trash2, 
  RefreshCw, 
  AlertCircle, 
  Sparkles, 
  Heart, 
  TrendingUp, 
  CheckCircle2, 
  ArrowRight,
  Sliders
} from 'lucide-react';
import { useProductivityStore } from '../stores/useProductivityStore';

export interface PlanSlot {
  id: string;
  time: string;
  taskId?: string;
  taskTitle: string;
  durationMinutes: number;
  energyRequired: 'High' | 'Medium' | 'Low';
}

export const DailyPlanningWizard: React.FC = () => {
  const { tasks, updateTask } = useProductivityStore();
  
  // Filter active tasks
  const activeTasks = tasks.filter(t => !t.completed);

  // Core Inputs
  const [availableHours, setAvailableHours] = useState<number>(8);
  const [energyLevel, setEnergyLevel] = useState<'High' | 'Medium' | 'Low'>('Medium');
  const [startTime, setStartTime] = useState<string>('09:00');

  // Plan State
  const [planSlots, setPlanSlots] = useState<PlanSlot[]>([]);
  const [commentary, setCommentary] = useState<string>('');
  const [focusMantra, setFocusMantra] = useState<string>('Prioritize execution over perfection.');
  const [completionRate, setCompletionRate] = useState<number>(75);

  // UX states
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [hasGenerated, setHasGenerated] = useState<boolean>(false);

  // Generate local plan using standard offline heuristic
  const generateLocalHeuristicPlan = () => {
    setErrorMessage(null);
    setIsLoading(true);

    try {
      if (activeTasks.length === 0) {
        // Mock default blocks if they have no tasks
        const defaultSlots: PlanSlot[] = [
          {
            id: 'slot-1',
            time: startTime,
            taskTitle: 'Establish Daily Milestones & Primary Goals',
            durationMinutes: 45,
            energyRequired: 'Medium'
          },
          {
            id: 'slot-2',
            time: addMinutesToTimeStr(startTime, 60),
            taskTitle: 'Technical Skill Building & Review',
            durationMinutes: 90,
            energyRequired: 'High'
          },
          {
            id: 'slot-3',
            time: addMinutesToTimeStr(startTime, 165),
            taskTitle: 'Operational Batches & Communications',
            durationMinutes: 45,
            energyRequired: 'Low'
          }
        ];
        
        setPlanSlots(defaultSlots);
        setCommentary("Your task board is currently clear of active obligations. I have calibrated a high-leverage template focusing on goal alignment and technical skill building. Add tasks on your board to schedule them directly.");
        setFocusMantra("Action breeds confidence.");
        setCompletionRate(95);
        setHasGenerated(true);
        setIsLoading(false);
        return;
      }

      // Sort: KING -> QUEEN -> ROOK -> PAWN
      const sorted = [...activeTasks].sort((a, b) => {
        const priorityOrder = { 'KING': 1, 'QUEEN': 2, 'ROOK': 3, 'PAWN': 4 };
        const pA = priorityOrder[a.priority] || 3;
        const pB = priorityOrder[b.priority] || 3;
        return pA - pB;
      });

      // Calibrate work window sizes and break duration by Energy Level
      let blockDurations = { 'KING': 90, 'QUEEN': 60, 'ROOK': 45, 'PAWN': 30 };
      let breakDuration = 15;

      if (energyLevel === 'High') {
        blockDurations = { 'KING': 120, 'QUEEN': 90, 'ROOK': 60, 'PAWN': 40 };
        breakDuration = 10;
      } else if (energyLevel === 'Low') {
        blockDurations = { 'KING': 60, 'QUEEN': 45, 'ROOK': 30, 'PAWN': 20 };
        breakDuration = 25;
      }

      const generated: PlanSlot[] = [];
      let [currH, currM] = startTime.split(':').map(Number);
      if (isNaN(currH)) { currH = 9; currM = 0; }

      let remainingMinutes = availableHours * 60;

      for (const t of sorted) {
        const dur = blockDurations[t.priority] || 45;
        if (remainingMinutes < dur) break;

        const timeStr = `${String(currH).padStart(2, '0')}:${String(currM).padStart(2, '0')}`;
        
        generated.push({
          id: `slot-${t.id}-${Date.now()}`,
          time: timeStr,
          taskId: t.id,
          taskTitle: t.title,
          durationMinutes: dur,
          energyRequired: t.priority === 'KING' ? 'High' : t.priority === 'QUEEN' ? 'Medium' : 'Low'
        });

        remainingMinutes -= dur;

        // Advance clock
        const nextM = currM + dur;
        currH = (currH + Math.floor(nextM / 60)) % 24;
        currM = nextM % 60;

        // Insert break if we have room
        if (remainingMinutes >= breakDuration) {
          const breakTimeStr = `${String(currH).padStart(2, '0')}:${String(currM).padStart(2, '0')}`;
          generated.push({
            id: `break-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
            time: breakTimeStr,
            taskTitle: "Strategic Recovery Break",
            durationMinutes: breakDuration,
            energyRequired: "Low"
          });

          remainingMinutes -= breakDuration;

          const nextMForBreak = currM + breakDuration;
          currH = (currH + Math.floor(nextMForBreak / 60)) % 24;
          currM = nextMForBreak % 60;
        }
      }

      setPlanSlots(generated);
      setCommentary(`[Quick Offline Mode]: Sorted your ${generated.filter(s => s.taskId).length} high-priority tasks into a smooth timeline spanning ${availableHours} hours. This sequence prioritizes higher focus tasks earlier in the day to prevent fatigue.`);
      setFocusMantra(energyLevel === 'High' ? "Direct your peak attention toward key tasks." : energyLevel === 'Low' ? "Conserve resources. Small milestones add up to great progress." : "Steady rhythm delivers the win.");
      setCompletionRate(energyLevel === 'High' ? 88 : energyLevel === 'Medium' ? 76 : 58);
      setHasGenerated(true);
    } catch (err: any) {
      setErrorMessage("Scheduling tool failure: " + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Generate day plan using backend Gemini AI
  const generateAIPoweredPlan = async () => {
    setErrorMessage(null);
    setIsLoading(true);

    try {
      const response = await fetch('/api/coach/suggest-day-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tasks: activeTasks,
          availableHours,
          energyLevel,
          startTime
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned status code ${response.status}`);
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      // Map API plan slots to our local schema (ensuring IDs exist)
      const formattedSlots = (data.plan || []).map((slot: any, idx: number) => ({
        id: slot.taskId ? `slot-${slot.taskId}-${idx}` : `slot-manual-${idx}`,
        time: slot.time || '09:00',
        taskId: slot.taskId,
        taskTitle: slot.taskTitle || 'Activity',
        durationMinutes: Number(slot.durationMinutes) || 45,
        energyRequired: slot.energyRequired || 'Medium'
      }));

      setPlanSlots(formattedSlots);
      setCommentary(data.commentary || "Your day plan is calibrated.");
      setFocusMantra(data.focusMantra || "Focus produces clarity.");
      setCompletionRate(data.estimatedCompletionRate || 75);
      setHasGenerated(true);

      setStatusMessage("Daily schedule created!");
      setTimeout(() => setStatusMessage(null), 3000);
    } catch (err: any) {
      console.warn("AI Generation resting. Initiating robust local backup.", err);
      // Fallback silently to offline plan
      generateLocalHeuristicPlan();
      setStatusMessage("Scheduled via offline helper.");
      setTimeout(() => setStatusMessage(null), 3500);
    } finally {
      setIsLoading(false);
    }
  };

  // Helper utility to add minutes to time string
  const addMinutesToTimeStr = (timeStr: string, minutes: number): string => {
    let [h, m] = timeStr.split(':').map(Number);
    if (isNaN(h)) { h = 9; m = 0; }
    const totalMinutes = h * 60 + m + minutes;
    const finalH = Math.floor(totalMinutes / 60) % 24;
    const finalM = totalMinutes % 60;
    return `${String(finalH).padStart(2, '0')}:${String(finalM).padStart(2, '0')}`;
  };

  // Save/Apply Plan to Zustand Tasks
  const handleApplyPlan = () => {
    let tasksUpdated = 0;
    
    planSlots.forEach(slot => {
      if (slot.taskId) {
        updateTask(slot.taskId, {
          startTime: slot.time,
          durationMinutes: slot.durationMinutes
        });
        tasksUpdated++;
      }
    });

    setStatusMessage(`Successfully synchronized ${tasksUpdated} scheduled tasks on your workspace board!`);
    setTimeout(() => setStatusMessage(null), 4000);
  };

  // Edit fields inline
  const updateSlotField = (id: string, field: keyof PlanSlot, value: any) => {
    setPlanSlots(prev => prev.map(s => {
      if (s.id === id) {
        return { ...s, [field]: value };
      }
      return s;
    }));
  };

  // Delete a slot
  const handleDeleteSlot = (id: string) => {
    setPlanSlots(prev => prev.filter(s => s.id !== id));
  };

  // Add a new empty custom block
  const handleAddCustomBlock = () => {
    const lastSlot = planSlots[planSlots.length - 1];
    const newTime = lastSlot ? addMinutesToTimeStr(lastSlot.time, lastSlot.durationMinutes) : startTime;
    
    const newSlot: PlanSlot = {
      id: `slot-custom-${Date.now()}`,
      time: newTime,
      taskTitle: 'New Operational Activity',
      durationMinutes: 45,
      energyRequired: 'Medium'
    };

    setPlanSlots(prev => [...prev, newSlot]);
  };

  return (
    <div className="bg-[#12131a] border border-gray-800/80 rounded-2xl overflow-hidden shadow-2xl font-sans text-gray-200" id="daily-planning-wizard-root">
      
      {/* HEADER SECTION */}
      <div className="p-6 border-b border-gray-800/60 bg-black/20 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-400 shrink-0" />
            <h3 className="font-serif text-base font-bold text-gray-100">Daily Planning Wizard</h3>
          </div>
          <p className="text-xs text-gray-400 leading-relaxed">
            Calibrate, sequence, and customize an optimized daily workflow aligned with your available hours and energy budget.
          </p>
        </div>
        
        {/* Active counter badge */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-black/40 border border-gray-800 text-[10px] font-mono text-gray-400">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span>Active Tasks to Schedule: {activeTasks.length}</span>
        </div>
      </div>

      {/* PARAMETERS SELECTION FORM */}
      <div className="p-6 border-b border-gray-800/40 bg-black/10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          
          {/* Start Time Select */}
          <div className="space-y-2">
            <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-500 block">
              Day Start Clock
            </label>
            <div className="relative">
              <Clock className="w-4 h-4 text-gray-500 absolute left-3 top-3.5" />
              <input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="w-full bg-black/40 border border-gray-800 hover:border-gray-700 focus:border-amber-500/40 focus:bg-black/60 rounded-xl pl-9 pr-4 py-3 text-xs text-gray-200 outline-none transition-all font-mono"
                id="planning-start-time-input"
              />
            </div>
          </div>

          {/* Available Hours */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-500 block">
                Available Hours
              </label>
              <span className="font-mono text-xs text-amber-400 font-bold">{availableHours} hrs</span>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min="1"
                max="16"
                value={availableHours}
                onChange={(e) => setAvailableHours(Number(e.target.value))}
                className="w-full accent-amber-500 bg-gray-900 rounded-lg appearance-none h-1 cursor-pointer"
                id="planning-available-hours-slider"
              />
            </div>
          </div>

          {/* Energy Level Select */}
          <div className="space-y-2">
            <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-500 block">
              Energy Allocation
            </label>
            <div className="grid grid-cols-3 bg-black/40 border border-gray-800 p-1 rounded-xl gap-1">
              {(['High', 'Medium', 'Low'] as const).map((lvl) => {
                const isActive = energyLevel === lvl;
                return (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setEnergyLevel(lvl)}
                    className={`py-2 text-[10px] font-bold rounded-lg transition-all cursor-pointer text-center ${
                      isActive 
                        ? lvl === 'High' 
                          ? 'bg-amber-500 text-black shadow-md' 
                          : lvl === 'Medium' 
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' 
                          : 'bg-blue-500/20 text-blue-300 border border-blue-500/20'
                        : 'text-gray-400 hover:text-gray-200 hover:bg-black/20'
                    }`}
                  >
                    {lvl}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action trigger buttons (Quick Offline Plan + AI Guided Plan) */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={generateLocalHeuristicPlan}
              disabled={isLoading}
              className="py-3 bg-gray-800 hover:bg-gray-750 text-gray-200 border border-gray-700/60 font-bold text-[11px] rounded-xl cursor-pointer transition-all flex items-center justify-center gap-1.5 hover:border-gray-600 active:scale-[0.98] disabled:opacity-50"
              id="heuristic-plan-trigger"
              title="Align schedule using simple offline ordering"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Offline Plan</span>
            </button>

            <button
              onClick={generateAIPoweredPlan}
              disabled={isLoading}
              className="py-3 bg-amber-500 hover:bg-amber-450 text-black font-extrabold text-[11px] rounded-xl cursor-pointer transition-all flex items-center justify-center gap-1.5 shadow-[0_2px_15px_rgba(245,158,11,0.15)] active:scale-[0.98] disabled:opacity-50"
              id="ai-plan-trigger"
              title="Optimize schedule using intelligent assistant guidance"
            >
              <Sparkles className="w-3.5 h-3.5 shrink-0" />
              <span>AI Day Plan</span>
            </button>
          </div>

        </div>
      </div>

      {/* ERROR DISPLAY */}
      {errorMessage && (
        <div className="m-6 p-4 bg-rose-950/20 border border-rose-500/20 text-xs text-rose-300 rounded-xl flex items-start gap-2.5" id="planning-error-display">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* STATUS BANNER */}
      {statusMessage && (
        <div className="mx-6 mt-6 p-3.5 bg-emerald-950/15 border border-emerald-500/20 text-xs text-emerald-300 rounded-xl flex items-center gap-2.5" id="planning-status-toast">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="font-medium">{statusMessage}</span>
        </div>
      )}

      {/* DAY PLAN WORKSPACE AREA */}
      <div className="p-6 space-y-6">
        {!hasGenerated ? (
          <div className="py-14 text-center max-w-sm mx-auto space-y-4" id="planning-empty-state">
            <div className="p-4 bg-amber-500/5 border border-amber-500/10 text-amber-500/50 rounded-2xl inline-block">
              <Clock className="w-8 h-8" />
            </div>
            <div className="space-y-1.5">
              <h4 className="font-serif text-sm font-bold text-gray-200">Daily Schedule Unconfigured</h4>
              <p className="text-[11px] text-gray-500 leading-relaxed">
                Configure your day start time and energy budget above, then click either **Offline Plan** or **AI Strategize** to sequence your tasks.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            
            {/* STRATEGIC OVERVIEW & STATS */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4" id="planning-overview-panel">
              
              {/* Mentor Commentary Brief */}
              <div className="md:col-span-2 p-4 bg-black/30 border border-gray-800/60 rounded-xl space-y-2 flex flex-col justify-between">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-1.5 text-[10px] font-mono text-amber-400/80 uppercase font-black tracking-wider">
                    <Brain className="w-3.5 h-3.5 shrink-0" />
                    <span>Mentor Advisory Note</span>
                  </div>
                  <p className="text-xs text-gray-300 leading-relaxed italic">
                    "{commentary}"
                  </p>
                </div>
                
                <div className="border-t border-gray-900 pt-2 flex items-center gap-2 text-[10px] text-gray-500">
                  <span className="font-mono uppercase font-bold text-amber-500/70">Mantra:</span>
                  <span className="italic">"{focusMantra}"</span>
                </div>
              </div>

              {/* Day Metrics */}
              <div className="p-4 bg-[#0a0a0c]/60 border border-gray-900 rounded-xl flex flex-col justify-between">
                <div className="space-y-2">
                  <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest block font-bold">Calibration Success Rate</span>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-3xl font-serif font-black text-amber-400">{completionRate}%</span>
                    <span className="text-[10px] font-mono text-gray-500">probability</span>
                  </div>
                </div>

                <div className="space-y-2 pt-4 border-t border-gray-900/40">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-gray-500">Total Work Blocks:</span>
                    <span className="font-bold text-gray-300 font-mono">{planSlots.filter(s => s.taskId).length} blocks</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-gray-500">Strategic Pauses:</span>
                    <span className="font-bold text-gray-300 font-mono">{planSlots.filter(s => !s.taskId).length} breaks</span>
                  </div>
                </div>
              </div>

            </div>

            {/* ACTION BUTTONS: EDIT, SAVE & APPLY */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-black/25 p-3 rounded-xl border border-gray-800/40">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className={`px-3.5 py-2 border rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    isEditing 
                      ? 'bg-amber-500/10 border-amber-500/40 text-amber-300' 
                      : 'bg-black/20 border-gray-800 text-gray-400 hover:text-gray-200'
                  }`}
                  id="planning-toggle-edit-btn"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{isEditing ? "Finish Tweaking" : "Tweak Plan Slots"}</span>
                </button>

                {isEditing && (
                  <button
                    onClick={handleAddCustomBlock}
                    className="px-3.5 py-2 bg-black/20 hover:bg-black/40 border border-gray-800 hover:border-gray-700 text-gray-300 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                    id="planning-add-custom-slot-btn"
                  >
                    <Plus className="w-3.5 h-3.5 text-amber-400" />
                    <span>Add Manual Activity</span>
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleApplyPlan}
                  className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs rounded-xl cursor-pointer transition-all flex items-center gap-1.5 shadow-[0_2px_15px_rgba(16,185,129,0.15)] active:scale-[0.98]"
                  id="planning-apply-plan-btn"
                >
                  <Save className="w-3.5 h-3.5 text-black" />
                  <span>Synchronize Day Plan with Workspace Board</span>
                </button>
              </div>
            </div>

            {/* SEQUENCE TIMELINE */}
            <div className="space-y-2.5 relative" id="planning-sequence-timeline">
              
              {/* Vertical line connector */}
              <div className="absolute left-[34px] top-4 bottom-4 w-0.5 bg-gray-800/50 pointer-events-none hidden sm:block" />

              {planSlots.map((slot, idx) => {
                const isBreak = !slot.taskId;
                
                return (
                  <div 
                    key={slot.id}
                    className={`relative p-4 rounded-xl border transition-all duration-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                      isBreak 
                        ? 'bg-[#0a0a0c]/40 border-gray-900/60 opacity-85' 
                        : 'bg-[#12131a] border-gray-850 hover:border-gray-800'
                    }`}
                  >
                    
                    {/* Time & Identifier block */}
                    <div className="flex items-center gap-4 w-full sm:w-auto">
                      <div className="flex items-center gap-2 sm:flex-col sm:gap-1 text-center shrink-0 w-16 sm:w-16">
                        <span className="font-mono text-[10px] text-amber-500/80 uppercase font-black block tracking-wide">Start Clock</span>
                        {isEditing ? (
                          <input
                            type="time"
                            value={slot.time}
                            onChange={(e) => updateSlotField(slot.id, 'time', e.target.value)}
                            className="bg-black/60 border border-gray-800 text-gray-200 text-xs font-mono rounded px-1.5 py-0.5 outline-none focus:border-amber-500/40 w-full text-center"
                          />
                        ) : (
                          <span className="font-mono text-sm font-bold text-gray-200 block">{slot.time}</span>
                        )}
                      </div>

                      {/* Icon Bullet */}
                      <div className={`w-8 h-8 rounded-xl border flex items-center justify-center shrink-0 ${
                        isBreak 
                          ? 'bg-blue-500/5 border-blue-500/10 text-blue-400' 
                          : slot.energyRequired === 'High' 
                          ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' 
                          : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                      }`}>
                        {isBreak ? <Heart className="w-3.5 h-3.5" /> : <Zap className="w-3.5 h-3.5" />}
                      </div>

                      {/* Title block */}
                      <div className="flex-grow min-w-0">
                        {isEditing ? (
                          <input
                            type="text"
                            value={slot.taskTitle}
                            onChange={(e) => updateSlotField(slot.id, 'taskTitle', e.target.value)}
                            className="bg-black/40 border border-gray-800 text-xs text-gray-200 px-2 py-1.5 rounded-lg w-full outline-none focus:border-amber-500/40 font-medium"
                          />
                        ) : (
                          <h5 className={`text-xs font-bold leading-normal truncate ${isBreak ? 'text-gray-400 font-medium italic' : 'text-gray-100'}`}>
                            {slot.taskTitle}
                          </h5>
                        )}
                        <span className="text-[10px] font-mono text-gray-500 block mt-0.5 uppercase tracking-wider font-bold">
                          {isBreak ? "Rest & Recovery" : "Task Block"}
                        </span>
                      </div>

                    </div>

                    {/* Right attributes controls */}
                    <div className="flex items-center justify-between sm:justify-end gap-4 w-full sm:w-auto pt-2.5 sm:pt-0 border-t border-gray-900/30 sm:border-0">
                      
                      {/* Duration control */}
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-gray-500" />
                        {isEditing ? (
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="5"
                              max="240"
                              value={slot.durationMinutes}
                              onChange={(e) => updateSlotField(slot.id, 'durationMinutes', Number(e.target.value))}
                              className="bg-black/60 border border-gray-800 text-xs font-mono text-gray-300 rounded px-1.5 py-0.5 outline-none focus:border-amber-500/40 w-12 text-center"
                            />
                            <span className="text-[10px] text-gray-500">min</span>
                          </div>
                        ) : (
                          <span className="font-mono text-xs text-gray-400 font-bold">{slot.durationMinutes} mins</span>
                        )}
                      </div>

                      {/* Energy tag */}
                      {!isEditing && (
                        <div className={`px-2 py-1 rounded-md text-[9px] font-mono font-bold uppercase tracking-wider ${
                          slot.energyRequired === 'High' 
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' 
                            : slot.energyRequired === 'Medium' 
                            ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' 
                            : 'bg-gray-800 text-gray-500 border border-gray-900'
                        }`}>
                          {slot.energyRequired} Focus
                        </div>
                      )}

                      {/* Delete button (Edit Mode Only) */}
                      {isEditing && (
                        <button
                          onClick={() => handleDeleteSlot(slot.id)}
                          className="p-1.5 rounded-lg border border-gray-800 bg-black/20 text-gray-500 hover:text-rose-400 hover:border-rose-500/30 transition-all cursor-pointer"
                          title="Remove block from schedule"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}

                    </div>

                  </div>
                );
              })}

            </div>

            {/* Advisory guidance footer */}
            <div className="p-4 bg-[#0a0a0c]/40 border border-gray-900 rounded-xl flex items-start gap-2.5 text-[11px] text-gray-500 leading-relaxed" id="planning-guidance-notice">
              <CheckCircle2 className="w-4 h-4 text-amber-500/40 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-gray-400">Tempo Lock Guidance:</span> Synchronizing this day plan will save the specified start times and durations directly onto your active tasks. This enables proper time-blocking tracking on your primary Workspace Plan and alerts you when tasks enter their respective focus frames.
              </div>
            </div>

          </div>
        )}
      </div>

    </div>
  );
};
