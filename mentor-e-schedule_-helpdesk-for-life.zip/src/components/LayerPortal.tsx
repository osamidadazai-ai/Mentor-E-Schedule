import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Compass, LayoutGrid } from 'lucide-react';

interface LayerPortalProps {
  onSubmit: (title: string, description: string, primaryGoal: string) => void;
  isAnalyzing: boolean;
  onViewBoard?: () => void;
}

export const LayerPortal: React.FC<LayerPortalProps> = ({ onSubmit, isAnalyzing, onViewBoard }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [primaryGoal, setPrimaryGoal] = useState(() => {
    return localStorage.getItem('mentor_schedule_primary_goal') || 'Achieve peak professional impact and reach key milestones';
  });
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('You must specify the name of the planned move/task.');
      return;
    }
    setError('');
    localStorage.setItem('mentor_schedule_primary_goal', primaryGoal.trim());
    onSubmit(title.trim(), description.trim(), primaryGoal.trim());
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.1 }}
      className="w-full max-w-lg mx-auto flex flex-col justify-center min-h-[60vh] px-4"
      id="layer-portal-container"
    >
      <div className="bg-[#0a0a0a] border-2 border-[#D4AF37]/25 rounded-3xl p-6 sm:p-10 shadow-[0_10px_50px_rgba(212,175,55,0.05)] relative overflow-hidden">
        {/* Subtle background golden glow */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/[0.02] rounded-full blur-3xl pointer-events-none"></div>

        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-amber-500/5 border border-amber-500/20 mb-3 text-[#D4AF37]">
            <Compass className="w-5 h-5 animate-spin" style={{ animationDuration: '30s' }} />
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl font-extrabold tracking-wider text-[#D4AF37] uppercase animate-pulse">
            Strategic Task Input
          </h2>
          <p className="font-serif text-[10.5px] text-amber-500/50 uppercase tracking-widest mt-1">
            Align new tasks with your strategic goals
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5" id="portal-task-form">
          <div>
            <label className="block font-mono text-[9.5px] font-bold text-amber-500/70 uppercase tracking-widest mb-2">
              Primary Strategic Goal
            </label>
            <input
              type="text"
              value={primaryGoal}
              onChange={(e) => setPrimaryGoal(e.target.value)}
              placeholder="e.g. Expand reach to 10k users & optimize core service blueprints"
              className="w-full bg-[#050507] border border-amber-500/20 focus:border-amber-500 text-gray-100 rounded-xl px-4 py-3.5 text-xs font-sans placeholder-gray-600 outline-none transition-all focus:shadow-[0_0_15px_rgba(245,158,11,0.08)]"
              disabled={isAnalyzing}
              id="portal-primary-goal-input"
            />
          </div>

          <div>
            <label className="block font-mono text-[9.5px] font-bold text-amber-500/70 uppercase tracking-widest mb-2">
              Task Title / Actionable Objective
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                if (error) setError('');
              }}
              placeholder="e.g. Conduct comprehensive benchmark evaluation of service pipeline"
              className="w-full bg-[#050507] border border-amber-500/20 focus:border-amber-500 text-gray-100 rounded-xl px-4 py-3.5 text-xs font-sans placeholder-gray-600 outline-none transition-all focus:shadow-[0_0_15px_rgba(245,158,11,0.08)]"
              disabled={isAnalyzing}
              autoFocus
              id="portal-task-title-input"
            />
            {error && (
              <p className="text-red-400 font-mono text-[10px] mt-2 uppercase tracking-wide">
                ⚠️ {error}
              </p>
            )}
          </div>

          <div>
            <label className="block font-mono text-[9.5px] font-bold text-amber-500/70 uppercase tracking-widest mb-2">
              How This Task Aligns with Your Goal (Optional)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Explain how this task drives progress towards your goal and why it matters..."
              rows={3}
              className="w-full bg-[#050507] border border-amber-500/20 focus:border-amber-500 text-gray-100 rounded-xl px-4 py-3 text-xs font-sans placeholder-gray-600 outline-none transition-all focus:shadow-[0_0_15px_rgba(245,158,11,0.08)] resize-none"
              disabled={isAnalyzing}
              id="portal-task-desc-input"
            />
          </div>

          <button
            type="submit"
            disabled={isAnalyzing}
            className="w-full bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 hover:brightness-110 active:scale-[0.99] disabled:opacity-50 text-black font-serif font-extrabold text-xs py-4 rounded-xl shadow-[0_4px_20px_rgba(245,158,11,0.15)] transition-all uppercase tracking-widest cursor-pointer flex items-center justify-center gap-2"
            id="portal-submit-btn"
          >
            {isAnalyzing ? (
              <>
                <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                <span>Analyzing alignment...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-black shrink-0" />
                <span>Analyze Strategic Alignment</span>
              </>
            )}
          </button>
        </form>

        {onViewBoard && (
          <div className="mt-6 border-t border-amber-500/10 pt-5 flex justify-center">
            <button
              onClick={onViewBoard}
              type="button"
              className="font-mono text-[10px] text-amber-500/60 hover:text-amber-400 uppercase tracking-widest flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              Skip to Workspace Dashboard
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
};
