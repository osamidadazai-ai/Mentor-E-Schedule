import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, Zap, Sparkles, RefreshCw, Trash2, Clock, AlertCircle, CheckCircle, HelpCircle } from 'lucide-react';
import { Task } from '../types';

interface LayerSaboteurProps {
  task: Task;
  onAcknowledge: (action: 'recover' | 'delete') => void;
}

interface BlunderAnalysis {
  laughterMockery: string; // Used as the warm, supportive reassurance
  postMortem: string;      // The objective roadblock analysis
  tacticalAdjustment: string; // The practical advice
  nextBestMove: string;    // Actionable bite-sized next step
}

export const LayerSaboteur: React.FC<LayerSaboteurProps> = ({ task, onAcknowledge }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(true);
  const [error, setError] = useState('');
  const [analysis, setAnalysis] = useState<BlunderAnalysis | null>(null);
  const [selectedFriction, setSelectedFriction] = useState<string>('');
  const [reflectionStep, setReflectionStep] = useState<'friction' | 'analysis'>('friction');
  const [customSubtasks, setCustomSubtasks] = useState<{ sub1: string; sub2: string } | null>(null);
  const [showRescheduledToast, setShowRescheduledToast] = useState(false);

  const frictionOptions = [
    { id: 'overwhelmed', label: 'Overwhelmed (Scope was too big)', detail: 'The task felt too large or complex to start.' },
    { id: 'time', label: 'Lack of Time (Busy schedule)', detail: 'Other urgent priorities pushed this task aside.' },
    { id: 'info', label: 'Missing Info (Ambiguous goals)', detail: 'I was not fully clear on what the first step was.' },
    { id: 'energy', label: 'Low Energy (Burnout/fatigue)', detail: 'My physical or mental reserves were depleted.' }
  ];

  const handleFetchReview = async () => {
    try {
      setIsAnalyzing(true);
      setError('');
      
      const response = await fetch('/api/coach/analyze-blunder', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title: task.title,
          description: task.description,
          primaryGoal: task.primaryGoal || 'Achieve high-impact goals',
          rank: task.rank || 'King',
          friction: selectedFriction
        })
      });

      if (!response.ok) {
        throw new Error('Failed to retrieve post-mortem assessment');
      }

      const data = await response.json();
      setAnalysis(data);
      setReflectionStep('analysis');
    } catch (err: any) {
      console.warn('Post-mortem fallback triggered:', err);
      setAnalysis({
        laughterMockery: "Take a breath. Stalling on high-priority items is a completely normal part of managing progress. Let's analyze this calmly and get back on track.",
        postMortem: `Failing to complete "${task.title}" usually indicates that the scope was too broad or other urgent matters overallocated your focus blocks today.`,
        tacticalAdjustment: "Isolate this item. Let's reduce execution friction by simplifying its parameters and scheduling a dedicated focus block.",
        nextBestMove: "Spend exactly 5 to 10 minutes right now taking the absolute smallest, easiest next step of this task."
      });
      setReflectionStep('analysis');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleDivideConquer = () => {
    // Generate 2 simplified sub-tasks
    const cleanTitle = task.title.replace(/Deploy|Architect|Build|Write|Implement/gi, '').trim();
    setCustomSubtasks({
      sub1: `Outline first draft/notes for: ${cleanTitle}`,
      sub2: `Identify and complete the easiest 5-minute action for: ${cleanTitle}`
    });
  };

  const handleReschedule = () => {
    setShowRescheduledToast(true);
    setTimeout(() => {
      setShowRescheduledToast(false);
    }, 4000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ duration: 0.25 }}
      className="w-full max-w-3xl mx-auto px-4"
      id="reflection-panel-container"
    >
      <div className="bg-[#0b0c10] border border-amber-500/20 rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(212,175,55,0.05)] relative overflow-hidden flex flex-col gap-6">
        
        {/* Decorative Calming Ambient Background Lines */}
        <div className="absolute top-0 left-0 w-64 h-64 bg-amber-500/[0.02] rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-emerald-500/[0.02] rounded-full blur-3xl pointer-events-none"></div>

        {/* HEADER BAR */}
        <div className="flex items-center justify-between border-b border-gray-800 pb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 rounded-xl">
              <Shield className="w-5 h-5 text-amber-500" />
            </div>
            <div>
              <h3 className="font-serif text-xl sm:text-2xl font-bold text-gray-100">
                Reflection & Recovery Plan
              </h3>
              <p className="text-[11px] text-gray-500">
                Setbacks are data. Let's adjust and find the strongest next step.
              </p>
            </div>
          </div>
          <span className="bg-amber-500/10 border border-amber-500/20 text-amber-400 font-mono text-[9px] px-2.5 py-1 rounded-full uppercase tracking-wider font-bold">
            Priority Analysis
          </span>
        </div>

        {/* ACTIVE TASK CONTEXT CARD */}
        <div className="bg-[#12131a] border border-gray-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${task.rank === 'King' ? 'bg-red-500' : 'bg-amber-500'}`} />
              <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest font-bold">
                Deferred Task • Priority: {task.rank === 'King' ? 'Critical' : task.rank === 'Queen' ? 'High' : task.rank === 'Rook' ? 'Medium' : 'Low'}
              </span>
            </div>
            <h4 className="font-sans font-bold text-sm text-gray-200">{task.title}</h4>
            {task.description && (
              <p className="text-[11px] text-gray-500 italic font-sans">"{task.description}"</p>
            )}
          </div>
        </div>

        <AnimatePresence mode="wait">
          {reflectionStep === 'friction' ? (
            <motion.div
              key="friction-step"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-5"
            >
              <div className="space-y-2">
                <h4 className="font-sans font-bold text-sm text-gray-200 flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-amber-500" />
                  What was the primary friction point that blocked this task?
                </h4>
                <p className="text-[11px] text-gray-500">
                  Identifying the specific source of friction helps the advisor tailor the recovery roadmap.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {frictionOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setSelectedFriction(opt.id)}
                    className={`p-4 rounded-xl border text-left cursor-pointer transition-all ${
                      selectedFriction === opt.id
                        ? 'bg-amber-500/[0.06] border-amber-500 text-amber-300'
                        : 'bg-black/30 border-gray-800 text-gray-400 hover:border-gray-700'
                    }`}
                  >
                    <div className="font-sans font-bold text-xs">{opt.label}</div>
                    <div className="text-[10px] text-gray-500 mt-1">{opt.detail}</div>
                  </button>
                ))}
              </div>

              <button
                onClick={handleFetchReview}
                disabled={!selectedFriction}
                className="w-full bg-[#d4af37] hover:brightness-110 disabled:opacity-40 text-black font-sans font-black text-xs py-4 rounded-xl uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-2 mt-4"
              >
                <span>Begin Calm Review</span>
                <Clock className="w-4 h-4" />
              </button>
            </motion.div>
          ) : (
            <motion.div
              key="analysis-step"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              {isAnalyzing ? (
                <div className="py-12 flex flex-col items-center justify-center gap-3">
                  <RefreshCw className="w-7 h-7 text-amber-500 animate-spin" />
                  <p className="font-mono text-gray-500 text-[10px] uppercase tracking-widest animate-pulse">
                    Generating Supportive Roadmaps...
                  </p>
                </div>
              ) : (
                <div className="space-y-6 text-left">
                  {/* Reassuring commentary block */}
                  <div className="bg-amber-500/[0.03] border border-amber-500/15 rounded-2xl p-5">
                    <p className="text-xs text-amber-200/90 leading-relaxed font-serif italic">
                      "{analysis?.laughterMockery}"
                    </p>
                  </div>

                  {/* Core post-mortem columns */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
                    <div className="space-y-2 bg-[#12131a] border border-gray-800 p-4.5 rounded-2xl">
                      <h5 className="font-sans font-bold text-xs text-amber-400 flex items-center gap-1.5 uppercase tracking-wider">
                        <AlertCircle className="w-4 h-4" />
                        Roadblock Assessment
                      </h5>
                      <p className="text-[11px] text-gray-400 leading-relaxed">
                        {analysis?.postMortem}
                      </p>
                    </div>

                    <div className="space-y-2 bg-[#12131a] border border-gray-800 p-4.5 rounded-2xl">
                      <h5 className="font-sans font-bold text-xs text-green-400 flex items-center gap-1.5 uppercase tracking-wider">
                        <Sparkles className="w-4 h-4" />
                        Recommended Next Step
                      </h5>
                      <p className="text-[11px] text-gray-400 leading-relaxed">
                        {analysis?.tacticalAdjustment}
                      </p>
                    </div>
                  </div>

                  {/* Highlighted minimal next step */}
                  <div className="bg-emerald-500/[0.04] p-4.5 rounded-2xl border border-emerald-500/25 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="space-y-1 flex-grow">
                      <span className="text-[8px] font-mono text-emerald-400 uppercase tracking-widest font-black block">
                        Quickest Path to Momentum
                      </span>
                      <p className="text-[12px] text-emerald-100 font-semibold leading-relaxed">
                        {analysis?.nextBestMove}
                      </p>
                    </div>
                  </div>

                  {/* Divide & Conquer custom generated output */}
                  {customSubtasks && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="bg-sky-500/[0.03] border border-sky-500/20 p-4.5 rounded-2xl space-y-3"
                    >
                      <h5 className="font-sans font-bold text-xs text-sky-400 uppercase tracking-wider flex items-center gap-1.5">
                        <CheckCircle className="w-4 h-4" />
                        Decomposed Sub-tasks
                      </h5>
                      <div className="space-y-2 text-xs">
                        <div className="bg-black/40 p-2.5 rounded-xl border border-gray-800 flex items-start gap-2.5">
                          <span className="bg-sky-500/10 text-sky-400 font-mono text-[9px] px-2 py-0.5 rounded font-black">1</span>
                          <span className="text-gray-300 font-sans">{customSubtasks.sub1}</span>
                        </div>
                        <div className="bg-black/40 p-2.5 rounded-xl border border-gray-800 flex items-start gap-2.5">
                          <span className="bg-sky-500/10 text-sky-400 font-mono text-[9px] px-2 py-0.5 rounded font-black">2</span>
                          <span className="text-gray-300 font-sans">{customSubtasks.sub2}</span>
                        </div>
                      </div>
                      <p className="text-[10px] text-gray-500 italic">
                        These sub-tasks have been structured to drastically lower starting friction.
                      </p>
                    </motion.div>
                  )}

                  {/* TOAST NOTIFICATION */}
                  {showRescheduledToast && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-amber-500/10 border border-amber-500/30 p-3 rounded-xl text-center text-xs text-amber-300"
                    >
                      📅 Slot Allocated: Added a supportive 15-minute slot in your local calendar.
                    </motion.div>
                  )}

                  {/* CONSTRUCTIVE ACTION PLATFORM */}
                  <div className="space-y-3 pt-3 border-t border-gray-800">
                    <div className="text-[10px] text-gray-500 font-mono uppercase tracking-widest text-center">
                      Select Recovery Action
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <button
                        onClick={handleDivideConquer}
                        className="py-3 bg-sky-950/20 hover:bg-sky-950/40 border border-sky-500/30 text-sky-400 font-sans font-bold text-[10px] rounded-xl uppercase tracking-widest cursor-pointer transition-all flex items-center justify-center gap-1.5"
                      >
                        <Zap className="w-3.5 h-3.5" />
                        Divide & Conquer
                      </button>

                      <button
                        onClick={handleReschedule}
                        className="py-3 bg-amber-950/20 hover:bg-amber-950/40 border border-amber-500/30 text-amber-400 font-sans font-bold text-[10px] rounded-xl uppercase tracking-widest cursor-pointer transition-all flex items-center justify-center gap-1.5"
                      >
                        <Clock className="w-3.5 h-3.5" />
                        Allocate 15m Block
                      </button>

                      <button
                        onClick={() => onAcknowledge('recover')}
                        className="py-3 bg-[#d4af37] hover:brightness-110 text-black font-sans font-extrabold text-[10px] rounded-xl uppercase tracking-widest cursor-pointer transition-all flex items-center justify-center gap-1.5"
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                        Acknowledge & Save
                      </button>
                    </div>

                    <div className="flex justify-center pt-2">
                      <button
                        onClick={() => onAcknowledge('delete')}
                        className="text-gray-500 hover:text-red-400 font-mono text-[9px] uppercase tracking-widest cursor-pointer flex items-center gap-1 transition-all"
                      >
                        <Trash2 className="w-3 h-3" />
                        Discard and remove from list
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </motion.div>
  );
};
