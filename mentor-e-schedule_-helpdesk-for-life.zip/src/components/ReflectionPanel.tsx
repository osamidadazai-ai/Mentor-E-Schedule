import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldAlert, 
  HelpCircle, 
  Brain, 
  Sparkles, 
  Check, 
  Clock, 
  Trash2, 
  ArrowRight, 
  History, 
  Heart, 
  Compass, 
  TrendingUp, 
  AlertCircle,
  Undo2,
  CalendarCheck
} from 'lucide-react';
import { useProductivityStore, StoreTask, ReflectionRecord } from '../stores/useProductivityStore';

export const ReflectionPanel: React.FC = () => {
  const { tasks, reflections, addReflection, deleteReflection, updateTask, completeTask } = useProductivityStore();

  // Active uncompleted tasks to choose from
  const activeTasks = tasks.filter(t => !t.completed);

  // Core component states
  const [selectedTaskId, setSelectedTaskId] = useState<string>('');
  const [customTaskTitle, setCustomTaskTitle] = useState<string>('');
  
  const [selectedBlocker, setSelectedBlocker] = useState<'Lack of Time' | 'Low Energy' | 'Missing Information' | 'Priority Changed' | 'Unexpected Event' | null>(null);
  
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [showToast, setShowToast] = useState<string | null>(null);
  const [activeStep, setActiveStep] = useState<'select' | 'blocker' | 'result' | 'history'>('select');

  // Completed reflection outcome
  const [currentResult, setCurrentResult] = useState<{
    taskTitle: string;
    blocker: 'Lack of Time' | 'Low Energy' | 'Missing Information' | 'Priority Changed' | 'Unexpected Event';
    recoveryInsight: string;
    recommendedNextStep: string;
    suggestedAction: string;
  } | null>(null);

  const blockerOptions = [
    { 
      id: 'Lack of Time' as const, 
      label: 'Lack of Time', 
      detail: 'Busy schedule or overallocated time windows' 
    },
    { 
      id: 'Low Energy' as const, 
      label: 'Low Energy', 
      detail: 'Mental fatigue, physical depletion, or low motivation' 
    },
    { 
      id: 'Missing Information' as const, 
      label: 'Missing Information', 
      detail: 'Ambiguity, lack of clarity, or missing inputs' 
    },
    { 
      id: 'Priority Changed' as const, 
      label: 'Priority Changed', 
      detail: 'Shifting priorities or more urgent strategic requirements' 
    },
    { 
      id: 'Unexpected Event' as const, 
      label: 'Unexpected Event', 
      detail: 'Ad-hoc disruptions, emergencies, or sudden context-switches' 
    }
  ];

  // Offline recovery logic generator
  const getHeuristicRecovery = (
    title: string, 
    blocker: 'Lack of Time' | 'Low Energy' | 'Missing Information' | 'Priority Changed' | 'Unexpected Event'
  ) => {
    switch (blocker) {
      case 'Lack of Time':
        return {
          recoveryInsight: "Time constraints represent classic scheduling congestion. Often, we underestimate setup periods or fail to defend deep-focus boundaries. Acknowledge that time is finite and realign your schedule calmly.",
          recommendedNextStep: "Schedule exactly 15 minutes tomorrow dedicated purely to starting the task. Defend this small slot aggressively.",
          suggestedAction: "Schedule 15 minutes tomorrow"
        };
      case 'Low Energy':
        return {
          recoveryInsight: "Energy is the ultimate currency of productivity. Working during mental depletion creates resistance and triggers avoidance behaviors. Recognizing your baseline state is a strategic victory, not a tactical failure.",
          recommendedNextStep: "Reduce the initial cognitive friction by breaking this task down. Focus only on the absolute simplest action, or move it to next week.",
          suggestedAction: "Break task into smaller parts"
        };
      case 'Missing Information':
        return {
          recoveryInsight: "Ambiguity is the absolute enemy of motivation. When the parameters of a task are vague, our brain naturally seeks safer, more structured alternatives. Defining boundaries restores confidence.",
          recommendedNextStep: "Isolate the single, most critical question that needs answering, and allocate 10 minutes purely to clearing up that specific roadblock.",
          suggestedAction: "Remove unnecessary complexity"
        };
      case 'Priority Changed':
        return {
          recoveryInsight: "A fluid board is the sign of high-level strategy. Reallocating attention away from static tasks toward superior, high-leverage coordinates is a logical decision. Let go of past plans with absolute confidence.",
          recommendedNextStep: "Reschedule this task for next week to maintain a clean workspace focus, or simplify its scope so it aligns with your updated target roadmap.",
          suggestedAction: "Move task to next week"
        };
      case 'Unexpected Event':
        return {
          recoveryInsight: "Unpredictable friction is a law of physics. Sudden context shifts or urgent disruptions require a flexible posture. Accept the detour and regain your primary trajectory with poise.",
          recommendedNextStep: "Perform a gentle reset. Establish a fresh, comfortable focus slot tomorrow to tackle this item when the environment has stabilized.",
          suggestedAction: "Schedule 15 minutes tomorrow"
        };
    }
  };

  const handleBeginReflection = () => {
    if (!selectedTaskId && !customTaskTitle.trim()) {
      triggerToast("Please choose a task or enter a custom scenario.");
      return;
    }
    setActiveStep('blocker');
  };

  const handleGenerateReflection = async () => {
    if (!selectedBlocker) {
      triggerToast("Please choose your main blocker.");
      return;
    }

    setIsLoading(true);

    const taskTitle = selectedTaskId 
      ? activeTasks.find(t => t.id === selectedTaskId)?.title || 'Selected Move'
      : customTaskTitle.trim();

    try {
      // First try calling the server API
      const response = await fetch('/api/coach/analyze-blunder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: taskTitle,
          description: selectedTaskId ? activeTasks.find(t => t.id === selectedTaskId)?.description : '',
          friction: selectedBlocker
        })
      });

      if (!response.ok) {
        throw new Error("Server returned non-ok status");
      }

      const data = await response.json();
      
      const resultData = {
        taskTitle,
        blocker: selectedBlocker,
        recoveryInsight: data.laughterMockery || data.postMortem || getHeuristicRecovery(taskTitle, selectedBlocker).recoveryInsight,
        recommendedNextStep: data.nextBestMove || getHeuristicRecovery(taskTitle, selectedBlocker).recommendedNextStep,
        suggestedAction: data.tacticalAdjustment || getHeuristicRecovery(taskTitle, selectedBlocker).suggestedAction
      };

      setCurrentResult(resultData);
      
      // Zustand Integration: Persist the reflection record
      addReflection({
        taskId: selectedTaskId || undefined,
        taskTitle,
        blocker: selectedBlocker,
        recoveryInsight: resultData.recoveryInsight,
        recommendedNextStep: resultData.recommendedNextStep,
        suggestedAction: resultData.suggestedAction
      });

      setActiveStep('result');
      triggerToast("Reflection logged. Recovery path generated.");
    } catch (err) {
      console.warn("AI reflection service unavailable. Using local heuristic fallback.", err);
      
      const fallback = getHeuristicRecovery(taskTitle, selectedBlocker);
      const resultData = {
        taskTitle,
        blocker: selectedBlocker,
        recoveryInsight: fallback.recoveryInsight,
        recommendedNextStep: fallback.recommendedNextStep,
        suggestedAction: fallback.suggestedAction
      };

      setCurrentResult(resultData);

      // Zustand Integration: Persist the reflection record
      addReflection({
        taskId: selectedTaskId || undefined,
        taskTitle,
        blocker: selectedBlocker,
        recoveryInsight: resultData.recoveryInsight,
        recommendedNextStep: resultData.recommendedNextStep,
        suggestedAction: resultData.suggestedAction
      });

      setActiveStep('result');
      triggerToast("Reflection logged offline. Recovery path generated.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyActionPlan = () => {
    if (!currentResult) return;

    // Apply scheduled updates based on selected action plan
    if (selectedTaskId) {
      const action = currentResult.suggestedAction.toLowerCase();
      
      if (action.includes("smaller") || action.includes("complexity")) {
        // Break down
        updateTask(selectedTaskId, {
          title: `[Simplified] ${currentResult.taskTitle}`,
          description: `Focus step: ${currentResult.recommendedNextStep}`
        });
      } else if (action.includes("schedule") || action.includes("15 minutes") || action.includes("tomorrow")) {
        // Assign tomorrow's date
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const tomorrowStr = tomorrow.toISOString().split('T')[0];
        updateTask(selectedTaskId, {
          dueDate: tomorrowStr,
          durationMinutes: 15
        });
      } else if (action.includes("next week") || action.includes("move")) {
        // Push due date by 7 days
        const nextWeek = new Date();
        nextWeek.setDate(nextWeek.getDate() + 7);
        const nextWeekStr = nextWeek.toISOString().split('T')[0];
        updateTask(selectedTaskId, {
          dueDate: nextWeekStr
        });
      }
    }

    triggerToast("Strategic task board synchronized with recovery plan!");
    setActiveStep('select');
    setSelectedTaskId('');
    setCustomTaskTitle('');
    setSelectedBlocker(null);
    setCurrentResult(null);
  };

  const handleDiscardTask = () => {
    if (selectedTaskId) {
      updateTask(selectedTaskId, { completed: true });
      triggerToast("Task marked completed or archived.");
    }
    setActiveStep('select');
    setSelectedTaskId('');
    setCustomTaskTitle('');
    setSelectedBlocker(null);
    setCurrentResult(null);
  };

  const triggerToast = (msg: string) => {
    setShowToast(msg);
    setTimeout(() => setShowToast(null), 3000);
  };

  const renderFrictionSelection = () => (
    <div className="space-y-6">
      <div className="space-y-1">
        <h4 className="font-serif text-sm font-bold text-gray-200 flex items-center gap-2">
          <Compass className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Step 1: Choose a Target of Reflection</span>
        </h4>
        <p className="text-xs text-gray-500">
          Select an uncompleted move or type a custom scenario that encountered friction.
        </p>
      </div>

      <div className="space-y-4">
        {activeTasks.length > 0 && (
          <div className="space-y-2">
            <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-500">
              Active Strategic Tasks
            </label>
            <div className="relative">
              <select
                value={selectedTaskId}
                onChange={(e) => {
                  setSelectedTaskId(e.target.value);
                  setCustomTaskTitle('');
                }}
                className="w-full bg-black/40 border border-gray-800 hover:border-gray-700 focus:border-amber-500/40 focus:bg-black/60 rounded-xl px-4 py-3 text-xs text-gray-200 outline-none transition-all appearance-none cursor-pointer"
                id="reflection-task-selector"
              >
                <option value="">-- Choose from active board moves --</option>
                {activeTasks.map((t) => (
                  <option key={t.id} value={t.id}>
                    [{t.priority}] {t.title}
                  </option>
                ))}
              </select>
              <div className="absolute right-4 top-3.5 pointer-events-none text-gray-500 text-xs">▼</div>
            </div>
          </div>
        )}

        <div className="space-y-2">
          <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-500 block">
            Or: Input a Custom Event / Challenge
          </label>
          <input
            type="text"
            placeholder="e.g., Drafting the project architecture document"
            value={customTaskTitle}
            onChange={(e) => {
              setCustomTaskTitle(e.target.value);
              setSelectedTaskId('');
            }}
            className="w-full bg-black/40 border border-gray-800 hover:border-gray-700 focus:border-amber-500/40 focus:bg-black/60 rounded-xl px-4 py-3 text-xs text-gray-200 outline-none transition-all"
            id="reflection-custom-input"
          />
        </div>
      </div>

      <button
        onClick={handleBeginReflection}
        className="w-full py-3.5 bg-gray-800 hover:bg-gray-750 text-gray-200 border border-gray-700/60 font-bold text-xs rounded-xl cursor-pointer transition-all flex items-center justify-center gap-1.5 active:scale-[0.99]"
        id="reflection-step1-btn"
      >
        <span>Identify Blocker</span>
        <ArrowRight className="w-3.5 h-3.5" />
      </button>
    </div>
  );

  const renderBlockerQuestion = () => {
    const taskName = selectedTaskId 
      ? activeTasks.find(t => t.id === selectedTaskId)?.title || 'Target Task'
      : customTaskTitle;

    return (
      <div className="space-y-6">
        <div className="space-y-1">
          <div className="flex justify-between items-center">
            <span className="text-[9px] font-mono text-amber-500 font-bold uppercase tracking-widest">Active Reflection</span>
            <button 
              onClick={() => setActiveStep('select')}
              className="text-[10px] font-mono text-gray-500 hover:text-gray-300 flex items-center gap-1 cursor-pointer"
            >
              <Undo2 className="w-3 h-3" /> Back
            </button>
          </div>
          <h4 className="font-serif text-sm font-bold text-gray-200">
            Evaluating: <span className="text-amber-400">"{taskName}"</span>
          </h4>
          <p className="text-xs text-gray-500 mt-1">
            What was the main blocker?
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3" id="blocker-options-grid">
          {blockerOptions.map((opt) => {
            const isSelected = selectedBlocker === opt.id;
            return (
              <button
                key={opt.id}
                onClick={() => setSelectedBlocker(opt.id)}
                className={`p-4 rounded-xl border text-left cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-amber-500/[0.06] border-amber-500 text-amber-300'
                    : 'bg-black/30 border-gray-800 text-gray-400 hover:border-gray-700'
                }`}
                id={`blocker-option-${opt.id.replace(/\s+/g, '-').toLowerCase()}`}
              >
                <div className="font-sans font-bold text-xs flex items-center gap-2">
                  <span className={`w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-amber-400' : 'bg-gray-600'}`} />
                  {opt.label}
                </div>
                <div className="text-[10px] text-gray-500 mt-1">{opt.detail}</div>
              </button>
            );
          })}
        </div>

        <button
          onClick={handleGenerateReflection}
          disabled={!selectedBlocker || isLoading}
          className="w-full py-3.5 bg-amber-500 hover:bg-amber-450 text-black font-extrabold text-xs rounded-xl cursor-pointer transition-all flex items-center justify-center gap-1.5 shadow-[0_2px_15px_rgba(245,158,11,0.15)] disabled:opacity-50 active:scale-[0.99]"
          id="reflection-generate-btn"
        >
          {isLoading ? (
            <>
              <Brain className="w-3.5 h-3.5 animate-spin" />
              <span>Generating supportive insights...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-3.5 h-3.5" />
              <span>Calibrate Recovery Path</span>
            </>
          )}
        </button>
      </div>
    );
  };

  const renderResultInsight = () => {
    if (!currentResult) return null;

    return (
      <div className="space-y-6" id="reflection-result-workspace">
        <div className="space-y-1">
          <span className="text-[9px] font-mono text-emerald-400 font-bold uppercase tracking-widest">Strategic Insight Ready</span>
          <h4 className="font-serif text-sm font-bold text-gray-200">
            Roadmap for: <span className="text-amber-400">"{currentResult.taskTitle}"</span>
          </h4>
        </div>

        {/* RECOVERY INSIGHT */}
        <div className="bg-[#12131a] border border-gray-800 p-5 rounded-2xl space-y-2 relative overflow-hidden">
          <div className="absolute right-0 top-0 w-32 h-32 bg-emerald-500/[0.02] rounded-full blur-xl pointer-events-none" />
          
          <div className="flex items-center gap-2 text-[10px] font-mono text-emerald-400 uppercase tracking-wider font-bold">
            <Heart className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Recovery Insight</span>
          </div>
          <p className="text-xs text-gray-300 leading-relaxed font-sans">
            {currentResult.recoveryInsight}
          </p>
        </div>

        {/* NEXT STEPS & SUGGESTED ACTION */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          <div className="bg-[#12131a] border border-gray-800 p-4 rounded-xl space-y-1.5">
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-amber-400 uppercase tracking-wider font-bold">
              <Clock className="w-3.5 h-3.5" />
              <span>Recommended Next Step</span>
            </div>
            <p className="text-xs text-gray-300 leading-relaxed">
              {currentResult.recommendedNextStep}
            </p>
          </div>

          <div className="bg-[#12131a] border border-gray-800 p-4 rounded-xl space-y-1.5">
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-purple-400 uppercase tracking-wider font-bold">
              <CalendarCheck className="w-3.5 h-3.5 text-purple-400" />
              <span>Suggested Action</span>
            </div>
            <p className="text-xs text-gray-300 font-bold leading-relaxed">
              {currentResult.suggestedAction}
            </p>
          </div>

        </div>

        {/* DECISION PLATFORM */}
        <div className="pt-4 border-t border-gray-800 space-y-3">
          <div className="text-[10px] text-gray-500 font-mono uppercase tracking-widest text-center">
            Synchronize Action Options
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={handleApplyActionPlan}
              className="py-3 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-[11px] uppercase tracking-wider rounded-xl cursor-pointer transition-all flex items-center justify-center gap-1.5 shadow-[0_2px_15px_rgba(16,185,129,0.15)]"
              id="reflection-apply-plan-btn"
            >
              <Check className="w-3.5 h-3.5 stroke-[3]" />
              <span>Apply Recommended Action</span>
            </button>

            <button
              onClick={() => setActiveStep('select')}
              className="py-3 bg-gray-850 hover:bg-gray-800 text-gray-300 border border-gray-800 font-bold text-[11px] uppercase tracking-wider rounded-xl cursor-pointer transition-all flex items-center justify-center gap-1.5"
              id="reflection-cancel-btn"
            >
              <span>Back to Selection</span>
            </button>
          </div>

          {selectedTaskId && (
            <div className="flex justify-center pt-1">
              <button
                onClick={handleDiscardTask}
                className="text-gray-500 hover:text-rose-400 font-mono text-[9px] uppercase tracking-widest cursor-pointer flex items-center gap-1 transition-all"
                id="reflection-archive-btn"
              >
                <Trash2 className="w-3 h-3" />
                Discard task and remove from active matrix
              </button>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderReflectionHistory = () => {
    const records = reflections || [];

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="space-y-1">
            <h4 className="font-serif text-sm font-bold text-gray-200">Reflection Logbook</h4>
            <p className="text-xs text-gray-500">Review your past growth notes and friction mitigations.</p>
          </div>
          <button
            onClick={() => setActiveStep('select')}
            className="px-3 py-1.5 text-xs bg-black/25 border border-gray-800 hover:border-gray-700 text-gray-400 hover:text-gray-200 rounded-xl cursor-pointer"
          >
            New Reflection
          </button>
        </div>

        {records.length === 0 ? (
          <div className="py-12 text-center text-gray-600 text-xs">
            No logged reflections yet. Complete a reflection to begin tracking roadblocks.
          </div>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto pr-1" id="reflection-history-list">
            {records.map((rec) => (
              <div 
                key={rec.id}
                className="p-4 bg-black/20 border border-gray-900 rounded-xl space-y-2 relative"
              >
                <button
                  onClick={() => {
                    deleteReflection(rec.id);
                    triggerToast("Reflection entry deleted.");
                  }}
                  className="absolute right-3 top-3.5 p-1 text-gray-600 hover:text-rose-400 rounded transition-all cursor-pointer"
                  title="Delete log entry"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>

                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 text-[8px] font-mono font-bold uppercase tracking-wider">
                      {rec.blocker}
                    </span>
                    <span className="text-[9px] font-mono text-gray-600">
                      {new Date(rec.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <h5 className="text-xs font-bold text-gray-300">"{rec.taskTitle}"</h5>
                </div>

                <div className="border-t border-gray-900/60 pt-2 space-y-1.5">
                  <p className="text-[11px] text-gray-400 leading-relaxed italic">
                    "{rec.recoveryInsight}"
                  </p>
                  <div className="text-[10px] text-gray-500 flex items-center gap-1.5">
                    <span className="font-bold text-amber-500/70 uppercase">Next Step:</span>
                    <span>{rec.recommendedNextStep}</span>
                  </div>
                </div>

              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="bg-[#12131a] border border-gray-800/80 rounded-2xl overflow-hidden shadow-2xl font-sans text-gray-200" id="reflection-panel-root">
      
      {/* HEADER BAR */}
      <div className="p-6 border-b border-gray-800/60 bg-black/20 flex justify-between items-center gap-4 relative overflow-hidden">
        {/* Decorative calm background lights */}
        <div className="absolute left-0 top-0 w-32 h-32 bg-emerald-500/[0.02] rounded-full blur-2xl pointer-events-none" />
        
        <div className="space-y-1 z-10">
          <div className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-amber-400 shrink-0" />
            <h3 className="font-serif text-base font-bold text-gray-100">Advisor Reflection & Recovery</h3>
          </div>
          <p className="text-xs text-gray-400 leading-relaxed">
            Convert stalled goals or unexpected blockages into highly structured tactical recoveries. Setbacks are just data.
          </p>
        </div>

        {/* Log button */}
        <button
          onClick={() => setActiveStep(activeStep === 'history' ? 'select' : 'history')}
          className="px-3.5 py-2 rounded-xl bg-black/40 border border-gray-800 hover:border-gray-700 text-xs font-bold text-gray-400 hover:text-gray-200 flex items-center gap-1.5 shrink-0 cursor-pointer z-10"
          id="toggle-reflection-history-btn"
        >
          <History className="w-3.5 h-3.5" />
          <span>{activeStep === 'history' ? 'New Reflection' : 'History Log'}</span>
        </button>
      </div>

      {/* TOAST PANEL */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mx-6 mt-6 p-3 bg-emerald-950/20 border border-emerald-500/20 text-emerald-300 text-xs rounded-xl flex items-center gap-2"
            id="reflection-toast"
          >
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{showToast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* STEP DISPLAY COMPARTMENT */}
      <div className="p-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeStep}
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.2 }}
          >
            {activeStep === 'select' && renderFrictionSelection()}
            {activeStep === 'blocker' && renderBlockerQuestion()}
            {activeStep === 'result' && renderResultInsight()}
            {activeStep === 'history' && renderReflectionHistory()}
          </motion.div>
        </AnimatePresence>
      </div>

    </div>
  );
};
