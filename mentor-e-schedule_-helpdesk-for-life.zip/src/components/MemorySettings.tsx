import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Brain, 
  Target, 
  Briefcase, 
  MessageSquare, 
  Activity, 
  RotateCcw, 
  Check, 
  ShieldCheck, 
  Info
} from 'lucide-react';
import { useProductivityStore, CoachMemorySettings } from '../stores/useProductivityStore';

export const MemorySettings: React.FC = () => {
  const { coachMemorySettings, updateCoachMemorySettings } = useProductivityStore();
  const [showSavedToast, setShowSavedToast] = useState(false);

  const toggleSetting = (key: keyof CoachMemorySettings) => {
    const currentValue = coachMemorySettings[key];
    updateCoachMemorySettings({ [key]: !currentValue });
    
    // Trigger auto-save visual indicator
    setShowSavedToast(true);
    const timer = setTimeout(() => setShowSavedToast(false), 2000);
    return () => clearTimeout(timer);
  };

  const handleReset = () => {
    if (window.confirm("Are you sure you want to restore mentor memory preferences to default states?")) {
      updateCoachMemorySettings({
        rememberGoals: true,
        rememberProjects: true,
        rememberDiscussions: true,
        rememberStyle: true
      });
      setShowSavedToast(true);
      setTimeout(() => setShowSavedToast(false), 2000);
    }
  };

  const settingsItems = [
    {
      key: 'rememberGoals' as keyof CoachMemorySettings,
      label: 'Remember Strategic Goals',
      description: 'Retains your primary career and performance objectives, ensuring every scheduling block aligned or suggested remains focused on your absolute win conditions.',
      icon: Target,
      accentColor: 'text-amber-400 bg-amber-400/10 border-amber-500/20'
    },
    {
      key: 'rememberProjects' as keyof CoachMemorySettings,
      label: 'Remember Active Projects',
      description: 'Remembers specific sub-tasks, board layout decisions, and backlog priorities. Avoids re-explaining context when requesting technical plan reviews.',
      icon: Briefcase,
      accentColor: 'text-blue-400 bg-blue-400/10 border-blue-500/20'
    },
    {
      key: 'rememberDiscussions' as keyof CoachMemorySettings,
      label: 'Remember Strategic Discussions',
      description: 'Caches prior advice, frustrations shared, and core mindset adjustments made with the mentor. Ensures conversation history is synthesized and respected.',
      icon: MessageSquare,
      accentColor: 'text-[#D4AF37] bg-[#D4AF37]/10 border-[#D4AF37]/20'
    },
    {
      key: 'rememberStyle' as keyof CoachMemorySettings,
      label: 'Remember Working Pace',
      description: 'Tracks and adapts to your peak working hours, momentum shifts, fatigue thresholds, and preferred daily tempos for tailored time-locking and advice.',
      icon: Activity,
      accentColor: 'text-emerald-400 bg-emerald-400/10 border-emerald-500/20'
    }
  ];

  return (
    <div className="bg-[#12131a] border border-gray-800/80 rounded-2xl overflow-hidden shadow-2xl font-sans" id="mentor-memory-settings-container">
      {/* Header section with instructions */}
      <div className="p-6 border-b border-gray-800/60 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-black/20">
        <div className="space-y-1.5 max-w-lg">
          <div className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-amber-400 shrink-0" />
            <h3 className="font-serif text-base font-bold text-gray-100">Senior Mentor Cognitive Memory</h3>
          </div>
          <p className="text-xs text-gray-400 leading-relaxed">
            Configure which aspects of your schedule, goals, and working patterns the Senior Mentor is allowed to retain in memory to synthesize advice and detect strategic risks.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleReset}
            className="px-3 py-1.5 border border-gray-800 bg-[#0d0e12] hover:bg-gray-800/50 hover:text-gray-200 text-gray-400 text-[10px] font-mono font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
            id="reset-memory-preferences-btn"
            title="Reset to default settings"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restore Defaults</span>
          </button>
        </div>
      </div>

      {/* Main Settings Grid */}
      <div className="p-6 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {settingsItems.map((item) => {
            const isEnabled = coachMemorySettings[item.key];
            const IconComponent = item.icon;

            return (
              <div 
                key={item.key}
                className={`p-4 rounded-xl border transition-all duration-300 flex flex-col justify-between gap-4 ${
                  isEnabled 
                    ? 'bg-black/30 border-amber-500/10' 
                    : 'bg-[#0a0a0c]/40 border-gray-900/60 opacity-80'
                }`}
                id={`setting-card-${item.key}`}
              >
                <div className="flex gap-3.5 items-start">
                  <div className={`p-2 rounded-xl border shrink-0 ${item.accentColor}`}>
                    <IconComponent className="w-4 h-4" />
                  </div>
                  
                  <div className="space-y-1">
                    <label 
                      htmlFor={`toggle-${item.key}`}
                      className="text-xs font-bold text-gray-100 cursor-pointer flex items-center gap-2"
                    >
                      {item.label}
                    </label>
                    <p className="text-[11px] text-gray-400 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>

                {/* Animated Switch Element */}
                <div className="flex justify-end items-center pt-2 border-t border-gray-900/40">
                  <div className="flex items-center gap-2.5">
                    <span className="font-mono text-[9px] uppercase tracking-wider text-gray-500">
                      {isEnabled ? "RETENTION ACTIVE" : "DISABLED"}
                    </span>
                    
                    <button
                      type="button"
                      id={`toggle-${item.key}`}
                      onClick={() => toggleSetting(item.key)}
                      className={`relative w-11 h-6 rounded-full cursor-pointer transition-colors outline-none ${
                        isEnabled ? 'bg-amber-500' : 'bg-gray-800'
                      }`}
                    >
                      <motion.div
                        className="w-4 h-4 rounded-full bg-white absolute top-1 left-1"
                        animate={{ x: isEnabled ? 20 : 0 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                      />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Security Warning Panel */}
        <div className="p-4 bg-[#0a0a0c]/60 border border-gray-900 rounded-xl flex gap-3 items-start text-[11px] text-gray-500 leading-relaxed" id="security-warning-panel">
          <Info className="w-4 h-4 text-amber-500/60 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-gray-400">Sandbox Sovereignty Notice:</span> Turning off any category will immediately clear that context from subsequent mentor syntheses. All cognitive data state is saved in your local sandboxed browser storage. No telemetry or credentials are sent to external servers.
          </div>
        </div>
      </div>

      {/* Persistent Auto-save Footer Status */}
      <div className="px-6 py-3 bg-black/40 border-t border-gray-800/60 flex items-center justify-between text-[11px]">
        <div className="flex items-center gap-1.5 text-gray-500">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          <span>Local Storage Synchronization Engaged</span>
        </div>

        <AnimatePresence>
          {showSavedToast && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="text-emerald-400 font-mono font-bold flex items-center gap-1"
              id="settings-saved-indicator"
            >
              <Check className="w-3.5 h-3.5 shrink-0" />
              <span>SAVED TO SANDBOX</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
