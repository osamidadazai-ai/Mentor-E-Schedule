import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Flame, Award, TrendingUp, CheckCircle, Clock, Calendar, 
  Sparkles, Smile, Battery, Search, ArrowRight, History, 
  ChevronLeft, ChevronRight, BookOpen, AlertCircle, RefreshCw, 
  HelpCircle, MessageSquare, ListTodo, Plus, Info, Check, ThumbsUp
} from 'lucide-react';
import { useProductivityStore } from '../stores/useProductivityStore';
import { reflectionService, DailyLog, WeeklyReport, MonthlyReport, UserStreaks } from '../services/reflectionService';

export const DailyReflectionSystem: React.FC = () => {
  const { tasks, completedTasks, userProfile } = useProductivityStore();
  
  // Tabs: 'today' | 'history' | 'weekly' | 'monthly'
  const [activeTab, setActiveTab] = useState<'today' | 'history' | 'reports'>('today');
  
  // Loading & Sync States
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);
  
  // Streaks State
  const [streaks, setStreaks] = useState<UserStreaks>({
    currentStreak: 0,
    longestStreak: 0,
    consecutiveProductiveDays: 0,
    consecutivePlannerUsage: 0,
    consecutiveAiMentorUsage: 0
  });

  // Today's log state
  const [todayLog, setTodayLog] = useState<DailyLog | null>(null);
  const [todayMood, setTodayMood] = useState<string>('Focused');
  const [todayEnergy, setTodayEnergy] = useState<number>(8);
  const [todayOneLine, setTodayOneLine] = useState<string>('');
  
  // Today's prompt questions (helper helpers)
  const [todayPromptIdx, setTodayPromptIdx] = useState<number>(0);
  const prompts = [
    "What did you learn today that prepares you for tomorrow's moves?",
    "What represented the single biggest roadblock today, and how did you bypass it?",
    "What specific execution block made you proudest today?",
    "What should you adjust or simplify tomorrow to maintain high ELO momentum?"
  ];

  // History states
  const [historyLogs, setHistoryLogs] = useState<DailyLog[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedHistLog, setSelectedHistLog] = useState<DailyLog | null>(null);

  // Weekly/Monthly Reports states
  const [weeklyReports, setWeeklyReports] = useState<WeeklyReport[]>([]);
  const [monthlyReports, setMonthlyReports] = useState<MonthlyReport[]>([]);
  const [currentWeeklyReport, setCurrentWeeklyReport] = useState<WeeklyReport | null>(null);
  const [currentMonthlyReport, setCurrentMonthlyReport] = useState<MonthlyReport | null>(null);
  const [isWeeklyLoading, setIsWeeklyLoading] = useState<boolean>(false);
  const [isMonthlyLoading, setIsMonthlyLoading] = useState<boolean>(false);

  const todayDateStr = new Date().toISOString().split('T')[0];

  // Load Streaks, Today's Log & History
  const loadData = async () => {
    setIsLoading(true);
    try {
      const activeStreaks = await reflectionService.getStreaks();
      setStreaks(activeStreaks);

      const log = await reflectionService.getDailyLog(todayDateStr);
      if (log) {
        setTodayLog(log);
        setTodayMood(log.mood || 'Focused');
        setTodayEnergy(log.energyLevel || 8);
        setTodayOneLine(log.oneLineReflection || '');
      } else {
        // Auto compile initial day log structure
        const stats = compileAutoStats(todayDateStr);
        setTodayLog({
          date: todayDateStr,
          ...stats,
          oneLineReflection: '',
          aiReflection: '',
          aiRecommendation: '',
          timestamp: new Date().toISOString(),
          lastUpdated: new Date().toISOString()
        });
      }

      const history = await reflectionService.getDailyLogsHistory();
      setHistoryLogs(history);

      const weeks = await reflectionService.getWeeklyReportsHistory();
      setWeeklyReports(weeks);
      if (weeks.length > 0) {
        setCurrentWeeklyReport(weeks[0]);
      }

      const months = await reflectionService.getMonthlyReportsHistory();
      setMonthlyReports(months);
      if (months.length > 0) {
        setCurrentMonthlyReport(months[0]);
      }

    } catch (err) {
      console.error('Error loading reflection system data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [tasks, completedTasks]);

  // Compile auto statistics for a specific day date
  const compileAutoStats = (dateStr: string) => {
    // Standard task mapping
    const completedToday = completedTasks.filter(t => {
      if (!t.createdAt) return false;
      const compDate = t.createdAt.split('T')[0];
      return compDate === dateStr;
    });

    const pendingToday = tasks.filter(t => t.dueDate === dateStr && !t.completed);
    
    // Missed tasks are tasks with a past due date that are not completed
    const missedToday = tasks.filter(t => {
      if (!t.dueDate) return false;
      return t.dueDate < dateStr && !t.completed;
    });

    const totalCalculated = completedToday.length + pendingToday.length + missedToday.length;
    const rate = totalCalculated > 0 ? Math.round((completedToday.length / totalCalculated) * 100) : 0;

    // Study focus minutes
    const studyTime = completedToday.reduce((acc, t) => acc + (t.durationMinutes || 30), 0);

    // Created plans today
    const createdPlans = [...tasks, ...completedTasks].filter(t => t.createdAt?.split('T')[0] === dateStr).length;

    // Deadlines due today
    const deadlinesCount = tasks.filter(t => t.dueDate === dateStr && (t.priority === 'KING' || t.priority === 'QUEEN')).map(t => ({
      id: t.id,
      title: t.title,
      priority: t.priority
    }));

    return {
      completedTasks: completedToday.map(t => ({ id: t.id, title: t.title, priority: t.priority })),
      pendingTasks: pendingToday.map(t => ({ id: t.id, title: t.title, priority: t.priority })),
      missedTasks: missedToday.map(t => ({ id: t.id, title: t.title, priority: t.priority })),
      completionPercentage: rate,
      studyTime,
      createdPlans,
      deadlines: deadlinesCount
    };
  };

  // Re-sync today's log stats manually
  const handleRefreshTodayStats = () => {
    if (!todayLog) return;
    const freshStats = compileAutoStats(todayDateStr);
    setTodayLog({
      ...todayLog,
      ...freshStats,
      lastUpdated: new Date().toISOString()
    });
  };

  // Save Today's Reflection and query advisor
  const handleSubmitReflection = async () => {
    if (!todayLog) return;
    setIsAiLoading(true);

    const freshStats = compileAutoStats(todayDateStr);
    const updatedLog: DailyLog = {
      ...todayLog,
      ...freshStats,
      mood: todayMood,
      energyLevel: todayEnergy,
      oneLineReflection: todayOneLine,
      lastUpdated: new Date().toISOString()
    };

    try {
      // Query server Gemini endpoint for reflection
      const aiResponse = await reflectionService.generateDailyAISummary(updatedLog, userProfile);
      
      const finalLog: DailyLog = {
        ...updatedLog,
        aiReflection: aiResponse.aiReflection,
        aiRecommendation: aiResponse.aiRecommendation
      };

      await reflectionService.saveDailyLog(finalLog);
      setTodayLog(finalLog);
      
      // Update streaks state
      const updatedStreaks = await reflectionService.getStreaks();
      setStreaks(updatedStreaks);

      // Refresh history list
      const freshHistory = await reflectionService.getDailyLogsHistory();
      setHistoryLogs(freshHistory);

    } catch (err) {
      console.error('Failed to analyze reflection:', err);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Compile and Save Weekly Report for current week
  const handleGenerateWeeklyReport = async () => {
    setIsWeeklyLoading(true);
    const currentYear = new Date().getFullYear();
    // Get current week number
    const tempDate = new Date();
    tempDate.setHours(0,0,0,0);
    tempDate.setDate(tempDate.getDate() + 3 - (tempDate.getDay() + 6) % 7);
    const week1 = new Date(tempDate.getFullYear(), 0, 4);
    const weekNumber = 1 + Math.round(((tempDate.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
    const weekId = `${currentYear}-W${weekNumber.toString().padStart(2, '0')}`;

    try {
      // Take past 7 daily logs from history
      const relevantLogs = historyLogs.slice(0, 7);
      const report = await reflectionService.generateWeeklyReport(weekId, relevantLogs, userProfile);
      setCurrentWeeklyReport(report);
      
      const updatedWeeks = await reflectionService.getWeeklyReportsHistory();
      setWeeklyReports(updatedWeeks);
    } catch (err) {
      console.error('Failed to compile weekly report:', err);
    } finally {
      setIsWeeklyLoading(false);
    }
  };

  // Compile and Save Monthly Report
  const handleGenerateMonthlyReport = async () => {
    setIsMonthlyLoading(true);
    const currentYear = new Date().getFullYear();
    const currentMonthNum = new Date().getMonth() + 1;
    const monthId = `${currentYear}-${currentMonthNum.toString().padStart(2, '0')}`;

    try {
      const report = await reflectionService.generateMonthlyReport(monthId, weeklyReports, userProfile);
      setCurrentMonthlyReport(report);

      const updatedMonths = await reflectionService.getMonthlyReportsHistory();
      setMonthlyReports(updatedMonths);
    } catch (err) {
      console.error('Failed to compile monthly report:', err);
    } finally {
      setIsMonthlyLoading(false);
    }
  };

  // Get completion count color for contribution heatmap tiles
  const getDensityColor = (percentage: number) => {
    if (percentage === 0) return 'bg-[#12131a] border-gray-850';
    if (percentage < 30) return 'bg-amber-950/20 border-amber-900/30 text-amber-500';
    if (percentage < 60) return 'bg-amber-500/10 border-amber-500/20 text-amber-400';
    if (percentage < 85) return 'bg-amber-500/25 border-amber-500/40 text-amber-300';
    return 'bg-[#D4AF37]/35 border-[#D4AF37]/65 text-amber-200';
  };

  // Filter history logs based on search terms
  const filteredLogs = historyLogs.filter(log => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    const dateMatches = log.date.includes(query);
    const textMatches = log.oneLineReflection?.toLowerCase().includes(query) || false;
    const aiMatches = log.aiReflection?.toLowerCase().includes(query) || false;
    const moodMatches = log.mood?.toLowerCase().includes(query) || false;
    
    const taskMatches = log.completedTasks.some(t => t.title.toLowerCase().includes(query)) ||
      log.pendingTasks.some(t => t.title.toLowerCase().includes(query)) ||
      log.missedTasks.some(t => t.title.toLowerCase().includes(query));

    return dateMatches || textMatches || aiMatches || moodMatches || taskMatches;
  });

  return (
    <div className="w-full space-y-6 text-gray-200" id="reflection-system-root">
      
      {/* HEADER SECTION */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-amber-500/10 text-[#D4AF37] rounded-lg border border-amber-500/20">
              <BookOpen className="w-4 h-4" />
            </span>
            <h3 className="font-serif text-2xl font-black text-gray-100 uppercase tracking-wide">
              Daily Progress & Reflection Ledger
            </h3>
          </div>
          <p className="text-xs text-gray-400">
            Chronicle your daily focus logs, consult the strategic AI advisor on executive momentum, and audit structural weekly trends.
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex bg-[#12131a] p-1 rounded-xl border border-gray-800">
          {[
            { id: 'today', label: "Today's Log", icon: Calendar },
            { id: 'history', label: 'History Archives', icon: History },
            { id: 'reports', label: 'Growth Reports', icon: Award }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-[10px] font-sans font-bold uppercase tracking-wider transition-all cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#D4AF37]'
                    : 'text-gray-400 hover:text-gray-200 border border-transparent'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* QUICK STATUS STREAKS SECTION */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Momentum Streak', val: `${streaks.currentStreak} Days`, desc: 'Productive days (≥50% completion)', icon: Flame, color: 'text-rose-500', bg: 'bg-rose-500/5' },
          { label: 'Longest Streak', val: `${streaks.longestStreak} Days`, desc: 'Personal strategy peak record', icon: Award, color: 'text-amber-400', bg: 'bg-amber-500/5' },
          { label: 'Daily Planner Usage', val: `${streaks.consecutivePlannerUsage} Days`, desc: 'Consistent schedule ledger entries', icon: ListTodo, color: 'text-sky-400', bg: 'bg-sky-500/5' },
          { label: 'AI Advisor discussions', val: `${streaks.consecutiveAiMentorUsage} consults`, desc: 'Active planning calibrations', icon: MessageSquare, color: 'text-emerald-400', bg: 'bg-emerald-500/5' }
        ].map((item, idx) => {
          const Icon = item.icon;
          return (
            <div key={idx} className="bg-[#0f1015] border border-gray-850 rounded-2xl p-4 flex items-center gap-4.5">
              <div className={`p-3 rounded-xl ${item.bg} border border-gray-800 shrink-0`}>
                <Icon className={`w-5 h-5 ${item.color}`} />
              </div>
              <div>
                <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block font-bold">{item.label}</span>
                <span className="text-lg font-serif font-black text-gray-100">{item.val}</span>
                <span className="text-[9px] text-gray-400 block line-clamp-1 mt-0.5">{item.desc}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* ACTIVE TAB CONTENT */}
      {activeTab === 'today' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" key="today-tab">
          
          {/* LEFT: AUTO COLLECT STATS */}
          <div className="space-y-4 lg:col-span-1">
            <div className="bg-[#0b0c10]/80 border border-gray-850 rounded-2xl p-5 space-y-4">
              <div className="flex justify-between items-center border-b border-gray-850 pb-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-[#D4AF37]" />
                  <span className="text-xs uppercase font-mono font-bold text-gray-200">Today's Performance Stats</span>
                </div>
                <button 
                  onClick={handleRefreshTodayStats} 
                  title="Sync latest store metrics"
                  className="p-1 hover:bg-gray-800 rounded text-gray-500 hover:text-gray-300 transition-all cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </div>

              {todayLog ? (
                <div className="space-y-3.5">
                  {/* Circle Completion percentage */}
                  <div className="flex items-center gap-4 bg-black/20 border border-gray-850/60 p-4 rounded-xl">
                    <div className="relative w-14 h-14 flex items-center justify-center shrink-0">
                      <svg className="w-full h-full transform -rotate-90">
                        <circle cx="28" cy="28" r="24" stroke="#12131a" strokeWidth="4" fill="transparent" />
                        <circle cx="28" cy="28" r="24" stroke="#D4AF37" strokeWidth="4" fill="transparent" 
                                strokeDasharray={`${2 * Math.PI * 24}`} 
                                strokeDashoffset={`${2 * Math.PI * 24 * (1 - todayLog.completionPercentage / 100)}`} 
                                strokeLinecap="round" className="transition-all duration-700" />
                      </svg>
                      <span className="absolute text-[10px] font-mono font-black text-[#D4AF37]">{todayLog.completionPercentage}%</span>
                    </div>
                    <div>
                      <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider block font-bold">Execution Rate</span>
                      <h4 className="text-sm font-serif font-bold text-gray-200">
                        {todayLog.completedTasks.length} out of {todayLog.completedTasks.length + todayLog.pendingTasks.length + todayLog.missedTasks.length} tasks completed
                      </h4>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-black/20 border border-gray-850/40 rounded-xl">
                      <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest block font-bold">Focus Time</span>
                      <span className="text-sm font-serif font-black text-[#D4AF37]">{todayLog.studyTime} Mins</span>
                    </div>
                    <div className="p-3 bg-black/20 border border-gray-850/40 rounded-xl">
                      <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest block font-bold">Planned Moves</span>
                      <span className="text-sm font-serif font-black text-sky-400">+{todayLog.createdPlans} Created</span>
                    </div>
                  </div>

                  {/* Task details scannable list */}
                  <div className="space-y-2">
                    <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest block font-bold">Task Log Audit</span>
                    
                    {todayLog.completedTasks.length > 0 && (
                      <div className="space-y-1">
                        <span className="text-[8px] uppercase font-mono text-emerald-500 font-bold block">✓ Executed</span>
                        <div className="max-h-[100px] overflow-y-auto space-y-1">
                          {todayLog.completedTasks.map((t, i) => (
                            <div key={i} className="p-2 bg-emerald-950/5 border border-emerald-900/10 rounded-lg text-[10px] text-gray-300 flex items-center justify-between">
                              <span className="line-clamp-1">{t.title}</span>
                              <span className="text-[8px] font-mono px-1.5 py-0.5 rounded bg-emerald-950 border border-emerald-800/30 text-emerald-400 font-bold uppercase">{t.priority}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {todayLog.pendingTasks.length > 0 && (
                      <div className="space-y-1">
                        <span className="text-[8px] uppercase font-mono text-amber-500 font-bold block">⌛ Pending Operations</span>
                        <div className="max-h-[100px] overflow-y-auto space-y-1">
                          {todayLog.pendingTasks.map((t, i) => (
                            <div key={i} className="p-2 bg-amber-950/5 border border-amber-900/10 rounded-lg text-[10px] text-gray-400 flex items-center justify-between">
                              <span className="line-clamp-1">{t.title}</span>
                              <span className="text-[8px] font-mono px-1.5 py-0.5 rounded bg-amber-950 border border-amber-800/30 text-amber-400 font-bold uppercase">{t.priority}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {todayLog.missedTasks.length > 0 && (
                      <div className="space-y-1">
                        <span className="text-[8px] uppercase font-mono text-rose-500 font-bold block">🗙 Missed/Overdue Targets</span>
                        <div className="max-h-[100px] overflow-y-auto space-y-1">
                          {todayLog.missedTasks.map((t, i) => (
                            <div key={i} className="p-2 bg-rose-950/5 border border-rose-900/10 rounded-lg text-[10px] text-gray-450 flex items-center justify-between">
                              <span className="line-clamp-1">{t.title}</span>
                              <span className="text-[8px] font-mono px-1.5 py-0.5 rounded bg-rose-950 border border-rose-800/30 text-rose-400 font-bold uppercase">{t.priority}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {todayLog.completedTasks.length === 0 && todayLog.pendingTasks.length === 0 && todayLog.missedTasks.length === 0 && (
                      <p className="text-[10px] text-gray-600 italic text-center py-6">No scheduled tasks logged for today.</p>
                    )}
                  </div>

                </div>
              ) : (
                <div className="text-center py-10">
                  <div className="w-6 h-6 border-2 border-[#D4AF37]/30 border-t-[#D4AF37] rounded-full animate-spin mx-auto mb-2"></div>
                  <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Loading latest metrics...</span>
                </div>
              )}
            </div>
          </div>

          {/* RIGHT/MIDDLE: REFLECTION INPUTS & ADVISOR FEEDBACK */}
          <div className="space-y-4 lg:col-span-2">
            
            {/* INPUT PANEL */}
            <div className="bg-[#0b0c10]/80 border border-gray-850 rounded-2xl p-6 space-y-5">
              <div className="flex justify-between items-center border-b border-gray-850 pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                  <span className="text-xs uppercase font-mono font-bold text-gray-200">User Growth Reflection</span>
                </div>
                <span className="text-[10px] font-mono text-gray-500">{todayDateStr}</span>
              </div>

              {/* Mood & Energy selector */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 bg-black/10 p-4 rounded-xl border border-gray-850/50">
                {/* Mood Selector */}
                <div className="space-y-2">
                  <label className="text-[9px] font-mono text-gray-400 uppercase tracking-wider block font-bold">Baseline Focus State (Mood)</label>
                  <div className="flex flex-wrap gap-1.5">
                    {['Focused', 'Calm', 'Fatigued', 'Anxious', 'Productive'].map((m) => (
                      <button
                        key={m}
                        onClick={() => setTodayMood(m)}
                        className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wide transition-all cursor-pointer border ${
                          todayMood === m 
                            ? 'bg-[#D4AF37]/15 border-[#D4AF37]/30 text-[#D4AF37]' 
                            : 'bg-[#12131a] border-gray-850 text-gray-400 hover:text-gray-200'
                        }`}
                      >
                        {m}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Energy Level (1-10 Slider) */}
                <div className="space-y-2 flex flex-col justify-between">
                  <div className="flex justify-between items-center">
                    <label className="text-[9px] font-mono text-gray-400 uppercase tracking-wider block font-bold">Energy Baseline Level</label>
                    <span className="text-xs font-serif font-black text-[#D4AF37]">{todayEnergy}/10</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] font-mono text-gray-600">Low</span>
                    <input 
                      type="range" min="1" max="10" step="1" 
                      value={todayEnergy} 
                      onChange={(e) => setTodayEnergy(parseInt(e.target.value))}
                      className="flex-grow accent-[#D4AF37] bg-gray-800 rounded-lg cursor-pointer h-1.5"
                    />
                    <span className="text-[10px] font-mono text-gray-600">High</span>
                  </div>
                </div>
              </div>

              {/* Dynamic prompts helper */}
              <div className="p-3 bg-amber-500/5 border border-amber-500/10 rounded-xl space-y-1.5">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1.5 text-amber-400">
                    <HelpCircle className="w-3.5 h-3.5" />
                    <span className="text-[9px] font-mono uppercase tracking-widest font-black">Strategic Guidance Prompt</span>
                  </div>
                  <button 
                    onClick={() => setTodayPromptIdx(prev => (prev + 1) % prompts.length)}
                    className="text-[9px] font-mono text-[#D4AF37] hover:underline cursor-pointer"
                  >
                    Next Prompt
                  </button>
                </div>
                <p className="text-[10.5px] text-gray-300 italic leading-relaxed">
                  "{prompts[todayPromptIdx]}"
                </p>
              </div>

              {/* Text reflection input */}
              <div className="space-y-2">
                <label className="text-[9px] font-mono text-gray-400 uppercase tracking-wider block font-bold">What happened today? (Notes & Reflection)</label>
                <textarea
                  value={todayOneLine}
                  onChange={(e) => setTodayOneLine(e.target.value)}
                  placeholder="Record your roadblocks, wins, insights, or custom notes regarding today's performance..."
                  className="w-full h-24 bg-[#12131a] border border-gray-850 rounded-xl p-3.5 text-xs text-gray-200 placeholder-gray-650 focus:outline-none focus:border-[#D4AF37]/50 resize-none font-sans"
                />
              </div>

              <button
                onClick={handleSubmitReflection}
                disabled={isAiLoading}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-600 via-[#D4AF37] to-amber-600 text-black text-xs uppercase font-mono font-bold tracking-widest hover:brightness-110 active:scale-[0.99] transition-all cursor-pointer shadow-md disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isAiLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin"></div>
                    <span>Formulating Strategic Assessment...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Submit Reflection & Query Advisor</span>
                  </>
                )}
              </button>
            </div>

            {/* ADVISOR ADVICE OUTPUT */}
            <AnimatePresence mode="wait">
              {todayLog?.aiReflection && (
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.3 }}
                  className="bg-[#0b0c10]/80 border border-amber-500/30 rounded-2xl p-6 space-y-4 shadow-[0_4px_30px_rgba(212,175,55,0.05)] relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/2.5 rounded-full blur-2xl pointer-events-none"></div>
                  
                  <div className="flex items-center gap-2 border-b border-gray-850 pb-3">
                    <span className="p-1 bg-[#D4AF37]/10 text-[#D4AF37] rounded border border-[#D4AF37]/25">
                      <Sparkles className="w-3.5 h-3.5" />
                    </span>
                    <span className="text-[10px] uppercase font-mono tracking-widest font-black text-[#D4AF37]">Grandmaster Strategist Evaluation</span>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <span className="text-[8px] font-mono text-gray-500 uppercase tracking-wider block font-bold">Tactical Analysis</span>
                      <p className="text-xs text-gray-300 font-serif leading-relaxed italic">
                        "{todayLog.aiReflection}"
                      </p>
                    </div>

                    <div className="p-3.5 bg-[#D4AF37]/5 border border-[#D4AF37]/15 rounded-xl space-y-1">
                      <span className="text-[8px] font-mono text-[#D4AF37] uppercase tracking-wider block font-bold">Key Recommendation for Tomorrow</span>
                      <p className="text-[11px] text-gray-200 leading-relaxed">
                        {todayLog.aiRecommendation}
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

          </div>

        </div>
      )}

      {activeTab === 'history' && (
        <div className="space-y-4" key="history-tab">
          
          {/* Search bar & heat map grid info */}
          <div className="flex flex-col md:flex-row gap-4 justify-between items-center bg-[#0f1015] border border-gray-850 p-4 rounded-2xl">
            <div className="relative w-full md:max-w-sm">
              <Search className="w-4 h-4 absolute left-3.5 top-3 text-gray-550" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search date, keywords, mood, task, etc..."
                className="w-full pl-10 pr-4 py-2 bg-[#12131a] border border-gray-850 rounded-xl text-xs text-gray-200 placeholder-gray-650 focus:outline-none focus:border-[#D4AF37]/40 font-mono"
              />
            </div>

            <div className="flex items-center gap-2 text-[10px] font-mono text-gray-500 shrink-0">
              <span>Less</span>
              <div className="w-3.5 h-3.5 rounded bg-[#12131a] border border-gray-850"></div>
              <div className="w-3.5 h-3.5 rounded bg-amber-950/20 border-amber-900/30"></div>
              <div className="w-3.5 h-3.5 rounded bg-amber-500/10 border-amber-500/20"></div>
              <div className="w-3.5 h-3.5 rounded bg-[#D4AF37]/35 border-[#D4AF37]/65"></div>
              <span>More</span>
            </div>
          </div>

          {/* CONTRIBUTION HEATMAP & DENSITY GRID */}
          <div className="bg-[#0b0c10]/80 border border-gray-850 rounded-2xl p-5 space-y-3">
            <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest block font-bold">Productive Momentum Index (Heatmap)</span>
            
            {/* Display last 28 days */}
            <div className="flex flex-wrap gap-2 pt-1">
              {Array.from({ length: 28 }).map((_, idx) => {
                const dayOffset = 27 - idx;
                const d = new Date();
                d.setDate(d.getDate() - dayOffset);
                const isoStr = d.toISOString().split('T')[0];
                const matchingLog = historyLogs.find(l => l.date === isoStr);
                
                const percentage = matchingLog ? matchingLog.completionPercentage : 0;
                const isDayToday = isoStr === todayDateStr;

                return (
                  <button
                    key={idx}
                    onClick={() => {
                      if (matchingLog) setSelectedHistLog(matchingLog);
                    }}
                    disabled={!matchingLog}
                    className={`w-10 h-10 rounded-lg border flex flex-col items-center justify-center cursor-pointer transition-all hover:scale-105 ${getDensityColor(percentage)} ${
                      isDayToday ? 'ring-2 ring-amber-500/50' : ''
                    } ${!matchingLog ? 'opacity-30 cursor-not-allowed' : ''}`}
                    title={`${isoStr}: ${percentage}% completed`}
                  >
                    <span className="text-[8px] font-mono text-gray-500 font-bold block">{d.getDate()}</span>
                    {matchingLog && (
                      <span className="text-[7.5px] font-mono block font-black text-amber-300 mt-0.5">{percentage}%</span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* FILTERED HISTORY LIST */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredLogs.map((log) => (
              <div 
                key={log.date}
                onClick={() => setSelectedHistLog(log)}
                className="bg-[#0f1015] border border-gray-850 hover:border-[#D4AF37]/35 p-5 rounded-2xl space-y-4 transition-all cursor-pointer hover:shadow-lg relative group"
              >
                <div className="flex justify-between items-center border-b border-gray-850/60 pb-2.5">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-amber-500" />
                    <span className="text-xs font-mono font-black text-gray-100">{log.date}</span>
                  </div>
                  <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#12131a] border border-gray-800 text-amber-300 font-bold uppercase">
                    {log.mood || 'Focused'}
                  </span>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                    <span>Task Completion Rate:</span>
                    <span className="font-bold text-[#D4AF37]">{log.completionPercentage}%</span>
                  </div>
                  <div className="flex justify-between items-center text-[10px] font-mono text-gray-400">
                    <span>Focus Duration:</span>
                    <span className="font-bold text-sky-400">{log.studyTime} Mins</span>
                  </div>
                  
                  {log.oneLineReflection && (
                    <p className="text-[11px] text-gray-500 italic line-clamp-2 bg-black/10 p-2.5 rounded-lg border border-gray-850/40">
                      "{log.oneLineReflection}"
                    </p>
                  )}
                </div>

                <div className="text-[9px] text-gray-500 flex items-center justify-between border-t border-gray-850/40 pt-2.5">
                  <span>Last synced: {new Date(log.lastUpdated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  <span className="text-[#D4AF37] opacity-0 group-hover:opacity-100 transition-all font-mono font-bold flex items-center gap-0.5">
                    Audit <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))}

            {filteredLogs.length === 0 && (
              <div className="col-span-full py-16 bg-[#0f1015] border border-dashed border-gray-800 rounded-2xl text-center space-y-2">
                <AlertCircle className="w-8 h-8 text-gray-650 mx-auto" />
                <h4 className="text-xs font-mono uppercase font-black text-gray-400">No Archives Found</h4>
                <p className="text-[11px] text-gray-500 max-w-xs mx-auto">Create and log your reflection today to initialize your performance history archives ledger.</p>
              </div>
            )}
          </div>

          {/* ARCHIVE DIALOG / DETAILED LOG VIEW MODAL */}
          <AnimatePresence>
            {selectedHistLog && (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-4">
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="w-full max-w-xl bg-[#0c0d12] border border-amber-500/20 rounded-3xl p-6 relative shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto scrollbar-thin"
                >
                  <div className="flex justify-between items-center border-b border-gray-850 pb-4">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-amber-500" />
                      <span className="text-sm font-mono font-black text-gray-100">Performance Archive: {selectedHistLog.date}</span>
                    </div>
                    <button 
                      onClick={() => setSelectedHistLog(null)}
                      className="text-gray-500 hover:text-gray-300 font-mono text-xs uppercase font-bold cursor-pointer"
                    >
                      Close [x]
                    </button>
                  </div>

                  {/* Summary grid */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-black/25 p-4 rounded-xl border border-gray-850/60">
                    <div>
                      <span className="text-[8px] font-mono text-gray-500 uppercase tracking-wider block font-bold">Success Rate</span>
                      <span className="text-sm font-serif font-black text-[#D4AF37]">{selectedHistLog.completionPercentage}%</span>
                    </div>
                    <div>
                      <span className="text-[8px] font-mono text-gray-500 uppercase tracking-wider block font-bold">Focus Time</span>
                      <span className="text-sm font-serif font-black text-sky-400">{selectedHistLog.studyTime} Mins</span>
                    </div>
                    <div>
                      <span className="text-[8px] font-mono text-gray-500 uppercase tracking-wider block font-bold">Mood State</span>
                      <span className="text-sm font-serif font-black text-emerald-400">{selectedHistLog.mood || 'Focused'}</span>
                    </div>
                    <div>
                      <span className="text-[8px] font-mono text-gray-500 uppercase tracking-wider block font-bold">Energy Level</span>
                      <span className="text-sm font-serif font-black text-rose-400">{selectedHistLog.energyLevel || 8}/10</span>
                    </div>
                  </div>

                  {/* Reflection Text */}
                  {selectedHistLog.oneLineReflection && (
                    <div className="space-y-1.5 bg-[#12131a] border border-gray-850 p-4 rounded-2xl">
                      <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest block font-bold">User Written Reflection</span>
                      <p className="text-xs text-gray-300 italic leading-relaxed">
                        "{selectedHistLog.oneLineReflection}"
                      </p>
                    </div>
                  )}

                  {/* Tasks List logged */}
                  <div className="space-y-2.5">
                    <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest block font-bold">Task Log Breakdown</span>
                    <div className="space-y-1 max-h-[160px] overflow-y-auto pr-1">
                      {selectedHistLog.completedTasks.map((t, idx) => (
                        <div key={idx} className="p-2.5 bg-emerald-950/10 border border-emerald-900/15 rounded-lg text-xs text-gray-300 flex justify-between items-center">
                          <span>✓ {t.title}</span>
                          <span className="text-[8px] font-mono bg-emerald-950 border border-emerald-850 px-1.5 py-0.5 rounded text-emerald-400 font-bold uppercase">{t.priority}</span>
                        </div>
                      ))}
                      {selectedHistLog.pendingTasks.map((t, idx) => (
                        <div key={idx} className="p-2.5 bg-amber-950/10 border border-amber-900/15 rounded-lg text-xs text-gray-400 flex justify-between items-center">
                          <span>⌛ {t.title} (Pending)</span>
                          <span className="text-[8px] font-mono bg-amber-950 border border-amber-850 px-1.5 py-0.5 rounded text-amber-400 font-bold uppercase">{t.priority}</span>
                        </div>
                      ))}
                      {selectedHistLog.completedTasks.length === 0 && selectedHistLog.pendingTasks.length === 0 && (
                        <p className="text-[10px] text-gray-600 italic">No tasks recorded in this archive.</p>
                      )}
                    </div>
                  </div>

                  {/* AI reflection stored */}
                  {selectedHistLog.aiReflection && (
                    <div className="p-4.5 bg-amber-500/5 border border-amber-500/15 rounded-2xl space-y-2 relative overflow-hidden">
                      <div className="flex items-center gap-1.5 text-amber-400">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span className="text-[9px] font-mono uppercase tracking-widest font-black">AI Advisor Syntheses Archive</span>
                      </div>
                      <p className="text-xs text-gray-300 leading-relaxed font-serif">
                        "{selectedHistLog.aiReflection}"
                      </p>
                      <div className="p-2.5 bg-black/20 rounded-lg text-[10.5px] text-gray-400 leading-relaxed border border-gray-850/40">
                        <span className="text-[8px] uppercase font-mono text-amber-400 font-bold block mb-0.5">Preserved Action Strategy</span>
                        {selectedHistLog.aiRecommendation}
                      </div>
                    </div>
                  )}

                  <div className="border-t border-gray-850/60 pt-4 text-right">
                    <button
                      onClick={() => setSelectedHistLog(null)}
                      className="px-5 py-2 rounded-xl bg-[#12131a] hover:bg-gray-800 border border-gray-800 text-xs font-mono font-bold uppercase tracking-wider text-gray-300 transition-all cursor-pointer"
                    >
                      Acknowledge Archive
                    </button>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

        </div>
      )}

      {activeTab === 'reports' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6" key="reports-tab">
          
          {/* WEEKLY COCH REPORTS */}
          <div className="bg-[#0b0c10]/80 border border-gray-850 rounded-2xl p-6 space-y-5">
            <div className="flex justify-between items-center border-b border-gray-850 pb-3">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-xs uppercase font-mono font-bold text-gray-200">Weekly Strategic Reports</span>
              </div>
              <button
                onClick={handleGenerateWeeklyReport}
                disabled={isWeeklyLoading}
                className="px-3 py-1 bg-[#12131a] hover:bg-gray-800 border border-gray-850 rounded-lg text-[10px] font-mono font-bold uppercase text-amber-300 cursor-pointer flex items-center gap-1.5"
              >
                {isWeeklyLoading ? (
                  <div className="w-3 h-3 border border-amber-300/30 border-t-amber-300 rounded-full animate-spin"></div>
                ) : (
                  <Plus className="w-3 h-3" />
                )}
                <span>Generate Weekly Summary</span>
              </button>
            </div>

            {currentWeeklyReport ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-black/15 rounded-xl border border-gray-850/60">
                  <div>
                    <span className="text-[8px] font-mono text-gray-500 uppercase tracking-wider block">Report Week ID</span>
                    <span className="text-xs font-mono font-black text-gray-100">{currentWeeklyReport.weekId}</span>
                  </div>
                  <div>
                    <span className="text-[8px] font-mono text-gray-500 uppercase tracking-wider block">Tasks Completed</span>
                    <span className="text-xs font-mono font-black text-sky-400">{currentWeeklyReport.tasksCompleted} Tasks</span>
                  </div>
                  <div>
                    <span className="text-[8px] font-mono text-gray-500 uppercase tracking-wider block">Avg Success Rate</span>
                    <span className="text-xs font-mono font-black text-[#D4AF37]">{currentWeeklyReport.completionRate}%</span>
                  </div>
                </div>

                {/* AI bullet points */}
                <div className="space-y-1.5">
                  <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest block font-bold">Executive AI Synthesis Insights</span>
                  <div className="p-4 bg-[#12131a] border border-gray-850 rounded-xl text-xs text-gray-300 whitespace-pre-line leading-relaxed">
                    {currentWeeklyReport.weeklyAiInsights}
                  </div>
                </div>

                {/* Action Recommendations */}
                <div className="p-4 bg-amber-500/5 border border-amber-500/15 rounded-xl space-y-1.5">
                  <div className="flex items-center gap-1.5 text-amber-400">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span className="text-[9px] font-mono uppercase tracking-widest font-black">Upcoming Strategic Actions</span>
                  </div>
                  <div className="text-xs text-gray-300 whitespace-pre-line leading-relaxed">
                    {currentWeeklyReport.recommendations}
                  </div>
                </div>

              </div>
            ) : (
              <div className="py-20 text-center space-y-2">
                <AlertCircle className="w-6 h-6 text-gray-700 mx-auto" />
                <p className="text-[10px] font-mono uppercase text-gray-500">No Weekly Reports Generated Yet</p>
                <button 
                  onClick={handleGenerateWeeklyReport}
                  className="px-4 py-1.5 rounded-lg border border-[#D4AF37]/35 bg-[#D4AF37]/10 text-[#D4AF37] text-[10px] font-mono uppercase font-bold cursor-pointer hover:bg-[#D4AF37]/20"
                >
                  Compile Weekly Report
                </button>
              </div>
            )}
          </div>

          {/* MONTHLY REVIEW */}
          <div className="bg-[#0b0c10]/80 border border-gray-850 rounded-2xl p-6 space-y-5">
            <div className="flex justify-between items-center border-b border-gray-850 pb-3">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-[#D4AF37]" />
                <span className="text-xs uppercase font-mono font-bold text-gray-200">Monthly Performance Audits</span>
              </div>
              <button
                onClick={handleGenerateMonthlyReport}
                disabled={isMonthlyLoading}
                className="px-3 py-1 bg-[#12131a] hover:bg-gray-800 border border-gray-850 rounded-lg text-[10px] font-mono font-bold uppercase text-amber-300 cursor-pointer flex items-center gap-1.5"
              >
                {isMonthlyLoading ? (
                  <div className="w-3 h-3 border border-amber-300/30 border-t-amber-300 rounded-full animate-spin"></div>
                ) : (
                  <Plus className="w-3 h-3" />
                )}
                <span>Generate Monthly Audit</span>
              </button>
            </div>

            {currentMonthlyReport ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-black/15 rounded-xl border border-gray-850/60">
                  <div>
                    <span className="text-[8px] font-mono text-gray-500 uppercase tracking-wider block">Month ID</span>
                    <span className="text-xs font-mono font-black text-gray-100">{currentMonthlyReport.monthId}</span>
                  </div>
                  <div>
                    <span className="text-[8px] font-mono text-gray-500 uppercase tracking-wider block">Hours Invested</span>
                    <span className="text-xs font-mono font-black text-sky-400">{currentMonthlyReport.hoursInvested} Hrs</span>
                  </div>
                  <div>
                    <span className="text-[8px] font-mono text-gray-500 uppercase tracking-wider block">Goal Completion</span>
                    <span className="text-xs font-mono font-black text-[#D4AF37]">{currentMonthlyReport.goalCompletion}%</span>
                  </div>
                </div>

                {/* Growth and bottlenecks */}
                <div className="space-y-3">
                  <div className="p-4 bg-[#12131a] border border-gray-850 rounded-xl space-y-1">
                    <span className="text-[8px] font-mono text-emerald-400 uppercase tracking-wider font-bold block">Personal Growth Assessment</span>
                    <p className="text-xs text-gray-300 leading-relaxed font-serif">
                      {currentMonthlyReport.personalGrowth}
                    </p>
                  </div>

                  <div className="p-4 bg-[#12131a] border border-gray-850 rounded-xl space-y-1">
                    <span className="text-[8px] font-mono text-[#D4AF37] uppercase tracking-wider font-bold block">Biggest Improvements Detected</span>
                    <p className="text-xs text-gray-300 leading-relaxed font-serif">
                      {currentMonthlyReport.biggestImprovements}
                    </p>
                  </div>

                  <div className="p-4 bg-[#12131a] border border-gray-850 rounded-xl space-y-1">
                    <span className="text-[8px] font-mono text-rose-400 uppercase tracking-wider font-bold block">Structural Bottlenecks Observed</span>
                    <p className="text-xs text-gray-300 leading-relaxed font-serif">
                      {currentMonthlyReport.recurringBottlenecks}
                    </p>
                  </div>
                </div>

                {/* Recommendations */}
                <div className="p-4.5 bg-gradient-to-r from-amber-500/5 to-amber-600/5 border border-amber-500/15 rounded-2xl space-y-1">
                  <span className="text-[8px] font-mono text-amber-400 uppercase tracking-wider block font-bold">Month-Over-Month Tactical Roadmap</span>
                  <p className="text-xs text-gray-200 leading-relaxed">
                    {currentMonthlyReport.aiRecommendations}
                  </p>
                </div>

              </div>
            ) : (
              <div className="py-20 text-center space-y-2">
                <AlertCircle className="w-6 h-6 text-gray-700 mx-auto" />
                <p className="text-[10px] font-mono uppercase text-gray-500">No Monthly Audits Generated Yet</p>
                <button 
                  onClick={handleGenerateMonthlyReport}
                  className="px-4 py-1.5 rounded-lg border border-[#D4AF37]/35 bg-[#D4AF37]/10 text-[#D4AF37] text-[10px] font-mono uppercase font-bold cursor-pointer hover:bg-[#D4AF37]/20"
                >
                  Compile Monthly Audit
                </button>
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
};
