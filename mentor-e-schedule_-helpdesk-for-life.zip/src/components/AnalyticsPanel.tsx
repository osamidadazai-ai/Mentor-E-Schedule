import React from 'react';
import { motion } from 'motion/react';
import { 
  Award, TrendingUp, CheckCircle, Flame, Clock, Calendar, 
  ArrowUpRight, Target, ShieldCheck, Trophy, Sparkles
} from 'lucide-react';
import { useProductivityStore } from '../stores/useProductivityStore';

export const AnalyticsPanel: React.FC = () => {
  const { tasks, userProfile, analytics } = useProductivityStore();

  const totalTasksCount = tasks.length;
  const completedTasksCount = tasks.filter(t => t.completed).length;
  const activeTasksCount = totalTasksCount - completedTasksCount;

  // Group tasks by priority/rank
  const rankCounts = {
    King: tasks.filter(t => t.rank === 'King').length,
    Queen: tasks.filter(t => t.rank === 'Queen').length,
    Rook: tasks.filter(t => t.rank === 'Rook').length,
    Pawn: tasks.filter(t => t.rank === 'Pawn').length,
  };

  const rankCompleted = {
    King: tasks.filter(t => t.rank === 'King' && t.completed).length,
    Queen: tasks.filter(t => t.rank === 'Queen' && t.completed).length,
    Rook: tasks.filter(t => t.rank === 'Rook' && t.completed).length,
    Pawn: tasks.filter(t => t.rank === 'Pawn' && t.completed).length,
  };

  // Safe ELO calculation history
  const eloHistory = analytics.eloHistory || [{ date: new Date().toISOString().split('T')[0], elo: 100 }];

  // Helper to determine rank details
  const getEloRankTier = (elo: number) => {
    if (elo >= 1200) return { title: 'Grandmaster Strategist', color: 'text-amber-400', desc: 'Unparalleled focus and zero blunder latency.' };
    if (elo >= 1100) return { title: 'Master Planner', color: 'text-amber-300', desc: 'Expert prioritization and tight timeline calibration.' };
    if (elo >= 1050) return { title: 'Tactical Specialist', color: 'text-sky-400', desc: 'Highly efficient execution on mid-to-high priority tasks.' };
    return { title: 'Strategy Apprentice', color: 'text-gray-400', desc: 'Building consistent habits and establishing primary focuses.' };
  };

  const tier = getEloRankTier(userProfile.eloScore);

  return (
    <div className="w-full space-y-6 text-gray-200" id="analytics-panel-root">
      {/* Title */}
      <div className="space-y-1">
        <h3 className="font-serif text-2xl font-black text-gray-100 uppercase tracking-wide">
          Strategic Performance Analytics
        </h3>
        <p className="text-xs text-gray-400">
          Analyze execution trends, ELO milestones, and schedule efficiency metrics.
        </p>
      </div>

      {/* Grid of Key Performance Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* rating */}
        <div className="bg-[#0f1015] border border-gray-850 rounded-2xl p-5 flex flex-col justify-between h-32 relative overflow-hidden group">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-black">Strategy Rating</span>
            <span className="p-1.5 bg-amber-500/10 rounded-lg text-amber-400">
              <Award className="w-4 h-4" />
            </span>
          </div>
          <div>
            <div className="text-2xl font-serif font-extrabold text-amber-400">{userProfile.eloScore} ELO</div>
            <p className="text-[10px] text-gray-400 line-clamp-1">{tier.title}</p>
          </div>
        </div>

        {/* completion rate */}
        <div className="bg-[#0f1015] border border-gray-850 rounded-2xl p-5 flex flex-col justify-between h-32 relative overflow-hidden group">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-black">Success Rate</span>
            <span className="p-1.5 bg-emerald-500/10 rounded-lg text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div>
            <div className="text-2xl font-serif font-extrabold text-emerald-400">{analytics.completionRate}%</div>
            <p className="text-[10px] text-gray-400">Target goal completions</p>
          </div>
        </div>

        {/* tasks completed */}
        <div className="bg-[#0f1015] border border-gray-850 rounded-2xl p-5 flex flex-col justify-between h-32 relative overflow-hidden group">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-black">Tasks Solved</span>
            <span className="p-1.5 bg-sky-500/10 rounded-lg text-sky-400">
              <CheckCircle className="w-4 h-4" />
            </span>
          </div>
          <div>
            <div className="text-2xl font-serif font-extrabold text-sky-400">{analytics.tasksCompletedCount}</div>
            <p className="text-[10px] text-gray-400">{activeTasksCount} active tasks remaining</p>
          </div>
        </div>

        {/* focus minutes */}
        <div className="bg-[#0f1015] border border-gray-850 rounded-2xl p-5 flex flex-col justify-between h-32 relative overflow-hidden group">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-black">Focus Duration</span>
            <span className="p-1.5 bg-rose-500/10 rounded-lg text-rose-400">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <div>
            <div className="text-2xl font-serif font-extrabold text-rose-400">{analytics.totalFocusMinutes} Min</div>
            <p className="text-[10px] text-gray-400">{analytics.streakDays}-day momentum streak</p>
          </div>
        </div>
      </div>

      {/* Main Analysis Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Priority Matrix Execution Rate (Left, Col span 2) */}
        <div className="lg:col-span-2 bg-[#0b0c10] border border-gray-850 rounded-3xl p-6 space-y-6">
          <div>
            <h4 className="font-serif text-sm font-bold text-gray-200 uppercase tracking-wider">
              Priority Grid Distribution & Success Rate
            </h4>
            <p className="text-[11px] text-gray-500">
              Shows how effectively you execute tasks categorized by the strategic matrix priority.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { rank: 'King', label: '🔴 Critical Priority', desc: 'High cognitive demand, core project releases, critical block-breakers.', count: rankCounts.King, completed: rankCompleted.King, color: 'bg-rose-500', barColor: 'from-rose-500 to-rose-400' },
              { rank: 'Queen', label: '🔶 High Priority', desc: 'Medium-to-long term milestones, high-leverage strategic developments.', count: rankCounts.Queen, completed: rankCompleted.Queen, color: 'bg-amber-500', barColor: 'from-amber-500 to-amber-400' },
              { rank: 'Rook', label: '🔷 Medium Priority', desc: 'Administrative schedules, team reporting, communication syncs.', count: rankCounts.Rook, completed: rankCompleted.Rook, color: 'bg-sky-500', barColor: 'from-sky-500 to-sky-400' },
              { rank: 'Pawn', label: '🟢 Low Priority', desc: 'Habits, skills, routine physical recovery, and background learning.', count: rankCounts.Pawn, completed: rankCompleted.Pawn, color: 'bg-emerald-500', barColor: 'from-emerald-500 to-emerald-400' }
            ].map((item, idx) => {
              const successRate = item.count > 0 ? Math.round((item.completed / item.count) * 100) : 0;
              return (
                <div key={idx} className="p-4 rounded-xl border border-gray-850 bg-black/10 space-y-3 flex flex-col justify-between">
                  <div className="space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-gray-200">{item.label}</span>
                      <span className="text-[10px] font-mono font-bold text-gray-400">
                        {item.completed}/{item.count} Done
                      </span>
                    </div>
                    <p className="text-[10px] text-gray-500 leading-normal">{item.desc}</p>
                  </div>

                  <div className="space-y-1 pt-1">
                    <div className="flex justify-between text-[9px] font-mono text-gray-500">
                      <span>Completion Pacing</span>
                      <span className="font-bold text-gray-300">{successRate}%</span>
                    </div>
                    <div className="w-full bg-gray-900 h-2 rounded-full overflow-hidden border border-gray-800/40">
                      <div 
                        className={`bg-gradient-to-r ${item.barColor} h-full rounded-full transition-all duration-500`}
                        style={{ width: `${successRate || 5}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* ELO Rating Trajectory History Logs (Right Column) */}
        <div className="bg-[#0b0c10] border border-gray-850 rounded-3xl p-6 space-y-4">
          <div>
            <h4 className="font-serif text-sm font-bold text-gray-200 uppercase tracking-wider">
              Strategic Rating Logs
            </h4>
            <p className="text-[11px] text-gray-500">
              History of strategy calibration gains and focus streak rewards.
            </p>
          </div>

          <div className="space-y-3 max-h-[300px] overflow-y-auto scrollbar-thin pr-1">
            {eloHistory.slice().reverse().map((entry, idx) => (
              <div 
                key={idx} 
                className="p-3 bg-black/20 border border-gray-850 rounded-xl flex items-center justify-between hover:border-gray-800 transition-all"
              >
                <div className="space-y-0.5">
                  <span className="text-[9px] font-mono text-gray-500">{entry.date}</span>
                  <div className="text-xs font-bold text-gray-300">
                    {idx === 0 ? 'Current Strategic Score' : 'Rating Adjustment'}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-mono font-black text-amber-400">
                    {entry.elo} ELO
                  </div>
                  <span className="text-[8.5px] uppercase font-mono tracking-wider font-bold text-emerald-400">
                    + Active
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Guidelines on ELO calculation */}
          <div className="p-3.5 bg-amber-500/5 border border-amber-500/10 rounded-xl space-y-1.5">
            <div className="flex items-center gap-1.5 text-amber-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span className="text-[9px] font-mono uppercase tracking-widest font-black">ELO Calculation Guide</span>
            </div>
            <p className="text-[10px] text-gray-400 leading-normal">
              Gain ELO points by completing scheduled Critical and High priority tasks. Avoid letting the deep focus timer expire, as doing so represents a tactical setback, resulting in minor ELO adjustments.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
