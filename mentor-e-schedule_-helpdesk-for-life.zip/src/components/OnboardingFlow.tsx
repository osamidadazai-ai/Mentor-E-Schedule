import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Calendar, 
  Briefcase, 
  Target, 
  Compass, 
  Brain, 
  ArrowLeft, 
  ArrowRight, 
  Check, 
  Sparkles,
  ShieldAlert
} from 'lucide-react';
import { useProductivityStore } from '../stores/useProductivityStore';

const ROLES = [
  { value: 'Student', label: 'Student', desc: 'Acquiring knowledge and preparing for future milestones' },
  { value: 'Professional', label: 'Professional', desc: 'Executing high-impact projects and career advancement' },
  { value: 'Entrepreneur', label: 'Entrepreneur', desc: 'Building products, scaling operations, and driving growth' },
  { value: 'Job Seeker', label: 'Job Seeker', desc: 'Strategizing interviews and preparing technical skills' },
  { value: 'Freelancer', label: 'Freelancer', desc: 'Managing diverse clients, delivery pipelines, and autonomy' },
  { value: 'Other', label: 'Other', desc: 'Pursuing custom development or general productivity paths' }
];

const GOALS = [
  { value: 'Data Analyst', label: 'Data Analyst', desc: 'Querying, building visualization dashboards, and modeling' },
  { value: 'Software Engineer', label: 'Software Engineer', desc: 'Coding systems, deploying architecture, and scaling backends' },
  { value: 'UPSC', label: 'UPSC Candidate', desc: 'Civil Services preparation and intensive syllabus mastery' },
  { value: 'Business', label: 'Business Owner / Builder', desc: 'Optimizing conversions, strategy development, and metrics' },
  { value: 'Fitness', label: 'Fitness & Longevity', desc: 'Training consistency, nutritional discipline, and well-being' },
  { value: 'Custom', label: 'Custom Strategic Goal', desc: 'Write your own professional destination' }
];

export const OnboardingFlow: React.FC = () => {
  const { updateUserProfile, updateCoachMemorySettings } = useProductivityStore();
  
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 6;

  // Form State
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [role, setRole] = useState('');
  const [primaryGoal, setPrimaryGoal] = useState('');
  const [customGoal, setCustomGoal] = useState('');
  const [purpose, setPurpose] = useState('');
  
  // Memory Preferences State
  const [rememberGoals, setRememberGoals] = useState(true);
  const [rememberProjects, setRememberProjects] = useState(true);
  const [rememberDiscussions, setRememberDiscussions] = useState(true);
  const [rememberStyle, setRememberStyle] = useState(true);

  const [validationError, setValidationError] = useState('');

  // Validate current step before proceeding
  const handleNext = () => {
    setValidationError('');

    if (currentStep === 1) {
      if (!name.trim()) {
        setValidationError('Please provide your name to personalize your mentoring.');
        return;
      }
      if (name.trim().length < 2) {
        setValidationError('Your name should be at least 2 characters long.');
        return;
      }
    }

    if (currentStep === 2) {
      if (!age.trim()) {
        setValidationError('Please specify your age to calibrate the guidance.');
        return;
      }
      const parsedAge = parseInt(age, 10);
      if (isNaN(parsedAge) || parsedAge < 10 || parsedAge > 120) {
        setValidationError('Please enter a valid age between 10 and 120.');
        return;
      }
    }

    if (currentStep === 3) {
      if (!role) {
        setValidationError('Please select a professional role to configure the mentor.');
        return;
      }
    }

    if (currentStep === 4) {
      if (!primaryGoal) {
        setValidationError('Please choose a strategic direction to focus the mentor.');
        return;
      }
      if (primaryGoal === 'Custom' && !customGoal.trim()) {
        setValidationError('Please enter your custom goal description.');
        return;
      }
      if (primaryGoal === 'Custom' && customGoal.trim().length < 5) {
        setValidationError('Custom goal should be detailed (at least 5 characters).');
        return;
      }
    }

    if (currentStep === 5) {
      if (!purpose.trim()) {
        setValidationError('Please tell us how you plan to use Mentor-E-Schedule.');
        return;
      }
      if (purpose.trim().length < 10) {
        setValidationError('Please share a bit more details (at least 10 characters).');
        return;
      }
    }

    if (currentStep < totalSteps) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    setValidationError('');
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleComplete = () => {
    // Final save to store
    const finalGoal = primaryGoal === 'Custom' ? customGoal.trim() : primaryGoal;

    updateUserProfile({
      name: name.trim(),
      age: age.trim(),
      role: role,
      primaryGoal: finalGoal,
      purpose: purpose.trim(),
      onboarded: true,
      eloScore: 100,
      level: 'Professional Tier'
    });

    updateCoachMemorySettings({
      rememberGoals,
      rememberProjects,
      rememberDiscussions,
      rememberStyle
    });
  };

  const progressPercentage = (currentStep / totalSteps) * 100;

  return (
    <div className="min-h-screen w-full bg-[#0a0a0c] text-gray-200 flex flex-col justify-center items-center px-4 py-8 relative overflow-hidden" id="onboarding-flow-container">
      {/* Absolute ambient lights */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(212,175,55,0.02),transparent_70%)] pointer-events-none"></div>

      <div className="w-full max-w-xl flex flex-col gap-6 relative z-10">
        {/* APP BRANDING & HERO */}
        <div className="text-center">
          <h2 className="font-serif text-3xl font-extrabold text-[#D4AF37] tracking-wider uppercase drop-shadow-[0_2px_10px_rgba(212,175,55,0.2)]">
            Mentor-E-Schedule
          </h2>
          <p className="text-[10px] font-mono text-gray-500 uppercase tracking-widest mt-1">
            Professional Calibrator & Mentor Pipeline
          </p>
        </div>

        {/* PROGRESS BLOCK */}
        <div className="bg-[#0f1015] border border-gray-800/60 rounded-2xl p-4 flex flex-col gap-2">
          <div className="flex justify-between items-center text-xs">
            <span className="font-mono text-[10px] uppercase text-gray-500 tracking-wider font-bold">Workspace Configuration Progress</span>
            <span className="font-mono text-[#D4AF37] font-black">Step {currentStep} of {totalSteps}</span>
          </div>
          {/* Progress bar background */}
          <div className="w-full h-1.5 bg-gray-900 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${progressPercentage}%` }}
              transition={{ duration: 0.3, ease: 'easeOut' }}
              className="h-full bg-gradient-to-r from-amber-600 via-[#D4AF37] to-amber-500"
            />
          </div>
        </div>

        {/* ERROR DISPLAY */}
        <AnimatePresence mode="wait">
          {validationError && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-rose-950/20 border border-rose-500/20 rounded-xl p-3.5 flex items-start gap-2.5 text-xs text-rose-300"
              id="onboarding-error-banner"
            >
              <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{validationError}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* STEPS CARDS AREA */}
        <div className="bg-[#0f1015] border border-gray-800/80 rounded-3xl shadow-2xl relative overflow-hidden flex flex-col min-h-[380px]">
          {/* Decorative Top Line */}
          <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-amber-500/10 via-[#D4AF37]/50 to-amber-500/10"></div>

          <div className="p-6 sm:p-8 flex-grow flex flex-col justify-center">
            <AnimatePresence mode="wait">
              {currentStep === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-6"
                >
                  <div className="space-y-2">
                    <div className="inline-flex p-2.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl">
                      <User className="w-5 h-5" />
                    </div>
                    <h3 className="font-serif text-lg font-bold text-gray-100">What is your professional name?</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">
                      Your supportive mentor will address you by this name. Keep it clear, authentic, and professional.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-500/80 block">
                      Full Name
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => {
                        setName(e.target.value);
                        if (validationError) setValidationError('');
                      }}
                      placeholder="e.g., Sarah Jenkins"
                      className="w-full bg-black/40 border border-gray-800 hover:border-gray-700 focus:border-amber-500/40 focus:bg-black/60 rounded-xl px-4 py-3.5 text-xs text-gray-100 placeholder-gray-600 outline-none transition-all"
                      id="onboarding-step-1-input"
                      autoFocus
                    />
                  </div>
                </motion.div>
              )}

              {currentStep === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-6"
                >
                  <div className="space-y-2">
                    <div className="inline-flex p-2.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl">
                      <Calendar className="w-5 h-5" />
                    </div>
                    <h3 className="font-serif text-lg font-bold text-gray-100">How old are you?</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">
                      This allows the Mentor Engine to calibrate planning structures and energy buffers that align with your life stage.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-500/80 block">
                      Age (Years)
                    </label>
                    <input
                      type="text"
                      pattern="[0-9]*"
                      value={age}
                      onChange={(e) => {
                        const cleanValue = e.target.value.replace(/[^0-9]/g, '');
                        setAge(cleanValue);
                        if (validationError) setValidationError('');
                      }}
                      placeholder="e.g., 28"
                      className="w-full bg-black/40 border border-gray-800 hover:border-gray-700 focus:border-amber-500/40 focus:bg-black/60 rounded-xl px-4 py-3.5 text-xs text-gray-100 placeholder-gray-600 outline-none transition-all"
                      id="onboarding-step-2-input"
                      autoFocus
                    />
                  </div>
                </motion.div>
              )}

              {currentStep === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-5"
                >
                  <div className="space-y-2">
                    <div className="inline-flex p-2.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl">
                      <Briefcase className="w-5 h-5" />
                    </div>
                    <h3 className="font-serif text-lg font-bold text-gray-100">Select your current role</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">
                      Choose the category that best represents your focus and day-to-day commitments.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[220px] overflow-y-auto pr-1">
                    {ROLES.map((r) => {
                      const isSelected = role === r.value;
                      return (
                        <button
                          key={r.value}
                          type="button"
                          onClick={() => {
                            setRole(r.value);
                            setValidationError('');
                          }}
                          className={`p-3 rounded-xl border text-left transition-all flex flex-col gap-1 cursor-pointer ${
                            isSelected 
                              ? 'bg-amber-500/10 border-amber-500/40 text-amber-200' 
                              : 'bg-black/20 border-gray-800 hover:border-gray-700 hover:bg-black/30 text-gray-300'
                          }`}
                          id={`onboarding-role-option-${r.value}`}
                        >
                          <div className="flex justify-between items-center w-full">
                            <span className="text-xs font-bold">{r.label}</span>
                            {isSelected && <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                          </div>
                          <span className="text-[10px] text-gray-500 leading-tight block">{r.desc}</span>
                        </button>
                      );
                    })}
                  </div>
                </motion.div>
              )}

              {currentStep === 4 && (
                <motion.div
                  key="step4"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-5"
                >
                  <div className="space-y-2">
                    <div className="inline-flex p-2.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl">
                      <Target className="w-5 h-5" />
                    </div>
                    <h3 className="font-serif text-lg font-bold text-gray-100">What is your primary strategic goal?</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">
                      Establish the absolute win condition for your workspace setup.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[170px] overflow-y-auto pr-1">
                    {GOALS.map((g) => {
                      const isSelected = primaryGoal === g.value;
                      return (
                        <button
                          key={g.value}
                          type="button"
                          onClick={() => {
                            setPrimaryGoal(g.value);
                            setValidationError('');
                          }}
                          className={`p-3 rounded-xl border text-left transition-all flex flex-col gap-1 cursor-pointer ${
                            isSelected 
                              ? 'bg-amber-500/10 border-amber-500/40 text-amber-200' 
                              : 'bg-black/20 border-gray-800 hover:border-gray-700 hover:bg-black/30 text-gray-300'
                          }`}
                          id={`onboarding-goal-option-${g.value}`}
                        >
                          <div className="flex justify-between items-center w-full">
                            <span className="text-xs font-bold">{g.label}</span>
                            {isSelected && <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                          </div>
                          <span className="text-[10px] text-gray-500 leading-tight block">{g.desc}</span>
                        </button>
                      );
                    })}
                  </div>

                  {primaryGoal === 'Custom' && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="space-y-2 mt-3"
                    >
                      <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-500 block">
                        Enter Custom Goal Details
                      </label>
                      <input
                        type="text"
                        value={customGoal}
                        onChange={(e) => {
                          setCustomGoal(e.target.value);
                          if (validationError) setValidationError('');
                        }}
                        placeholder="e.g., Self-publish a novel on history and market it online"
                        className="w-full bg-black/40 border border-gray-800 hover:border-gray-700 focus:border-amber-500/40 rounded-xl px-4 py-3 text-xs text-gray-100 placeholder-gray-600 outline-none transition-all"
                        id="onboarding-step-4-custom-input"
                        autoFocus
                      />
                    </motion.div>
                  )}
                </motion.div>
              )}

              {currentStep === 5 && (
                <motion.div
                  key="step5"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-6"
                >
                  <div className="space-y-2">
                    <div className="inline-flex p-2.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl">
                      <Compass className="w-5 h-5" />
                    </div>
                    <h3 className="font-serif text-lg font-bold text-gray-100">Why are you using Mentor-E-Schedule?</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">
                      Describe your challenges, needs, and what you hope to accomplish under the mentor's counsel.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-500/80 block">
                      Purpose Statement (Minimum 10 characters)
                    </label>
                    <textarea
                      value={purpose}
                      onChange={(e) => {
                        setPurpose(e.target.value);
                        if (validationError) setValidationError('');
                      }}
                      placeholder="e.g., I want help planning my studies and projects. I struggle with time blocking and need professional, focused accountability."
                      rows={4}
                      className="w-full bg-black/40 border border-gray-800 hover:border-gray-700 focus:border-amber-500/40 focus:bg-black/60 rounded-xl px-4 py-3 text-xs text-gray-100 placeholder-gray-600 outline-none transition-all resize-none leading-relaxed"
                      id="onboarding-step-5-textarea"
                      autoFocus
                    />
                  </div>
                </motion.div>
              )}

              {currentStep === 6 && (
                <motion.div
                  key="step6"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-5"
                >
                  <div className="space-y-2">
                    <div className="inline-flex p-2.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl">
                      <Brain className="w-5 h-5" />
                    </div>
                    <h3 className="font-serif text-lg font-bold text-gray-100">Mentor Memory Configuration</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">
                      Select which elements of your schedule, discussions, and goals your Senior Mentor should retain to shape subsequent strategies.
                    </p>
                  </div>

                  <div className="space-y-3 pt-2">
                    {/* Checkbox 1 */}
                    <label className="flex items-start gap-3 p-3 rounded-xl border border-gray-800/60 hover:bg-black/10 cursor-pointer transition-all select-none" id="pref-remember-goals">
                      <input
                        type="checkbox"
                        checked={rememberGoals}
                        onChange={(e) => setRememberGoals(e.target.checked)}
                        className="mt-0.5 rounded border-gray-700 text-amber-500 focus:ring-amber-500 focus:ring-offset-gray-900 bg-black"
                      />
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-bold text-gray-200">Remember Goals</span>
                        <span className="text-[10px] text-gray-500 leading-tight">Retains primary goals to align long-term task structures.</span>
                      </div>
                    </label>

                    {/* Checkbox 2 */}
                    <label className="flex items-start gap-3 p-3 rounded-xl border border-gray-800/60 hover:bg-black/10 cursor-pointer transition-all select-none" id="pref-remember-projects">
                      <input
                        type="checkbox"
                        checked={rememberProjects}
                        onChange={(e) => setRememberProjects(e.target.checked)}
                        className="mt-0.5 rounded border-gray-700 text-amber-500 focus:ring-amber-500 focus:ring-offset-gray-900 bg-black"
                      />
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-bold text-gray-200">Remember Projects</span>
                        <span className="text-[10px] text-gray-500 leading-tight">Keeps track of sub-tasks and operational planner structures.</span>
                      </div>
                    </label>

                    {/* Checkbox 3 */}
                    <label className="flex items-start gap-3 p-3 rounded-xl border border-gray-800/60 hover:bg-black/10 cursor-pointer transition-all select-none" id="pref-remember-discussions">
                      <input
                        type="checkbox"
                        checked={rememberDiscussions}
                        onChange={(e) => setRememberDiscussions(e.target.checked)}
                        className="mt-0.5 rounded border-gray-700 text-amber-500 focus:ring-amber-500 focus:ring-offset-gray-900 bg-black"
                      />
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-bold text-gray-200">Remember Discussions</span>
                        <span className="text-[10px] text-gray-500 leading-tight">Maintains key learning takeaways from strategic chat logs.</span>
                      </div>
                    </label>

                    {/* Checkbox 4 */}
                    <label className="flex items-start gap-3 p-3 rounded-xl border border-gray-800/60 hover:bg-black/10 cursor-pointer transition-all select-none" id="pref-remember-working-style">
                      <input
                        type="checkbox"
                        checked={rememberStyle}
                        onChange={(e) => setRememberStyle(e.target.checked)}
                        className="mt-0.5 rounded border-gray-700 text-amber-500 focus:ring-amber-500 focus:ring-offset-gray-900 bg-black"
                      />
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-bold text-gray-200">Remember Working Style</span>
                        <span className="text-[10px] text-gray-500 leading-tight">Understands focus trends, momentum shifts, and peak schedules.</span>
                      </div>
                    </label>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* BOTTOM CONTROLS FOOTER */}
          <div className="px-6 py-4 bg-black/40 border-t border-gray-800/80 flex justify-between items-center rounded-b-3xl">
            {currentStep > 1 ? (
              <button
                type="button"
                onClick={handleBack}
                className="px-4 py-2 text-xs font-bold text-gray-400 hover:text-gray-200 bg-[#12131a] hover:bg-gray-800/50 border border-gray-800 rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                id="onboarding-back-btn"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
            ) : (
              <div /> // Spacer
            )}

            {currentStep < totalSteps ? (
              <button
                type="button"
                onClick={handleNext}
                className="px-5 py-2.5 text-xs font-extrabold text-black bg-[#D4AF37] hover:bg-amber-400 active:scale-[0.98] rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-[0_2px_15px_rgba(212,175,55,0.15)]"
                id="onboarding-next-btn"
              >
                <span>Continue</span>
                <ArrowRight className="w-3.5 h-3.5 text-black" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleComplete}
                className="px-5 py-2.5 text-xs font-extrabold text-black bg-emerald-500 hover:bg-emerald-400 active:scale-[0.98] rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-[0_2px_15px_rgba(16,185,129,0.15)] animate-pulse"
                id="onboarding-complete-btn"
              >
                <span>Deploy Strategy Hub</span>
                <Check className="w-3.5 h-3.5 text-black" />
              </button>
            )}
          </div>
        </div>

        {/* TRUST AND SECURITY NOTE */}
        <div className="text-center text-[10px] text-gray-500/80 leading-relaxed max-w-sm mx-auto flex items-center justify-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]/50 shrink-0" />
          <span>Local execution. Your profiles and configuration are securely cached in your private browser sandbox.</span>
        </div>
      </div>
    </div>
  );
};
