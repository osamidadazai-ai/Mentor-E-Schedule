import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, Mail, Lock, Shield, Sparkles, Brain, Clock, 
  CheckCircle, ArrowRight, Check, Briefcase, Eye, EyeOff 
} from 'lucide-react';
import { useProductivityStore } from '../stores/useProductivityStore';
import { authService } from '../services/authService';

const AVATARS = [
  { id: 'slate', name: 'Slate Gray', class: 'bg-slate-600', color: '#475569' },
  { id: 'amber', name: 'Amber Accent', class: 'bg-amber-600', color: '#d97706' },
  { id: 'emerald', name: 'Emerald Teal', class: 'bg-emerald-600', color: '#059669' },
  { id: 'royal', name: 'Royal Platinum', class: 'bg-indigo-600', color: '#4f46e5' }
];

export const LandingPage: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  
  // Form States
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState('slate');
  
  // Status States
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Zustand Actions
  const { setCurrentUser } = useProductivityStore();

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    // Simple frontend validations
    if (!email.trim() || !password.trim()) {
      setError('Please fill out all required fields.');
      return;
    }

    if (!isLogin && !fullName.trim()) {
      setError('Please provide your full name.');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    setLoading(true);

    try {
      let syncData;
      if (isLogin) {
        // Log in using Firebase Auth service
        syncData = await authService.loginWithEmail(email.trim(), password);
        setSuccess('Welcome back! Loading your workspace...');
      } else {
        // Register using Firebase Auth service
        syncData = await authService.registerWithEmail(
          email.trim(), 
          password, 
          fullName.trim(), 
          selectedAvatar
        );
        setSuccess('Account successfully compiled! Directing to onboarding...');
      }

      // Update Zustand Store
      setTimeout(() => {
        setCurrentUser({
          email: syncData.user.email,
          name: syncData.user.fullName,
          profilePicture: syncData.user.profilePicture,
          onboarded: syncData.user.onboarded
        }, syncData.user.profile || null, syncData.user.workspace || null);
        
        setLoading(false);
      }, 1000);

    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred during authorization.');
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      const syncData = await authService.loginWithGoogle();
      setSuccess('Google Authorization complete! Initializing workspace...');
      
      setTimeout(() => {
        setCurrentUser({
          email: syncData.user.email,
          name: syncData.user.fullName,
          profilePicture: syncData.user.profilePicture,
          onboarded: syncData.user.onboarded
        }, syncData.user.profile || null, syncData.user.workspace || null);
        
        setLoading(false);
      }, 1000);

    } catch (err: any) {
      setError(err.message || 'Google authentication was not completed.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#070709] text-gray-200 flex flex-col relative overflow-hidden" id="landing-page-container">
      {/* Decorative corporate ambient gradients */}
      <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-amber-500/[0.015] rounded-full blur-[140px] pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-indigo-500/[0.015] rounded-full blur-[140px] pointer-events-none"></div>

      {/* HEADER BAR */}
      <header className="w-full max-w-6xl mx-auto px-6 py-6 flex items-center justify-between border-b border-gray-900/40 relative z-20">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-black font-black text-sm shadow-[0_2px_10px_rgba(245,158,11,0.2)]">
            M
          </div>
          <span className="font-serif text-lg font-bold tracking-wider text-gray-100 uppercase">
            Mentor-E-Schedule
          </span>
        </div>
        <button 
          onClick={() => setIsLogin(!isLogin)}
          className="px-4 py-2 border border-gray-800 bg-[#0d0e12]/60 hover:bg-gray-800/40 text-xs font-mono font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer text-gray-300"
        >
          {isLogin ? 'Create Account' : 'Sign In'}
        </button>
      </header>

      {/* HERO & AUTH SECTION */}
      <main className="flex-1 w-full max-w-6xl mx-auto px-6 py-12 md:py-20 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
        
        {/* LEFT COLUMN: SaaS Copy / Product Intro */}
        <div className="lg:col-span-7 space-y-8 text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500/5 border border-amber-500/20 rounded-full text-[10px] font-mono tracking-wider uppercase text-[#D4AF37]">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>SaaS Productivity Workspace</span>
          </div>
          
          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.1]">
            Your Schedule. <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#D4AF37] via-amber-400 to-amber-500">
              Engineered by AI.
            </span>
          </h1>

          <p className="text-sm sm:text-base text-gray-400 max-w-xl leading-relaxed">
            E-Schedule is a professional corporate productivity platform designed to reduce cognitive overload. Seamlessly organize tasks, establish foundational habits, and structure deep-focus sessions with the active guidance of an analytical, supportive AI Mentor.
          </p>

          {/* Core Feature Value Propositions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-4">
            <div className="flex gap-3 items-start">
              <div className="p-2 bg-amber-500/10 rounded-xl text-amber-400 shrink-0">
                <Brain className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-gray-200">Rational AI Mentor</h4>
                <p className="text-[11px] text-gray-400 mt-0.5">Objective, personalized strategy tailored exactly to your specific career path and focus style.</p>
              </div>
            </div>

            <div className="flex gap-3 items-start">
              <div className="p-2 bg-indigo-500/10 rounded-xl text-indigo-400 shrink-0">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-gray-200">Multi-User Workspaces</h4>
                <p className="text-[11px] text-gray-400 mt-0.5">Separate secure planning environments. Your projects, notes, and habits remain strictly yours.</p>
              </div>
            </div>

            <div className="flex gap-3 items-start">
              <div className="p-2 bg-emerald-500/10 rounded-xl text-emerald-400 shrink-0">
                <CheckCircle className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-gray-200">Execution Frameworks</h4>
                <p className="text-[11px] text-gray-400 mt-0.5">Built on the Eisenhower priority quadrants, custom time-locking gates, and momentum scoring.</p>
              </div>
            </div>

            <div className="flex gap-3 items-start">
              <div className="p-2 bg-slate-500/10 rounded-xl text-slate-400 shrink-0">
                <Shield className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-gray-200">Professional Aesthetics</h4>
                <p className="text-[11px] text-gray-400 mt-0.5">A clean, high-contrast dark theme optimized for eye comfort during long planning cycles.</p>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Auth Card */}
        <div className="lg:col-span-5 flex justify-center w-full">
          <div className="w-full max-w-md bg-[#111218] border border-gray-800/80 rounded-2xl overflow-hidden shadow-[0_10px_40px_rgba(0,0,0,0.5)]">
            
            {/* Login / Sign Up Tab Headers */}
            <div className="flex border-b border-gray-900/60 bg-black/20">
              <button
                type="button"
                onClick={() => {
                  setIsLogin(true);
                  setError('');
                  setSuccess('');
                }}
                className={`flex-1 py-4 text-xs font-mono font-bold tracking-wider uppercase transition-all ${
                  isLogin 
                    ? 'text-amber-400 border-b-2 border-amber-500 bg-[#111218]' 
                    : 'text-gray-500 hover:text-gray-300 hover:bg-black/10'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsLogin(false);
                  setError('');
                  setSuccess('');
                }}
                className={`flex-1 py-4 text-xs font-mono font-bold tracking-wider uppercase transition-all ${
                  !isLogin 
                    ? 'text-amber-400 border-b-2 border-amber-500 bg-[#111218]' 
                    : 'text-gray-500 hover:text-gray-300 hover:bg-black/10'
                }`}
              >
                Register
              </button>
            </div>

            <form onSubmit={handleAuthSubmit} className="p-6 space-y-5">
              
              {/* Alert Feedback Messages */}
              <AnimatePresence mode="wait">
                {error && (
                  <motion.div 
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-xs text-rose-400 leading-relaxed"
                  >
                    {error}
                  </motion.div>
                )}
                {success && (
                  <motion.div 
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-xs text-emerald-400 leading-relaxed flex items-center gap-2"
                  >
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{success}</span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Full Name Field (Register only) */}
              {!isLogin && (
                <div className="space-y-1.5 text-left">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                    Full Name
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-500">
                      <User className="w-4 h-4" />
                    </span>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="Jane Doe"
                      className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl pl-9 pr-4 py-2.5 text-xs text-gray-200 placeholder-gray-600 focus:outline-none transition-all"
                    />
                  </div>
                </div>
              )}

              {/* Email Address Field */}
              <div className="space-y-1.5 text-left">
                <label className="text-[10px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                  Email Address
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-500">
                    <Mail className="w-4 h-4" />
                  </span>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@corporate.com"
                    className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl pl-9 pr-4 py-2.5 text-xs text-gray-200 placeholder-gray-600 focus:outline-none transition-all"
                  />
                </div>
              </div>

              {/* Password Field */}
              <div className="space-y-1.5 text-left">
                <label className="text-[10px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                  Password
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-500">
                    <Lock className="w-4 h-4" />
                  </span>
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-[#08080a] border border-gray-800 focus:border-amber-500/50 rounded-xl pl-9 pr-10 py-2.5 text-xs text-gray-200 placeholder-gray-600 focus:outline-none transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-500 hover:text-gray-300"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {!isLogin && (
                  <p className="text-[9.5px] text-gray-500">Password must be at least 6 characters.</p>
                )}
              </div>

              {/* Optional Profile Avatar Selector (Register only) */}
              {!isLogin && (
                <div className="space-y-2 text-left pt-1">
                  <label className="text-[10px] font-mono uppercase tracking-wider text-gray-400 block font-bold">
                    Select Workspace Theme/Avatar (Optional)
                  </label>
                  <div className="grid grid-cols-4 gap-2.5">
                    {AVATARS.map((avatar) => (
                      <button
                        key={avatar.id}
                        type="button"
                        onClick={() => setSelectedAvatar(avatar.id)}
                        className={`p-2 rounded-xl border flex flex-col items-center gap-1.5 cursor-pointer transition-all ${
                          selectedAvatar === avatar.id 
                            ? 'border-amber-500 bg-amber-500/5' 
                            : 'border-gray-800 bg-[#08080a] hover:border-gray-700'
                        }`}
                      >
                        <div className={`w-6 h-6 rounded-lg ${avatar.class} flex items-center justify-center text-white text-[9px] font-bold shadow-sm`}>
                          {avatar.name[0]}
                        </div>
                        <span className="text-[8.5px] font-mono text-gray-400">{avatar.name.split(' ')[0]}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Submit Buttons */}
              <button
                type="submit"
                disabled={loading}
                className="w-full mt-2 py-3 bg-[#D4AF37] hover:bg-amber-500 text-black font-bold text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-[0_4px_15px_rgba(212,175,55,0.15)] flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                {loading ? (
                  <span className="inline-block animate-pulse">Compiling Workspace parameters...</span>
                ) : (
                  <>
                    <span>{isLogin ? 'Enter Workspace' : 'Initialize Workspace'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>

              {/* Decorative Divider */}
              <div className="relative my-4 shrink-0">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-800/80"></div>
                </div>
                <div className="relative flex justify-center text-[10px] uppercase font-mono">
                  <span className="bg-[#0c0d12] px-3 text-gray-500 font-bold">Or access securely via</span>
                </div>
              </div>

              {/* Google Sign-In Button */}
              <button
                type="button"
                disabled={loading}
                onClick={handleGoogleSignIn}
                className="w-full py-2.5 border border-gray-800 bg-[#08080a] hover:bg-gray-800/40 text-xs font-bold text-gray-300 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z" fill="#FBBC05" />
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                </svg>
                <span>Sign in with Google</span>
              </button>

            </form>
          </div>
        </div>

      </main>

      {/* FOOTER */}
      <footer className="border-t border-gray-900/30 py-6 text-center text-[10px] text-gray-600 font-mono relative z-10">
        <div className="max-w-6xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <span>© 2026 Mentor-E-Schedule — Strategic Productivity Workspace.</span>
          <span>Designed with high corporate fidelity and cognitive-alignment frameworks.</span>
        </div>
      </footer>
    </div>
  );
};
