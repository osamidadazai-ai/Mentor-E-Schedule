import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, Shield, Sparkles, Plus, Check, Brain, MessageSquare, 
  Settings, RefreshCw, Compass, AlertCircle, Trash2, HelpCircle 
} from 'lucide-react';
import { useProductivityStore } from '../stores/useProductivityStore';
import { MemorySettings } from './MemorySettings';

interface Message {
  id: string;
  sender: 'user' | 'mentor';
  text: string;
  timestamp: string;
  suggestedActions?: string[];
  appliedActions?: Record<string, boolean>; // track which actions have been added/applied
}

// Robust parser to extract clean conversation and tags from streams
function parseStreamedResponse(text: string) {
  const keys = [
    'SUGGESTED_ACTIONS:',
    'INSIGHT:'
  ];

  let minIdx = -1;
  for (const key of keys) {
    const idx = text.indexOf(key);
    if (idx !== -1) {
      if (minIdx === -1 || idx < minIdx) {
        minIdx = idx;
      }
    }
  }

  const cleanText = minIdx !== -1 ? text.substring(0, minIdx).trim() : text.trim();

  const extractValue = (key: string) => {
    const idx = text.indexOf(key);
    if (idx === -1) return '';
    const content = text.substring(idx + key.length);
    let nextIdx = -1;
    for (const otherKey of keys) {
      if (otherKey === key) continue;
      const oIdx = content.indexOf(otherKey);
      if (oIdx !== -1) {
        if (nextIdx === -1 || oIdx < nextIdx) {
          nextIdx = oIdx;
        }
      }
    }
    return nextIdx !== -1 ? content.substring(0, nextIdx).trim() : content.trim();
  };

  const actionsPart = extractValue('SUGGESTED_ACTIONS:');
  let suggestedActions: string[] = [];
  if (actionsPart) {
    try {
      suggestedActions = JSON.parse(actionsPart);
    } catch {
      suggestedActions = actionsPart
        .replace(/^\[|\]$/g, '')
        .split(',')
        .map(s => s.trim().replace(/^["']|["']$/g, ''))
        .filter(Boolean);
    }
  }

  const insight = extractValue('INSIGHT:').replace(/^["']|["']$/g, '');

  return {
    cleanText,
    suggestedActions,
    insight
  };
}

export const MentorPanel: React.FC = () => {
  // Store integration
  const { 
    coachMemorySettings, 
    updateCoachMemorySettings,
    addTask,
    userProfile
  } = useProductivityStore();

  // Local Chat State
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'mentor',
      text: `Welcome back. I am your supportive career and execution mentor. Feel free to talk to me about what you are working on, any struggles you are experiencing, career directions, or how you want to schedule your upcoming weeks. No judgment, just objective strategy and gentle practical suggestions.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestedActions: [
        "Audit my current priorities for the week",
        "Formulate a plan to handle overwhelming deadlines",
        "Set up a structured schedule for tomorrow"
      ]
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of chat
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Handle message sending
  const handleSend = async (e?: React.FormEvent, customText?: string) => {
    if (e) e.preventDefault();
    
    const textToSend = customText || inputMessage;
    if (!textToSend.trim() || isLoading) return;

    // Add user message to list
    const userMsgId = `msg-${Date.now()}`;
    const newUserMessage: Message = {
      id: userMsgId,
      sender: 'user',
      text: textToSend.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, newUserMessage]);
    if (!customText) setInputMessage('');
    setIsLoading(true);

    // Add mentor message placeholder
    const mentorMsgId = `mentor-${Date.now()}`;
    const newMentorMessage: Message = {
      id: mentorMsgId,
      sender: 'mentor',
      text: 'Analyzing task parameters and formulating the best path forward...',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      appliedActions: {}
    };
    setMessages((prev) => [...prev, newMentorMessage]);

    try {
      // Build history payload, mapping 'mentor' to 'coach' for API compatibility
      const chatHistory = messages.map(m => ({
        sender: m.sender === 'mentor' ? 'coach' : m.sender,
        text: m.text
      }));

      // Post to the free-chat-stream endpoint
      const response = await fetch('/api/coach/free-chat-stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: textToSend.trim(),
          rememberGoals: coachMemorySettings.rememberGoals,
          rememberProjects: coachMemorySettings.rememberProjects,
          rememberDiscussions: coachMemorySettings.rememberDiscussions,
          rememberStyle: coachMemorySettings.rememberStyle,
          history: chatHistory,
          primaryGoal: userProfile.primaryGoal
        })
      });

      if (!response.ok) {
        throw new Error('Consultation network interface returned an error.');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder("utf-8");
      let fullText = '';

      if (reader) {
        let isDone = false;
        while (!isDone) {
          const { done, value } = await reader.read();
          if (done) {
            isDone = true;
            break;
          }
          const chunkStr = decoder.decode(value, { stream: true });
          const lines = chunkStr.split('\n');
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const data = JSON.parse(line.substring(6));
                if (data.chunk) {
                  fullText += data.chunk;
                  
                  // Clean text on the fly to avoid flashing tags to the user
                  const cleaned = fullText
                    .replace(/SUGGESTED_ACTIONS:[\s\S]*/, '')
                    .replace(/INSIGHT:[\s\S]*/, '')
                    .trim();

                  setMessages((prev) =>
                    prev.map((m) =>
                      m.id === mentorMsgId ? { ...m, text: cleaned || 'Formulating...' } : m
                    )
                  );
                }
                if (data.done) {
                  isDone = true;
                }
              } catch (e) {
                // partial/malformed chunk, ignore and continue
              }
            }
          }
        }

        // Final parsing of the complete text
        const parsed = parseStreamedResponse(fullText);
        setMessages((prev) =>
          prev.map((m) =>
            m.id === mentorMsgId
              ? {
                  ...m,
                  text: parsed.cleanText || "I am here. Let's work together to organize your tasks.",
                  suggestedActions: parsed.suggestedActions.length > 0 ? parsed.suggestedActions : undefined
                }
              : m
          )
        );
      }

    } catch (error) {
      console.error("Consultation API error:", error);
      
      // Fallback response with beautiful helpful cards
      setMessages((prev) =>
        prev.map((m) =>
          m.id === mentorMsgId
            ? {
                ...m,
                text: "I encountered a minor interruption in my transmission, but my supportive commitment stands. Let's remain calm and look at what minor controls we can establish right now.",
                suggestedActions: [
                  "Write down the single most urgent matter on my mind",
                  "Dedicate 10 minutes to deep breathing or standard rest",
                  "Reschedule non-urgent work items to next week"
                ]
              }
            : m
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  // User clicks "Apply Suggestion" (creates a task in the store)
  const handleApplySuggestion = (msgId: string, suggestionText: string, index: number) => {
    // Add the task in store with High Impact ('QUEEN') as default
    addTask({
      title: suggestionText,
      priority: 'QUEEN',
      description: 'Suggested by Senior Strategy Mentor'
    });

    // Mark as applied locally in the state
    setMessages((prev) => 
      prev.map((m) => {
        if (m.id === msgId) {
          return {
            ...m,
            appliedActions: {
              ...m.appliedActions,
              [suggestionText]: true
            }
          };
        }
        return m;
      })
    );

    setStatusMessage(`✓ Added task: "${suggestionText}"`);
    setTimeout(() => setStatusMessage(null), 3000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col h-[650px] bg-[#0b0c10] border border-gray-800 rounded-3xl overflow-hidden shadow-2xl" id="mentor-panel-container">
      
      {/* HEADER */}
      <header className="px-6 py-4 border-b border-gray-800 bg-[#0f1015] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-500/10 rounded-xl border border-amber-500/20 text-amber-400">
            <Shield className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="font-serif text-base font-bold text-gray-100 flex items-center gap-1.5">
              <span>Senior Strategy Mentor</span>
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            </h3>
            <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-black block">
              Supportive Professional Mentor
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Clear Chat Button */}
          {messages.length > 0 && (
            <button
              onClick={() => {
                if (window.confirm("Are you sure you want to clear your conversation history?")) {
                  setMessages([]);
                  setStatusMessage("Conversation history cleared.");
                  setTimeout(() => setStatusMessage(null), 3000);
                }
              }}
              className="p-2 rounded-xl border border-gray-800 bg-black/30 text-gray-400 hover:text-rose-400 hover:border-rose-500/30 transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold"
              id="clear-chat-btn"
              title="Clear entire discussion"
            >
              <Trash2 className="w-4 h-4" />
              <span className="hidden sm:inline">Clear Chat</span>
            </button>
          )}

          {/* Settings Toggle */}
          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`p-2 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold ${
              showSettings 
                ? 'bg-amber-500/10 border-amber-500/30 text-amber-300' 
                : 'bg-black/30 border-gray-800/80 text-gray-400 hover:text-gray-300'
            }`}
            title="Mentor memory configuration"
          >
            <Settings className="w-4 h-4" />
            <span className="hidden sm:inline">Mentor Memory</span>
          </button>
        </div>
      </header>

      {/* TOAST NOTIFICATION */}
      <AnimatePresence>
        {statusMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-emerald-500/10 border-b border-emerald-500/20 text-emerald-400 text-[11px] font-sans font-bold px-4 py-2.5 flex items-center justify-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            <span>{statusMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* SETTINGS PANEL (Toggled open/close) */}
      <AnimatePresence>
        {showSettings && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-b border-gray-800/80 bg-[#12131a]"
            id="mentor-memory-settings-dropdown-wrapper"
          >
            <div className="p-4 sm:p-6 max-w-4xl mx-auto">
              <MemorySettings />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* CHAT MESSAGES PANEL */}
      <div className="flex-grow overflow-y-auto p-6 space-y-4 bg-[#0d0e12] scrollbar-thin" id="mentor-messages-area">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center max-w-lg mx-auto py-8 px-4" id="mentor-chat-empty-state">
            <div className="p-4 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-2xl mb-4 animate-pulse">
              <Brain className="w-8 h-8" />
            </div>
            <h4 className="font-serif text-lg font-bold text-gray-100 mb-2">No Active Discussion</h4>
            <p className="text-xs text-gray-400 leading-relaxed mb-6">
              I am your supportive Senior Strategy Mentor. Tap any starter prompt below or write your own thoughts to receive calm, rational, and completely non-judgmental guidance.
            </p>

            <div className="w-full space-y-4">
              <div>
                <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-black block mb-2 text-left">
                  Discuss strategic topics:
                </span>
                <div className="grid grid-cols-2 gap-2 text-left">
                  {[
                    "Productivity & Focus", "Career Direction", "Skill Acquisition",
                    "Active Projects", "Daily Planning", "Managing Frustrations"
                  ].map((topic, idx) => (
                    <div key={idx} className="bg-black/20 border border-gray-850 p-2.5 rounded-xl flex items-center gap-2 text-[11px] text-gray-300">
                      <div className="w-1.5 h-1.5 bg-amber-400 rounded-full shrink-0" />
                      <span>{topic}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-black block mb-2 text-left">
                  Click to ask instantly:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left">
                  {[
                    "I feel overwhelmed.",
                    "I am working but not learning.",
                    "I don't know what to focus on.",
                    "Should I complete my project first?"
                  ].map((exampleText, idx) => (
                    <button
                      key={idx}
                      onClick={(e) => handleSend(e, exampleText)}
                      className="bg-[#12131a] hover:bg-[#12131a]/80 border border-gray-800 hover:border-amber-500/25 text-gray-300 hover:text-amber-300 p-3 rounded-xl text-xs transition-all cursor-pointer font-medium leading-tight flex items-start gap-2 text-left"
                    >
                      <HelpCircle className="w-3.5 h-3.5 text-amber-400/80 shrink-0 mt-0.5" />
                      <span>"{exampleText}"</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          messages.map((message) => {
          const isMentor = message.sender === 'mentor';
          return (
            <div 
              key={message.id} 
              className={`flex items-start gap-3.5 max-w-[85%] ${
                isMentor ? 'mr-auto' : 'ml-auto flex-row-reverse'
              }`}
            >
              {/* Avatar Icon */}
              <div className={`p-2 rounded-xl shrink-0 ${
                isMentor 
                  ? 'bg-amber-500/10 border border-amber-500/20 text-amber-400' 
                  : 'bg-indigo-500/10 border border-indigo-500/20 text-indigo-400'
              }`}>
                {isMentor ? <Brain className="w-4 h-4" /> : <Compass className="w-4 h-4" />}
              </div>

              {/* Message Bubble */}
              <div className="space-y-3">
                <div className={`p-4 rounded-2xl text-xs leading-relaxed border ${
                  isMentor 
                    ? 'bg-[#12131a] border-gray-800/80 text-gray-300 rounded-tl-none' 
                    : 'bg-indigo-950/20 border-indigo-500/15 text-gray-200 rounded-tr-none'
                }`}>
                  <p className="whitespace-pre-line">{message.text}</p>
                  
                  <span className="text-[9px] font-mono text-gray-500 block text-right mt-2">
                    {message.timestamp}
                  </span>
                </div>

                {/* AI Suggestions appear as beautiful, distinct cards with custom apply hooks */}
                {isMentor && message.suggestedActions && message.suggestedActions.length > 0 && (
                  <div className="space-y-2 mt-2">
                    <span className="text-[10px] font-mono text-amber-500/70 font-bold uppercase tracking-wider block">
                      💡 Suggested Practical Steps:
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {message.suggestedActions.map((action, idx) => {
                        const isApplied = message.appliedActions?.[action];
                        return (
                          <div 
                            key={idx}
                            className={`p-3 rounded-xl border flex flex-col justify-between gap-2.5 transition-all bg-[#0f1015] ${
                              isApplied 
                                ? 'border-emerald-500/30 opacity-75' 
                                : 'border-gray-800 hover:border-gray-700'
                            }`}
                          >
                            <p className="text-[11px] text-gray-300 font-sans font-medium line-clamp-3">
                              {action}
                            </p>
                            
                            <button
                              onClick={() => handleApplySuggestion(message.id, action, idx)}
                              disabled={isApplied}
                              className={`w-full py-1.5 px-3 rounded-lg font-sans font-bold text-[10px] uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                                isApplied 
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 cursor-default' 
                                  : 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/20'
                              }`}
                            >
                              {isApplied ? (
                                <>
                                  <Check className="w-3 h-3" />
                                  <span>Added to Board</span>
                                </>
                              ) : (
                                <>
                                  <Plus className="w-3 h-3" />
                                  <span>Apply Suggestion</span>
                                </>
                              )}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })
      )}

        {/* LOADING INDICATOR */}
        {isLoading && (
          <div className="flex items-center gap-2.5 mr-auto max-w-[80%]">
            <div className="p-2 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl shrink-0 animate-bounce">
              <Brain className="w-4 h-4" />
            </div>
            <div className="bg-[#12131a] border border-gray-800/80 p-4 rounded-2xl rounded-tl-none flex items-center gap-2">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
              <span className="text-xs text-gray-500">Mentor is reviewing objectives...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* QUICK SUGGESTED CONVERSATION PROMPTS */}
      <div className="px-6 py-2.5 bg-[#0f1015]/40 border-t border-gray-800/40 flex items-center gap-2 overflow-x-auto whitespace-nowrap scrollbar-none">
        <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest font-black shrink-0">
          Topics:
        </span>
        {[
          "I am feeling completely overwhelmed",
          "Help me clarify my long-term career focus",
          "Evaluate my workload for this week",
          "How can I manage low focus blocks?"
        ].map((promptText, idx) => (
          <button
            key={idx}
            onClick={(e) => handleSend(e, promptText)}
            disabled={isLoading}
            className="bg-[#12131a]/80 hover:bg-[#12131a] border border-gray-800/80 hover:border-amber-500/20 text-gray-400 hover:text-gray-300 px-3 py-1.5 rounded-full text-[10px] transition-all cursor-pointer inline-block shrink-0"
          >
            {promptText}
          </button>
        ))}
      </div>

      {/* INPUT FORM */}
      <form onSubmit={handleSend} className="p-4 bg-[#0f1015] border-t border-gray-800 flex items-center gap-3" id="mentor-chat-form">
        <input 
          type="text"
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          disabled={isLoading}
          placeholder="Discuss your current struggles, planning doubts, or ask for guidance..."
          className="flex-grow bg-black/40 border border-gray-850 hover:border-gray-800 focus:border-amber-500/30 rounded-2xl px-4 py-3 text-xs text-gray-200 placeholder-gray-600 focus:outline-none transition-all"
        />

        <button
          type="submit"
          disabled={!inputMessage.trim() || isLoading}
          className="bg-amber-500 hover:brightness-110 disabled:opacity-45 text-black p-3.5 rounded-2xl transition-all cursor-pointer flex items-center justify-center shrink-0"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>

    </div>
  );
};
