import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle, Clock, Calendar as CalendarIcon, Award, TrendingUp, 
  Flame, Sparkles, ChevronLeft, ChevronRight, CheckCircle2, AlertCircle
} from 'lucide-react';
import { useProductivityStore } from '../stores/useProductivityStore';
import { DeadlineRadar } from './DeadlineRadar';

interface DashboardProps {
  onNavigateToMentor?: () => void;
  onNavigateToBoard?: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ 
  onNavigateToMentor,
  onNavigateToBoard
}) => {
  // Zustand Store Hooks
  const {
    tasks,
    userProfile,
    analytics,
    completeTask,
    deferTask,
    deleteTask,
    getTodaysTasks
  } = useProductivityStore();

  const todaysTasks = getTodaysTasks();

  // Active dates for Weekly Calendar view
  const [calendarOffset, setCalendarOffset] = useState(0); // offset in weeks
  const [selectedCalendarDate, setSelectedCalendarDate] = useState(() => new Date().toISOString().split('T')[0]);

  // Generate 7 days of the weekly calendar based on offset
  const getWeeklyDays = () => {
    const days = [];
    const today = new Date();
    today.setDate(today.getDate() + (calendarOffset * 7));
    
    // Get Monday of that week
    const day = today.getDay();
    const diff = today.getDate() - day + (day === 0 ? -6 : 1);
    const monday = new Date(today.setDate(diff));

    for (let i = 0; i < 7; i++) {
      const nextDay = new Date(monday);
      nextDay.setDate(monday.getDate() + i);
      days.push(nextDay);
    }
    return days;
  };

  const weeklyDays = getWeeklyDays();

  // Get responsive dynamic greeting based on time of day
  const getDynamicGreeting = () => {
    const hour = new Date().getHours();
    const name = userProfile?.name || 'Avi';
    if (hour < 12) return `Good Morning, ${name}`;
    if (hour < 17) return `Good Afternoon, ${name}`;
    return `Good Evening, ${name}`;
  };

  // Generate premium dynamic advice based on current schedule context
  const getCoachAdvice = () => {
    const activeKingTasks = todaysTasks.filter(t => t.priority === 'KING');
    const totalCount = todaysTasks.length;
    
    if (totalCount === 0) {
      return {
        tip: "Your agenda for today is fully clear.",
        insight: "Use this quiet interval to reflect on long-term strategy, register foundational habits, or engage in skill development."
      };
    }
    if (activeKingTasks.length > 0) {
      return {
        tip: `You have ${activeKingTasks.length} critical ${activeKingTasks.length === 1 ? 'task' : 'tasks'} to address today.`,
        insight: `Ensure you block out focused, high-energy time to resolve "${activeKingTasks[0].title}" first. Protect this slot from cognitive distractions.`
      };
    }
    return {
      tip: "Your schedule is well-proportioned today.",
      insight: "Focus on maintaining steady operational pacing. Complete tasks systematically to expand your ELO momentum score."
    };
  };

  const advice = getCoachAdvice();

  const getPriorityLabel = (priority: 'KING' | 'QUEEN' | 'ROOK' | 'PAWN') => {
    switch (priority) {
      case 'KING': return 'Critical Priority';
      case 'QUEEN': return 'High Impact';
      case 'ROOK': return 'Standard Operation';
      case 'PAWN': return 'Foundational Growth';
      default: return 'Standard';
    }
  };

  const getPriorityBadgeColor = (priority: 'KING' | 'QUEEN' | 'ROOK' | 'PAWN') => {
    switch (priority) {
      case 'KING': return 'bg-rose-500/10 border-rose-500/30 text-rose-400';
      case 'QUEEN': return 'bg-amber-500/10 border-amber-500/30 text-amber-300';
      case 'ROOK': return 'bg-sky-500/10 border-sky-500/30 text-sky-400';
      case 'PAWN': return 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400';
      default: return 'bg-gray-500/10 border-gray-500/30 text-gray-400';
    }
  };

  const getPriorityBorderColor = (priority: 'KING' | 'QUEEN' | 'ROOK' | 'PAWN') => {
    switch (priority) {
      case 'KING': return 'border-rose-500/20 hover:border-rose-500/40';
      case 'QUEEN': return 'border-amber-500/20 hover:border-amber-500/40';
      case 'ROOK': return 'border-sky-500/20 hover:border-sky-500/40';
      case 'PAWN': return 'border-emerald-500/20 hover:border-emerald-500/40';
      default: return 'border-gray-800 hover:border-gray-700';
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-1 py-2 space-y-8 text-gray-200" id="dashboard-container">
      
      {/* 1. GREETING HEADER SECTION */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pt-2">
        <div className="space-y-1">
          <h2 className="font-serif text-3xl font-extrabold text-[#D4AF37] tracking-tight" id="dashboard-greeting-title">
            {getDynamicGreeting()}
          </h2>
          <p className="text-xs text-gray-400">
            Welcome back to your workspace. Here is your daily strategic focus overview.
          </p>
        </div>
        <div className="text-right text-xs font-mono text-gray-500 bg-gray-900/40 border border-gray-800/80 rounded-xl px-4 py-2">
          <span className="text-gray-400 font-bold block">Current Status</span>
          <span className="text-[#D4AF37] font-semibold">{userProfile.level}</span>
        </div>
      </div>

      {/* 2. TODAY'S PROGRESS & QUICK STATISTICS */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4" id="stats-summary-grid">
        {/* Rating/Level Card */}
        <div className="bg-[#0f1015] border border-gray-800/80 rounded-2xl p-5 flex items-center justify-between shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/[0.015] rounded-full blur-2xl group-hover:bg-amber-500/[0.03] transition-all"></div>
          <div className="space-y-1 z-10">
            <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-black block">Strategy Rating</span>
            <div className="text-2xl font-bold font-serif text-amber-400">{userProfile.eloScore} ELO</div>
            <p className="text-[11px] text-gray-400">{userProfile.level}</p>
          </div>
          <div className="p-3 bg-amber-500/10 rounded-xl text-amber-400 z-10">
            <Award className="w-5 h-5" />
          </div>
        </div>

        {/* Completion Rate Card */}
        <div className="bg-[#0f1015] border border-gray-800/80 rounded-2xl p-5 flex items-center justify-between shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/[0.015] rounded-full blur-2xl group-hover:bg-emerald-500/[0.03] transition-all"></div>
          <div className="space-y-1 z-10">
            <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-black block">Completion Rate</span>
            <div className="text-2xl font-bold font-serif text-emerald-400">{analytics.completionRate}%</div>
            <div className="w-24 bg-gray-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div 
                className="bg-emerald-500 h-full rounded-full transition-all duration-500" 
                style={{ width: `${analytics.completionRate}%` }}
              ></div>
            </div>
          </div>
          <div className="p-3 bg-emerald-500/10 rounded-xl text-emerald-400 z-10">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        {/* Tasks Completed Card */}
        <div className="bg-[#0f1015] border border-gray-800/80 rounded-2xl p-5 flex items-center justify-between shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/[0.015] rounded-full blur-2xl group-hover:bg-blue-500/[0.03] transition-all"></div>
          <div className="space-y-1 z-10">
            <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-black block">Tasks Solved</span>
            <div className="text-2xl font-bold font-serif text-blue-400">{analytics.tasksCompletedCount}</div>
            <p className="text-[11px] text-gray-400">Archived completed items</p>
          </div>
          <div className="p-3 bg-blue-500/10 rounded-xl text-blue-400 z-10">
            <CheckCircle className="w-5 h-5" />
          </div>
        </div>

        {/* Streak Counter Card */}
        <div className="bg-[#0f1015] border border-gray-800/80 rounded-2xl p-5 flex items-center justify-between shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-rose-500/[0.015] rounded-full blur-2xl group-hover:bg-rose-500/[0.03] transition-all"></div>
          <div className="space-y-1 z-10">
            <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-black block">Daily Streak</span>
            <div className="text-2xl font-bold font-serif text-rose-400">{analytics.streakDays} Days</div>
            <p className="text-[11px] text-gray-400">Total focus: {analytics.totalFocusMinutes}m</p>
          </div>
          <div className="p-3 bg-rose-500/10 rounded-xl text-rose-400 z-10">
            <Flame className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 3. RECENT COACH SUGGESTION */}
      <div className="bg-gradient-to-r from-[#0c0d12] to-[#141520] border border-[#D4AF37]/20 rounded-3xl p-6 shadow-xl relative overflow-hidden group" id="coach-advice-panel">
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/[0.02] rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex items-start gap-4">
          <div className="p-3 bg-[#D4AF37]/10 rounded-2xl text-[#D4AF37] border border-[#D4AF37]/20 shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-mono text-[#D4AF37] uppercase tracking-widest font-black">Strategic Guidance</span>
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
              <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">Recent Advice</span>
            </div>
            <h4 className="font-serif text-sm font-bold text-gray-200">{advice.tip}</h4>
            <p className="text-[11px] text-gray-400 leading-relaxed max-w-3xl">
              {advice.insight}
            </p>
          </div>
        </div>
      </div>

      {/* 4. CALENDAR TIMELINE (Tactical Weekly Grid) */}
      <div className="bg-[#0b0c10] border border-gray-800 rounded-3xl p-6 shadow-lg space-y-4" id="weekly-calendar-grid-card">
        <div className="flex items-center justify-between border-b border-gray-800/80 pb-3">
          <div className="flex items-center gap-2">
            <CalendarIcon className="w-4.5 h-4.5 text-amber-400" />
            <h3 className="font-serif text-sm font-bold text-gray-100 uppercase tracking-wider">Tactical Calendar Timeline</h3>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCalendarOffset(prev => prev - 1)}
              className="p-1.5 bg-black/40 hover:bg-gray-800 rounded-lg border border-gray-800 text-gray-400 transition-all cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setCalendarOffset(0)}
              className="px-2.5 py-1.5 bg-black/40 hover:bg-gray-800 rounded-lg border border-gray-800 text-[9px] font-mono text-gray-400 transition-all cursor-pointer"
            >
              Current Week
            </button>
            <button
              onClick={() => setCalendarOffset(prev => prev + 1)}
              className="p-1.5 bg-black/40 hover:bg-gray-800 rounded-lg border border-gray-800 text-gray-400 transition-all cursor-pointer"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 7 Days Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
          {weeklyDays.map((dayDate, i) => {
            const formattedISO = dayDate.toISOString().split('T')[0];
            const isToday = formattedISO === new Date().toISOString().split('T')[0];
            const isSelected = formattedISO === selectedCalendarDate;
            
            const weekdayName = dayDate.toLocaleDateString('en-US', { weekday: 'short' });
            const dayNum = dayDate.getDate();

            // Find tasks scheduled for this day
            const scheduledTasks = tasks.filter(t => !t.completed && t.dueDate === formattedISO);

            return (
              <div
                key={i}
                onClick={() => setSelectedCalendarDate(formattedISO)}
                className={`p-3 rounded-2xl border text-left cursor-pointer transition-all space-y-2 min-h-[110px] flex flex-col justify-between ${
                  isSelected 
                    ? 'bg-[#D4AF37]/10 border-[#D4AF37]/50 text-[#D4AF37]' 
                    : isToday
                      ? 'bg-[#D4AF37]/5 border-gray-700 text-amber-200'
                      : 'bg-black/10 border-gray-800/80 hover:border-gray-700/60 text-gray-400'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className="text-[10px] uppercase font-mono font-black">{weekdayName}</span>
                  <span className={`text-xs font-sans font-bold flex items-center justify-center w-5.5 h-5.5 rounded-full ${
                    isToday ? 'bg-[#D4AF37] text-black font-black' : ''
                  }`}>{dayNum}</span>
                </div>

                <div className="flex-grow space-y-1">
                  {scheduledTasks.slice(0, 2).map((task) => (
                    <div 
                      key={task.id} 
                      className="bg-[#12131a] border border-gray-800/50 p-1 px-1.5 rounded-lg text-[9px] text-gray-300 font-sans truncate font-medium block"
                      title={`${task.title} (${task.startTime || 'No time'})`}
                    >
                      {task.startTime && <span className="text-[#D4AF37] font-bold mr-0.5">{task.startTime}</span>} {task.title}
                    </div>
                  ))}
                  {scheduledTasks.length > 2 && (
                    <span className="text-[8px] text-gray-500 block font-mono">+{scheduledTasks.length - 2} more</span>
                  )}
                  {scheduledTasks.length === 0 && (
                    <div className="text-[8px] text-gray-600 italic">No tasks</div>
                  )}
                </div>

                <div className="text-[8px] text-right font-mono text-gray-500">
                  {scheduledTasks.length} {scheduledTasks.length === 1 ? 'task' : 'tasks'}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 5. TWO COLUMN MAIN CONTENT GRID (Today's Tasks & Upcoming Deadlines) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="dashboard-main-grid">
        
        {/* TODAY'S AGENDA (Left & Center Columns) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#0b0c10] border border-gray-800 rounded-3xl p-6 shadow-lg space-y-4" id="todays-tasks-card">
            <div className="flex items-center justify-between border-b border-gray-800/80 pb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <h3 className="font-serif text-base font-bold text-gray-100 uppercase tracking-wider">Today's Active Tasks</h3>
              </div>
              <span className="bg-amber-500/5 text-amber-400 text-[10px] font-mono px-2.5 py-0.5 rounded-full border border-amber-500/20 font-bold uppercase tracking-wider">
                {todaysTasks.length} Pending
              </span>
            </div>

            {todaysTasks.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-emerald-500/5 border border-emerald-500/10 text-emerald-400">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <p className="text-gray-500 text-xs">All done! No pending tasks are scheduled for today.</p>
                {onNavigateToBoard && (
                  <button 
                    onClick={onNavigateToBoard}
                    className="text-[#D4AF37] hover:text-amber-300 text-[11px] font-sans font-bold flex items-center gap-1 mx-auto hover:underline"
                  >
                    <span>View Task Board</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1 scrollbar-thin">
                <AnimatePresence initial={false}>
                  {todaysTasks.map((task) => (
                    <motion.div
                      key={task.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      className={`p-4 rounded-xl bg-[#12131a]/80 border ${getPriorityBorderColor(task.priority)} transition-all flex items-start justify-between gap-3`}
                    >
                      <div className="flex items-start gap-3 flex-grow min-w-0">
                        {/* Checkbox */}
                        <button 
                          onClick={() => completeTask(task.id)}
                          className="mt-0.5 w-4.5 h-4.5 rounded border border-gray-700 hover:border-emerald-500/50 flex items-center justify-center cursor-pointer transition-all hover:bg-emerald-500/10 group shrink-0"
                        >
                          <CheckCircle className="w-3.5 h-3.5 text-transparent group-hover:text-emerald-500 transition-colors" />
                        </button>

                        <div className="flex-grow space-y-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <h4 className="font-sans font-bold text-xs text-gray-100 truncate">{task.title}</h4>
                            <span className={`text-[8.5px] font-bold px-2 py-0.5 rounded-full border uppercase tracking-wider shrink-0 ${getPriorityBadgeColor(task.priority)}`}>
                              {getPriorityLabel(task.priority)}
                            </span>
                          </div>
                          {task.description && (
                            <p className="text-[11px] text-gray-500 leading-normal line-clamp-2">{task.description}</p>
                          )}
                          <div className="flex items-center gap-3 text-[10px] text-gray-550 font-mono">
                            {task.startTime && (
                              <span className="flex items-center gap-1 text-sky-400/80 font-bold">
                                <Clock className="w-3 h-3" />
                                {task.startTime} ({task.durationMinutes || 30}m)
                              </span>
                            )}
                            <span className="text-amber-500/80 font-semibold">Today</span>
                          </div>
                        </div>
                      </div>

                      {/* Operations */}
                      <div className="flex items-center gap-1.5 shrink-0 ml-2">
                        <button 
                          onClick={() => deferTask(task.id, 1)}
                          className="bg-black/40 hover:bg-amber-500/10 hover:text-amber-400 text-gray-400 px-2 py-1.5 rounded-lg border border-transparent hover:border-amber-500/25 text-[9.5px] font-bold uppercase tracking-wider transition-all cursor-pointer"
                          title="Defer this task by 1 day"
                        >
                          Defer
                        </button>
                        <button 
                          onClick={() => deleteTask(task.id)}
                          className="bg-black/40 hover:bg-rose-500/10 text-gray-500 hover:text-rose-400 p-1.5 rounded-lg transition-all cursor-pointer border border-transparent hover:border-rose-500/25"
                          title="Discard task"
                        >
                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                          </svg>
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>

        {/* UPCOMING TASKS DEADLINE RADAR (Right Column) */}
        <div className="space-y-6">
          <div className="rounded-3xl border border-gray-800 bg-[#0b0c10] shadow-lg overflow-hidden">
            <div className="p-4 border-b border-gray-800 bg-black/10">
              <span className="text-[10px] font-mono text-[#D4AF37] uppercase tracking-widest block font-black mb-1">Upcoming Deadlines</span>
              <h3 className="font-serif text-sm font-bold text-gray-100 uppercase tracking-wider">Deadline Radar</h3>
            </div>
            <div className="p-2">
              <DeadlineRadar />
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
