import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, CheckCircle2, Clock, Trash2, Swords, Play, Pause, RotateCcw, 
  Skull, Trophy
} from 'lucide-react';
import { Task, ChessRank } from '../types';

interface LayerBoardProps {
  tasks: Task[];
  onToggleTask: (id: string) => void;
  onDeleteTask: (id: string) => void;
  onReturnToPortal: () => void;
  onClearAll: () => void;
  onTriggerBlunder: (task: Task) => void;
}

export const LayerBoard: React.FC<LayerBoardProps> = ({
  tasks,
  onToggleTask,
  onDeleteTask,
  onReturnToPortal,
  onClearAll,
  onTriggerBlunder
}) => {
  // Timer state
  const [minutes, setMinutes] = useState(25);
  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [isDeadlineMissed, setIsDeadlineMissed] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Filter tasks that are completed vs active
  const activeTasks = tasks.filter(t => !t.isProposed);

  // Priority Definitions matching professional terminology
  const rankDefinitions = {
    'King': {
      title: 'CRITICAL PRIORITY',
      desc: 'High-urgency, critical tasks to resolve immediately. Core progress makers.',
      color: 'border-rose-500/25 text-rose-400 bg-rose-950/[0.03]',
      icon: '🔴',
    },
    'Queen': {
      title: 'HIGH PRIORITY',
      desc: 'Strategic, high-impact tasks. Schedule these for peak focused effort.',
      color: 'border-amber-500/25 text-amber-400 bg-amber-950/[0.03]',
      icon: '🔶',
    },
    'Rook': {
      title: 'MEDIUM PRIORITY',
      desc: 'Routine operations, communication, and essential maintenance. Best batched.',
      color: 'border-blue-500/25 text-blue-400 bg-blue-950/[0.03]',
      icon: '🔷',
    },
    'Pawn': {
      title: 'LOW PRIORITY',
      desc: 'Personal well-being, skill-building, and background tasks. Vital for long-term health.',
      color: 'border-emerald-500/25 text-emerald-400 bg-emerald-950/[0.03]',
      icon: '🟢',
    },
  };

  const triggerTimerExpirationBlunder = () => {
    setIsActive(false);
    setMinutes(25);
    setSeconds(0);
    const uncompleted = activeTasks.find(t => !t.completed && (t.rank === 'King' || t.rank === 'Queen'))
                     || activeTasks.find(t => !t.completed);
    if (uncompleted) {
      onTriggerBlunder(uncompleted);
    } else {
      onTriggerBlunder({
        id: 'placeholder-blunder',
        title: 'Maintain Consistent Progress',
        description: 'No uncompleted tasks were registered, but your deep focus timer has fully elapsed.',
        completed: false,
        rank: 'King'
      });
    }
  };

  // Timer Tick Logic
  useEffect(() => {
    if (isActive) {
      timerRef.current = setInterval(() => {
        if (seconds > 0) {
          setSeconds(prev => prev - 1);
        } else if (minutes > 0) {
          setMinutes(prev => prev - 1);
          setSeconds(59);
        } else {
          // Timer reached 0:00! Missed deadline penalty triggered
          triggerTimerExpirationBlunder();
        }
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, minutes, seconds]);

  const toggleTimer = () => setIsActive(prev => !prev);
  const resetTimer = () => {
    setIsActive(false);
    setMinutes(25);
    setSeconds(0);
    setIsDeadlineMissed(false);
  };

  // Direct simulation of missed deadline / neglecting key tasks
  const handleSimulateFailure = () => {
    triggerTimerExpirationBlunder();
  };

  const getTasksByRank = (rank: ChessRank) => {
    return activeTasks.filter(t => t.rank === rank);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="w-full max-w-5xl mx-auto px-4 py-4 space-y-8"
      id="layer-board-container"
    >
      {/* Top action header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-amber-500/10 pb-4">
        <button
          onClick={onReturnToPortal}
          className="bg-black hover:bg-[#121319] border border-[#D4AF37]/30 hover:border-[#D4AF37] text-[#D4AF37] font-serif text-xs font-bold px-4 py-2.5 rounded-xl transition-all cursor-pointer flex items-center gap-2 shadow-sm"
          id="btn-return-to-portal"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Portal</span>
        </button>

        <div className="flex items-center gap-3">
          <button
            onClick={onClearAll}
            className="text-[10px] font-mono border border-red-500/20 text-red-400 hover:bg-red-950/20 px-3 py-2 rounded-xl transition-all cursor-pointer"
            id="board-clear-all-btn"
          >
            Reset Workspace Tasks
          </button>
        </div>
      </div>

      {/* Failure penalty block */}
      <AnimatePresence>
        {isDeadlineMissed && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="bg-[#0a0a0a] border-2 border-red-900/50 rounded-3xl p-6 sm:p-8 relative flex flex-col md:flex-row items-center gap-6 shadow-[0_0_40px_rgba(139,0,0,0.2)]"
            id="blunder-penalty-container"
          >
            {/* Crimson bordered alert image */}
            <div className="shrink-0 relative">
              <div className="absolute inset-0 bg-red-600/15 rounded-2xl blur-lg pointer-events-none animate-pulse"></div>
              <img
                src="https://placehold.co/200x200/111/8B0000?text=ACTION+REQUIRED"
                className="w-32 h-32 rounded-2xl border-2 border-red-800 object-cover shadow-[0_0_20px_rgba(139,0,0,0.5)] relative z-10 select-none"
                alt="ACTION REQUIRED"
                referrerPolicy="no-referrer"
                id="blunder-alert-img"
              />
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-black border border-red-600 text-red-500 text-[8px] font-mono px-2.5 py-0.5 rounded-full z-20 font-bold uppercase tracking-widest whitespace-nowrap">
                Review Workspace Priorities
              </div>
            </div>

            <div className="flex-grow space-y-4 text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-2 text-red-400 font-mono text-[10px] font-bold uppercase tracking-widest">
                <Skull className="w-4 h-4 text-red-500 animate-bounce" />
                <span>Neglected Priority Alert</span>
              </div>
              <h4 className="font-serif text-xl font-bold text-red-200">
                Action Plan Needs Review
              </h4>
              <p className="font-serif text-red-100/80 text-xs sm:text-sm leading-relaxed italic">
                "Critical objectives have been deferred or left incomplete. Re-evaluate your focus, streamline your scheduling, and address immediate high-priority objectives to maintain momentum."
              </p>
              <div className="flex flex-wrap gap-2.5 pt-2 justify-center md:justify-start">
                <button
                  onClick={resetTimer}
                  className="bg-red-900/30 hover:bg-red-900/50 border border-red-500/30 hover:border-red-400 text-red-200 font-serif text-[10.5px] font-bold px-4 py-2 rounded-xl transition-all uppercase tracking-widest cursor-pointer"
                  id="penalty-earn-absolution"
                >
                  Clear Priority Warning (Reset Timer)
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* STRATEGIC FOCUS TIMER */}
      <div className="bg-[#0a0a0a] border-2 border-[#D4AF37]/20 rounded-3xl p-6 shadow-[0_4px_35px_rgba(212,175,55,0.03)] relative overflow-hidden" id="chess-time-dial-card">
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/[0.01] rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1.5 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 text-amber-500 font-mono text-[9px] font-bold uppercase tracking-widest">
              <Clock className="w-3.5 h-3.5" />
              <span>Strategic Focus Timer</span>
            </div>
            <h3 className="font-serif text-lg font-bold text-amber-100">
              Deep Professional Focus Session
            </h3>
            <p className="text-xs text-gray-500 font-sans max-w-sm">
              Maximize your high-impact critical priorities before time runs dry to prevent strategic bottlenecks and maintain steady daily progress.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-6">
            {/* The Digital Clock */}
            <div className="font-mono text-4xl sm:text-5xl font-extrabold text-[#D4AF37] tabular-nums tracking-wider bg-black/40 border border-[#D4AF37]/15 px-6 py-3 rounded-2xl shadow-inner min-w-[140px] text-center" id="board-clock-timer">
              {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
            </div>

            {/* Controls */}
            <div className="flex items-center gap-2">
              <button
                onClick={toggleTimer}
                className={`w-11 h-11 rounded-xl flex items-center justify-center border transition-all cursor-pointer shadow-md ${
                  isActive 
                    ? 'bg-amber-500/10 border-amber-500 text-amber-400' 
                    : 'bg-[#D4AF37] border-[#D4AF37] text-black hover:brightness-110'
                }`}
                title={isActive ? "Pause Focus" : "Begin Focus"}
                id="btn-timer-play-pause"
              >
                {isActive ? <Pause className="w-4 h-4 stroke-[2.5]" /> : <Play className="w-4 h-4 fill-current" />}
              </button>

              <button
                onClick={resetTimer}
                className="w-11 h-11 bg-black/60 hover:bg-[#121319] border border-slate-800 hover:border-amber-500/30 text-gray-400 hover:text-[#D4AF37] rounded-xl flex items-center justify-center transition-all cursor-pointer"
                title="Reset Hour"
                id="btn-timer-reset"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              <button
                onClick={handleSimulateFailure}
                className="text-[9.5px] font-mono border border-red-500/20 text-red-400 hover:bg-red-950/20 px-3 py-3 rounded-xl transition-all cursor-pointer font-bold uppercase tracking-widest"
                title="Force timer to end"
                id="btn-simulate-fail"
              >
                Simulate Miss
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* STRATEGIC OBJECTIVES PLANNED */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-amber-500/10 pb-2">
          <h3 className="font-serif text-sm font-bold tracking-widest text-[#D4AF37] uppercase flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-500/70" />
            <span>Strategic Priorities Planner</span>
          </h3>
          <span className="font-mono text-[9.5px] text-gray-500 uppercase tracking-widest">
            {activeTasks.length} Active Task{activeTasks.length !== 1 ? 's' : ''}
          </span>
        </div>

        {activeTasks.length === 0 ? (
          <div className="text-center py-12 bg-[#0a0a0a] border-2 border-dashed border-[#D4AF37]/15 rounded-3xl flex flex-col items-center justify-center gap-3">
            <Trophy className="w-8 h-8 text-amber-500/30" />
            <p className="font-serif text-sm text-amber-500/60 italic">
              "Your task planner lies empty. Define a primary strategic goal and add some actionable tasks to start."
            </p>
            <button
              onClick={onReturnToPortal}
              className="bg-[#D4AF37]/10 hover:bg-[#D4AF37]/20 border border-[#D4AF37]/30 text-[#D4AF37] font-serif text-xs font-bold px-4 py-2 rounded-xl transition-all cursor-pointer"
            >
              Go to Goal Portal
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="dashboard-rank-grid">
            {(['King', 'Queen', 'Rook', 'Pawn'] as ChessRank[]).map((rank) => {
              const def = rankDefinitions[rank];
              const rankTasks = getTasksByRank(rank);

              return (
                <div
                  key={rank}
                  className={`border rounded-2xl p-5 flex flex-col gap-4 shadow-sm relative overflow-hidden transition-all hover:shadow-[0_4px_20px_rgba(212,175,55,0.03)] ${def.color}`}
                  id={`rank-panel-${rank}`}
                >
                  <div className="flex items-start justify-between border-b border-amber-500/5 pb-3">
                    <div>
                      <h4 className="font-serif text-xs font-black tracking-widest uppercase flex items-center gap-2">
                        <span className="text-sm font-bold">{def.icon}</span>
                        <span>{def.title}</span>
                      </h4>
                      <p className="text-[10px] text-gray-500 font-sans italic mt-0.5 leading-relaxed">
                        {def.desc}
                      </p>
                    </div>
                    <span className="font-mono text-[10px] font-bold bg-[#050507] border border-amber-500/10 text-amber-500/70 px-2 py-0.5 rounded-full">
                      {rankTasks.length}
                    </span>
                  </div>

                  <div className="flex-grow space-y-2.5">
                    {rankTasks.length === 0 ? (
                      <p className="text-[10.5px] font-sans italic text-gray-600 py-2">
                        No active tasks in this category.
                      </p>
                    ) : (
                      rankTasks.map((t) => (
                        <div
                          key={t.id}
                          className={`flex items-start gap-3 p-3 bg-black/40 border rounded-xl transition-all ${
                            t.completed 
                              ? 'border-green-500/10 opacity-50 bg-[#060a08]/10' 
                              : 'border-slate-800 hover:border-[#D4AF37]/25'
                          }`}
                          id={`task-item-${t.id}`}
                        >
                          {/* Complete Checkbox */}
                          <button
                            onClick={() => onToggleTask(t.id)}
                            className={`mt-0.5 shrink-0 w-5 h-5 rounded-full border flex items-center justify-center transition-all cursor-pointer ${
                              t.completed
                                ? 'bg-green-500/10 border-green-500 text-green-400'
                                : 'border-slate-800 hover:border-[#D4AF37]/40 text-transparent'
                            }`}
                            title={t.completed ? "Mark Incomplete" : "Mark Completed Task"}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5 stroke-[2.5]" />
                          </button>

                          {/* Content */}
                          <div className="flex-grow min-w-0">
                            <h5 className={`font-sans text-xs font-semibold leading-tight text-gray-200 ${
                              t.completed ? 'line-through text-gray-500' : ''
                            }`}>
                              {t.title}
                            </h5>
                            {t.description && (
                              <p className="text-[10px] text-gray-500 font-sans mt-1 line-clamp-2 leading-relaxed">
                                {t.description}
                              </p>
                            )}
                            
                            {/* Coach strategic wisdom insight */}
                            {t.insight && !t.completed && (
                              <div className="bg-[#15110a]/60 border border-[#D4AF37]/10 rounded-lg p-2.5 mt-2 space-y-1.5">
                                <p className="font-serif text-[10px] text-amber-500/80 italic leading-relaxed">
                                  "Mentor: {t.insight}"
                                </p>
                                {t.primaryGoal && (
                                  <div className="text-[8.5px] font-mono text-gray-500 uppercase tracking-widest pt-1 border-t border-[#D4AF37]/5">
                                    Target Goal: {t.primaryGoal}
                                  </div>
                                )}
                                {t.masteryInsight && (
                                  <div className="text-[9.5px] font-sans text-amber-200/90 bg-amber-500/[0.04] p-1.5 rounded border border-[#D4AF37]/10 mt-1 flex gap-1.5 items-start">
                                    <span className="text-[10px] shrink-0">✨</span>
                                    <span>{t.masteryInsight}</span>
                                  </div>
                                )}
                                {t.excellenceChallenge && (
                                  <div className="text-[9.5px] font-sans text-red-300/90 bg-red-950/[0.15] p-1.5 rounded border border-red-500/10 mt-1 flex gap-1.5 items-start">
                                    <span className="text-[10px] shrink-0">🔥</span>
                                    <span>{t.excellenceChallenge}</span>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>

                          {/* Actions */}
                          <div className="flex flex-col gap-2 items-center shrink-0">
                            {!t.completed && (
                              <button
                                onClick={() => onTriggerBlunder(t)}
                                className="text-red-500 hover:text-red-400 p-1.5 rounded transition-all cursor-pointer hover:bg-red-500/10 flex items-center gap-1 text-[8.5px] font-mono uppercase tracking-wider font-bold border border-red-500/20"
                                title="Mark as Neglected"
                              >
                                <Skull className="w-3 h-3 text-red-500" />
                                <span>Neglect</span>
                              </button>
                            )}
                            <button
                              onClick={() => onDeleteTask(t.id)}
                              className="text-gray-600 hover:text-red-400 p-1 rounded transition-all shrink-0 cursor-pointer"
                              title="Delete Task"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </motion.div>
  );
};
