import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar, 
  Clock, 
  AlertTriangle, 
  Check, 
  Hourglass, 
  CalendarRange, 
  Search, 
  SlidersHorizontal,
  ChevronRight,
  ShieldAlert,
  Bell,
  Trash2,
  CalendarDays,
  CheckCircle2
} from 'lucide-react';
import { useProductivityStore, StoreTask } from '../stores/useProductivityStore';

export interface RadarItem {
  task: StoreTask;
  daysRemaining: number;
  category: 'Urgent' | 'Upcoming' | 'Normal';
}

export const DeadlineRadar: React.FC = () => {
  const { tasks, updateTask, completeTask, deleteTask } = useProductivityStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'Urgent' | 'Upcoming' | 'Normal'>('All');
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [newDueDate, setNewDueDate] = useState('');
  const [showStatusToast, setShowStatusToast] = useState<string | null>(null);

  // Parse YYYY-MM-DD date safely in local time
  const parseLocalDate = (dateStr: string): Date => {
    const [year, month, day] = dateStr.split('-').map(Number);
    return new Date(year, month - 1, day);
  };

  // Calculate days remaining relative to today
  const getDaysRemaining = (dueDateStr: string): number => {
    if (!dueDateStr) return 0;
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const due = parseLocalDate(dueDateStr);
    due.setHours(0, 0, 0, 0);
    
    const diffTime = due.getTime() - today.getTime();
    return Math.round(diffTime / (1000 * 60 * 60 * 24));
  };

  // Fetch only active tasks with a due date
  const activeTasksWithDeadlines = tasks.filter(t => !t.completed && t.dueDate);

  // Group and categorize tasks
  const radarItems: RadarItem[] = activeTasksWithDeadlines.map(task => {
    const daysRemaining = getDaysRemaining(task.dueDate || '');
    let category: 'Urgent' | 'Upcoming' | 'Normal' = 'Normal';

    if (daysRemaining <= 2) {
      category = 'Urgent';
    } else if (daysRemaining <= 6) {
      category = 'Upcoming';
    }

    return {
      task,
      daysRemaining,
      category
    };
  });

  // Sort: Overdue & Urgent first, then sorted by daysRemaining ascending
  const sortedRadarItems = [...radarItems].sort((a, b) => a.daysRemaining - b.daysRemaining);

  // Filter items based on search and category tab
  const filteredRadarItems = sortedRadarItems.filter(item => {
    const matchesSearch = item.task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (item.task.description || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Category counts for quick status widgets
  const counts = {
    Urgent: radarItems.filter(i => i.category === 'Urgent').length,
    Upcoming: radarItems.filter(i => i.category === 'Upcoming').length,
    Normal: radarItems.filter(i => i.category === 'Normal').length,
    Overdue: radarItems.filter(i => i.daysRemaining < 0).length
  };

  const handleUpdateDueDate = (taskId: string) => {
    if (!newDueDate) return;
    updateTask(taskId, { dueDate: newDueDate });
    setEditingTaskId(null);
    setNewDueDate('');
    triggerToast("Task deadline updated successfully.");
  };

  const handleCompleteTask = (taskId: string, title: string) => {
    completeTask(taskId);
    triggerToast(`"${title}" marked completed! Elo Score rewarded.`);
  };

  const triggerToast = (msg: string) => {
    setShowStatusToast(msg);
    setTimeout(() => setShowStatusToast(null), 3000);
  };

  return (
    <div className="bg-[#12131a] border border-gray-800/80 rounded-2xl overflow-hidden shadow-2xl font-sans text-gray-200" id="deadline-radar-root">
      
      {/* HEADER WITH SWEEPING RADAR PULSE EFFECT */}
      <div className="p-6 border-b border-gray-800/60 bg-black/20 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 relative overflow-hidden">
        {/* Decorative radar background glow */}
        <div className="absolute right-0 top-0 w-44 h-44 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
        
        <div className="space-y-1 z-10">
          <div className="flex items-center gap-2">
            <div className="relative">
              <CalendarRange className="w-5 h-5 text-amber-400 shrink-0" />
              {counts.Urgent > 0 && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-rose-500 rounded-full animate-ping" />
              )}
            </div>
            <h3 className="font-serif text-base font-bold text-gray-100">Tactical Deadline Radar</h3>
          </div>
          <p className="text-xs text-gray-400 leading-relaxed">
            Monitor approaching target completions, isolate bottleneck dependencies, and adjust schedules to avoid operational penalties.
          </p>
        </div>

        {/* Overdue alert badge if any exists */}
        {counts.Overdue > 0 && (
          <div className="px-3 py-1.5 rounded-xl bg-rose-950/20 border border-rose-500/20 text-rose-300 text-[10px] font-mono font-bold flex items-center gap-1.5 shrink-0 z-10 animate-pulse" id="radar-overdue-alert-badge">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400 shrink-0" />
            <span>{counts.Overdue} OVERDUE BLOCKERS</span>
          </div>
        )}
      </div>

      {/* METRIC COUNTERS */}
      <div className="p-6 border-b border-gray-800/40 bg-black/10 grid grid-cols-2 md:grid-cols-4 gap-4" id="radar-metrics-grid">
        {[
          { label: 'Urgent (≤ 2 days)', count: counts.Urgent, color: 'text-rose-400 border-rose-500/10 bg-rose-500/5', type: 'Urgent' as const },
          { label: 'Upcoming (3-6 days)', count: counts.Upcoming, color: 'text-amber-400 border-amber-500/10 bg-amber-500/5', type: 'Upcoming' as const },
          { label: 'Normal (≥ 7 days)', count: counts.Normal, color: 'text-gray-400 border-gray-800 bg-black/20', type: 'Normal' as const },
          { label: 'Total Tracked', count: activeTasksWithDeadlines.length, color: 'text-blue-400 border-blue-500/10 bg-blue-500/5', type: 'All' as const }
        ].map((stat, idx) => (
          <button
            key={idx}
            onClick={() => setSelectedCategory(stat.type)}
            className={`p-4 rounded-xl border text-left cursor-pointer transition-all ${
              selectedCategory === stat.type 
                ? 'ring-2 ring-amber-500 border-transparent bg-amber-500/5 scale-[1.02]' 
                : 'hover:border-gray-700 hover:bg-black/30'
            } ${stat.color}`}
          >
            <span className="text-[10px] font-mono uppercase tracking-wider block font-bold text-gray-500">{stat.label}</span>
            <span className="text-2xl font-serif font-black block mt-1">{stat.count}</span>
          </button>
        ))}
      </div>

      {/* FILTER AND SEARCH CONTROLS */}
      <div className="p-6 border-b border-gray-800/40 flex flex-col md:flex-row gap-4 justify-between items-center bg-black/5">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-gray-500 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search deadlines..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-black/30 border border-gray-800 hover:border-gray-700 focus:border-amber-500/40 rounded-xl pl-9 pr-4 py-2 text-xs text-gray-200 outline-none transition-all"
            id="radar-search-input"
          />
        </div>

        <div className="flex gap-1.5 overflow-x-auto w-full md:w-auto" id="radar-tabs-row">
          {(['All', 'Urgent', 'Upcoming', 'Normal'] as const).map((tab) => {
            const isActive = selectedCategory === tab;
            return (
              <button
                key={tab}
                onClick={() => setSelectedCategory(tab)}
                className={`px-3 py-1.5 text-xs rounded-xl font-bold transition-all shrink-0 cursor-pointer border ${
                  isActive 
                    ? 'bg-amber-500 border-amber-500 text-black shadow-md' 
                    : 'bg-[#12131a] border-gray-800 text-gray-400 hover:text-gray-200 hover:border-gray-700'
                }`}
              >
                {tab}
              </button>
            );
          })}
        </div>
      </div>

      {/* STATUS TOAST */}
      <AnimatePresence>
        {showStatusToast && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mx-6 mt-6 p-3 bg-emerald-950/20 border border-emerald-500/20 text-emerald-300 text-xs rounded-xl flex items-center gap-2"
            id="radar-status-toast"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{showStatusToast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* DEADLINE LISTINGS */}
      <div className="p-6">
        {filteredRadarItems.length === 0 ? (
          <div className="py-14 text-center max-w-sm mx-auto space-y-4" id="radar-empty-state">
            <div className="p-4 bg-gray-900/40 border border-gray-800 text-gray-600 rounded-2xl inline-block">
              <CalendarDays className="w-8 h-8" />
            </div>
            <div className="space-y-1.5">
              <h4 className="font-serif text-sm font-bold text-gray-300">No Target Deadlines Match</h4>
              <p className="text-[11px] text-gray-500 leading-relaxed">
                {searchTerm || selectedCategory !== 'All' 
                  ? "Try altering your active filters or query parameters above." 
                  : "All current strategic tasks are clear of assigned deadlines. Establish a deadline from your primary board."}
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-3" id="radar-items-timeline">
            {filteredRadarItems.map(({ task, daysRemaining, category }) => {
              const isOverdue = daysRemaining < 0;
              const isEditing = editingTaskId === task.id;

              return (
                <div 
                  key={task.id}
                  className={`p-4 rounded-xl border transition-all duration-300 flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                    isOverdue 
                      ? 'bg-rose-950/5 border-rose-500/20' 
                      : category === 'Urgent' 
                      ? 'bg-amber-500/[0.02] border-amber-500/20' 
                      : 'bg-black/20 border-gray-850 hover:border-gray-800'
                  }`}
                  id={`radar-row-${task.id}`}
                >
                  
                  {/* Task details segment */}
                  <div className="flex gap-3.5 items-start flex-grow min-w-0">
                    
                    {/* Status Dot / Priority Badge */}
                    <div className="shrink-0 pt-0.5">
                      {isOverdue ? (
                        <div className="w-2.5 h-2.5 bg-rose-500 rounded-full animate-ping" title="Overdue blocker" />
                      ) : category === 'Urgent' ? (
                        <div className="w-2.5 h-2.5 bg-amber-500 rounded-full animate-pulse" title="Urgent deadline" />
                      ) : (
                        <div className="w-2.5 h-2.5 bg-gray-600 rounded-full" />
                      )}
                    </div>

                    <div className="space-y-1 flex-grow min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`px-2 py-0.5 rounded-md text-[9px] font-mono font-bold uppercase tracking-wider ${
                          task.priority === 'KING' 
                            ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' 
                            : task.priority === 'QUEEN' 
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' 
                            : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                        }`}>
                          {task.priority === 'KING' ? 'Critical' : task.priority === 'QUEEN' ? 'Strategic' : 'Operational'}
                        </span>
                        
                        <span className="text-[10px] font-mono text-gray-500">
                          Due: {task.dueDate}
                        </span>
                      </div>

                      <h4 className="text-xs font-bold text-gray-100 leading-normal truncate">
                        {task.title}
                      </h4>
                      {task.description && (
                        <p className="text-[11px] text-gray-400 leading-relaxed truncate max-w-xl">
                          {task.description}
                        </p>
                      )}
                    </div>

                  </div>

                  {/* Deadline clock counter & adjustments */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between md:justify-end gap-4 shrink-0 border-t border-gray-900/30 md:border-0 pt-3 md:pt-0">
                    
                    {/* Days Remaining Label */}
                    <div className="text-left sm:text-right">
                      {isOverdue ? (
                        <div className="flex items-center gap-1.5 text-rose-400 font-mono text-xs font-bold">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>Overdue by {Math.abs(daysRemaining)} days</span>
                        </div>
                      ) : daysRemaining === 0 ? (
                        <div className="flex items-center gap-1.5 text-amber-400 font-mono text-xs font-bold">
                          <Clock className="w-3.5 h-3.5" />
                          <span>Due Today</span>
                        </div>
                      ) : daysRemaining === 1 ? (
                        <div className="flex items-center gap-1.5 text-amber-400 font-mono text-xs font-bold">
                          <Clock className="w-3.5 h-3.5" />
                          <span>Tomorrow (1 day)</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 text-gray-400 font-mono text-xs font-medium">
                          <Hourglass className="w-3.5 h-3.5 text-gray-500" />
                          <span>{daysRemaining} days remaining</span>
                        </div>
                      )}
                    </div>

                    {/* Due Date Inline Editor or Actions */}
                    {isEditing ? (
                      <div className="flex items-center gap-2">
                        <input
                          type="date"
                          value={newDueDate}
                          onChange={(e) => setNewDueDate(e.target.value)}
                          className="bg-black/60 border border-gray-800 hover:border-gray-700 text-xs text-gray-200 px-2 py-1 rounded-lg outline-none focus:border-amber-500/40 font-mono"
                        />
                        <button
                          onClick={() => handleUpdateDueDate(task.id)}
                          className="p-1.5 rounded-lg bg-emerald-500 text-black hover:bg-emerald-400 transition-all cursor-pointer"
                          title="Save date"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setEditingTaskId(null)}
                          className="p-1.5 rounded-lg border border-gray-800 text-gray-400 hover:text-gray-200 text-xs font-bold hover:bg-black/20"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        {/* Adjust date trigger */}
                        <button
                          onClick={() => {
                            setEditingTaskId(task.id);
                            setNewDueDate(task.dueDate || '');
                          }}
                          className="px-2.5 py-1.5 text-[10px] font-mono uppercase tracking-wider font-bold rounded-lg border border-gray-800 bg-black/20 hover:border-gray-700 hover:text-gray-200 text-gray-400 transition-all cursor-pointer"
                          id={`radar-edit-btn-${task.id}`}
                        >
                          Shift Date
                        </button>

                        {/* Complete task button */}
                        <button
                          onClick={() => handleCompleteTask(task.id, task.title)}
                          className="p-1.5 rounded-lg bg-amber-500 hover:bg-amber-450 text-black transition-all cursor-pointer flex items-center justify-center"
                          id={`radar-complete-btn-${task.id}`}
                          title="Complete Task"
                        >
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </button>
                      </div>
                    )}

                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
};
