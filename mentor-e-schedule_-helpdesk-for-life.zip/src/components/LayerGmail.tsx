import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mail, RefreshCw, AlertCircle, Check, Plus, Send, 
  Sparkles, ShieldCheck, LogOut, ArrowRight, CheckCircle2,
  Lock, ExternalLink, Calendar, ChevronRight, Inbox, HelpCircle
} from 'lucide-react';
import { useProductivityStore } from '../stores/useProductivityStore';
import { 
  connectGmail, 
  isGmailConnected, 
  disconnectGmail, 
  fetchLatestEmails, 
  analyzeEmailWithMentor, 
  sendGmailReply,
  GmailEmail,
  EmailAnalysis
} from '../services/gmailService';

export const LayerGmail: React.FC = () => {
  const { addTask, currentUser } = useProductivityStore();
  const [isConnected, setIsConnected] = useState<boolean>(isGmailConnected());
  const [emails, setEmails] = useState<GmailEmail[]>([]);
  const [selectedEmail, setSelectedEmail] = useState<GmailEmail | null>(null);
  const [loadingEmails, setLoadingEmails] = useState<boolean>(false);
  const [analyzingEmail, setAnalyzingEmail] = useState<boolean>(false);
  const [analysis, setAnalysis] = useState<EmailAnalysis | null>(null);
  const [draftReply, setDraftReply] = useState<string>('');
  const [isSendingReply, setIsSendingReply] = useState<boolean>(false);
  const [replyStatus, setReplyStatus] = useState<{ success?: boolean; error?: string } | null>(null);
  
  // Tasks added from current analysis to prevent duplicate clicks
  const [addedTasks, setAddedTasks] = useState<Record<string, boolean>>({});

  // Safety Confirmation Modal Gate
  const [showConfirmGate, setShowConfirmGate] = useState<boolean>(false);

  // General error handling state
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Sync emails when connection is established or active
  useEffect(() => {
    if (isConnected) {
      loadLatestEmails();
    }
  }, [isConnected]);

  const handleConnect = async () => {
    try {
      setErrorMsg(null);
      await connectGmail();
      setIsConnected(true);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to authenticate Gmail via OAuth pop-up.');
    }
  };

  const handleDisconnect = () => {
    disconnectGmail();
    setIsConnected(false);
    setEmails([]);
    setSelectedEmail(null);
    setAnalysis(null);
    setDraftReply('');
    setReplyStatus(null);
  };

  const loadLatestEmails = async () => {
    setLoadingEmails(true);
    setErrorMsg(null);
    try {
      const fetched = await fetchLatestEmails(10);
      setEmails(fetched);
      if (fetched.length > 0 && !selectedEmail) {
        // Automatically select the first email
        handleSelectEmail(fetched[0]);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Error occurred while loading emails from Gmail API.');
      if (err.message?.includes('unauthorized') || err.message?.includes('auth')) {
        setIsConnected(false);
      }
    } finally {
      setLoadingEmails(false);
    }
  };

  const handleSelectEmail = async (email: GmailEmail) => {
    setSelectedEmail(email);
    setAnalysis(null);
    setDraftReply('');
    setReplyStatus(null);
    setAddedTasks({});
    setAnalyzingEmail(true);

    try {
      const result = await analyzeEmailWithMentor(email, currentUser?.email || '');
      setAnalysis(result);
      setDraftReply(result.proposedReply);
    } catch (err: any) {
      console.error('Mentor Email Analysis Failed:', err);
    } finally {
      setAnalyzingEmail(false);
    }
  };

  const handleIngestTask = (actionText: string, priority: 'KING' | 'QUEEN' | 'ROOK' | 'PAWN', index: number) => {
    addTask({
      title: actionText,
      description: `Ingested from email regarding: "${selectedEmail?.subject || 'Inbox Communication'}". From: ${selectedEmail?.from}.`,
      priority: priority,
      dueDate: new Date().toISOString().split('T')[0], // Defaults to today
    });
    setAddedTasks(prev => ({ ...prev, [index]: true }));
  };

  const initiateSendReply = () => {
    if (!draftReply.trim()) return;
    setShowConfirmGate(true);
  };

  const executeSendReply = async () => {
    if (!selectedEmail) return;
    setIsSendingReply(true);
    setReplyStatus(null);
    setShowConfirmGate(false);

    try {
      // Extract original email sender's email address
      const senderMatch = selectedEmail.from.match(/<([^>]+)>/);
      const recipient = senderMatch ? senderMatch[1] : selectedEmail.from;

      await sendGmailReply(
        recipient,
        selectedEmail.subject,
        draftReply,
        selectedEmail.threadId,
        selectedEmail.id
      );

      setReplyStatus({ success: true });
    } catch (err: any) {
      setReplyStatus({ error: err.message || 'Transmission failed.' });
    } finally {
      setIsSendingReply(false);
    }
  };

  const getPriorityColor = (category: string) => {
    switch (category?.toUpperCase()) {
      case 'KING':
        return {
          bg: 'bg-red-500/10 border-red-500/30 text-red-400',
          badge: 'bg-red-500/20 text-red-300 border-red-500/40',
          label: 'King (Critical Action)'
        };
      case 'QUEEN':
        return {
          bg: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
          badge: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
          label: 'Queen (High Impact)'
        };
      case 'ROOK':
        return {
          bg: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400',
          badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
          label: 'Rook (Operational Plan)'
        };
      default:
        return {
          bg: 'bg-gray-500/10 border-gray-800 text-gray-400',
          badge: 'bg-gray-800 text-gray-300 border-gray-700',
          label: 'Pawn (Maintenance/Ref)'
        };
    }
  };

  // Connection Gate screen (Not Connected state)
  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[500px] p-6 text-center max-w-2xl mx-auto">
        <div className="p-4 bg-[#D4AF37]/10 rounded-full border border-[#D4AF37]/30 mb-6 relative">
          <Mail className="w-12 h-12 text-[#D4AF37]" />
          <div className="absolute -bottom-1 -right-1 p-1 bg-[#12131a] rounded-full border border-gray-800">
            <Lock className="w-4 h-4 text-emerald-400" />
          </div>
        </div>
        
        <h2 className="text-xl font-sans font-bold text-gray-200 uppercase tracking-widest mb-3">
          Strategic Email Ingestion Engine
        </h2>
        
        <p className="text-xs text-gray-400 leading-relaxed mb-6">
          Synchronize your incoming Gmail communications with the Grandmaster Strategic Workspace. 
          Empower the AI Performance Coach to instantly categorize messages, assess strategic risks, 
          extract actionable operational goals, and draft high-impact replies.
        </p>

        {errorMsg && (
          <div className="w-full mb-6 p-3 rounded-lg bg-red-500/10 border border-red-500/30 flex items-start gap-3 text-left">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <p className="text-[11px] text-red-300 leading-tight font-mono">{errorMsg}</p>
          </div>
        )}

        <button
          onClick={handleConnect}
          className="flex items-center gap-2 px-6 py-3 bg-[#D4AF37]/15 border border-[#D4AF37]/40 hover:bg-[#D4AF37]/25 text-[#D4AF37] font-sans font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md cursor-pointer"
        >
          <Sparkles className="w-4 h-4" />
          Authorize Gmail Connection
        </button>

        <div className="mt-8 flex items-center gap-2 text-[10px] text-gray-500 bg-[#12131a]/60 px-4 py-2 rounded-lg border border-gray-800/80">
          <ShieldCheck className="w-4 h-4 text-emerald-500" />
          <span>Compliance Confirmed: OAuth authorization cached strictly in-memory. No emails are persisted externally.</span>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 h-[calc(100vh-140px)] min-h-[550px]">
      
      {/* 1. Inbox Column (Col Span 4) */}
      <div className="lg:col-span-4 bg-[#12131a]/40 border border-gray-800/80 rounded-2xl flex flex-col overflow-hidden">
        <div className="p-4 border-b border-gray-800/60 flex items-center justify-between bg-[#12131a]/80">
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-[#D4AF37]" />
            <h3 className="text-xs font-sans font-extrabold uppercase tracking-widest text-gray-300">Ingress Logs</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={loadLatestEmails}
              disabled={loadingEmails}
              className="p-1.5 rounded-lg border border-gray-800 hover:border-gray-700 bg-white/[0.02] text-gray-400 hover:text-gray-200 disabled:opacity-50 transition-all cursor-pointer"
              title="Refresh Ingress"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingEmails ? 'animate-spin text-[#D4AF37]' : ''}`} />
            </button>
            <button
              onClick={handleDisconnect}
              className="p-1.5 rounded-lg border border-gray-800 hover:border-red-900/30 bg-white/[0.02] text-gray-500 hover:text-red-400 transition-all cursor-pointer"
              title="Disconnect Stream"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Ingress list */}
        <div className="flex-1 overflow-y-auto divide-y divide-gray-900">
          {loadingEmails && emails.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full p-6 text-center">
              <RefreshCw className="w-6 h-6 text-[#D4AF37] animate-spin mb-3" />
              <p className="text-[11px] text-gray-500 font-mono">SYNCHRONIZING SECURE INGRESS STREAM...</p>
            </div>
          ) : emails.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full p-6 text-center">
              <Inbox className="w-8 h-8 text-gray-700 mb-2" />
              <p className="text-xs text-gray-400">No recent communications detected.</p>
              <button
                onClick={loadLatestEmails}
                className="mt-3 text-[10px] text-[#D4AF37] underline hover:text-[#e6c453] uppercase font-bold tracking-wider"
              >
                Scan Inbox
              </button>
            </div>
          ) : (
            emails.map((email) => {
              const isSelected = selectedEmail?.id === email.id;
              return (
                <button
                  key={email.id}
                  onClick={() => handleSelectEmail(email)}
                  className={`w-full text-left p-4 transition-all flex flex-col gap-1 cursor-pointer ${
                    isSelected 
                      ? 'bg-[#D4AF37]/5 border-l-2 border-l-[#D4AF37]' 
                      : 'hover:bg-white/[0.01] border-l-2 border-l-transparent'
                  }`}
                >
                  <div className="flex justify-between items-center gap-2">
                    <span className="text-[11px] font-sans font-extrabold text-gray-300 truncate max-w-[70%]">
                      {email.from.split('<')[0].trim() || email.from}
                    </span>
                    <span className="text-[9px] font-mono text-gray-500">
                      {email.date ? new Date(email.date).toLocaleDateString([], { month: 'short', day: 'numeric' }) : ''}
                    </span>
                  </div>
                  <span className="text-xs font-sans font-bold text-gray-100 truncate">
                    {email.subject}
                  </span>
                  <p className="text-[10px] text-gray-500 line-clamp-2 leading-relaxed">
                    {email.snippet}
                  </p>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* 2. Detailed View Columns (Col Span 8) */}
      <div className="lg:col-span-8 flex flex-col gap-4 overflow-hidden h-full">
        <AnimatePresence mode="wait">
          {!selectedEmail ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex-1 bg-[#12131a]/20 border border-gray-800/60 rounded-2xl flex flex-col items-center justify-center text-center p-6"
            >
              <Mail className="w-10 h-10 text-gray-700 mb-3" />
              <p className="text-xs text-gray-400">Select an email communication to initiate strategic analysis.</p>
            </motion.div>
          ) : (
            <motion.div
              key={selectedEmail.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
              className="flex-1 flex flex-col md:grid md:grid-cols-12 gap-4 h-full overflow-hidden"
            >
              {/* 2A. Original Mail Viewer (Span 5) */}
              <div className="md:col-span-5 bg-[#12131a]/40 border border-gray-800/80 rounded-2xl flex flex-col overflow-hidden h-full">
                <div className="p-4 border-b border-gray-800/60 bg-[#12131a]/80">
                  <span className="text-[9px] font-mono text-gray-500 block uppercase tracking-wider mb-1">Incoming Communication</span>
                  <h3 className="text-xs font-sans font-bold text-gray-100 leading-snug break-words">
                    {selectedEmail.subject}
                  </h3>
                  <div className="mt-2 flex flex-col gap-0.5 text-[10px] text-gray-400">
                    <span className="truncate"><strong className="text-gray-500 font-mono">FROM:</strong> {selectedEmail.from}</span>
                    <span><strong className="text-gray-500 font-mono">DATE:</strong> {selectedEmail.date}</span>
                  </div>
                </div>

                {/* Body Content */}
                <div className="flex-1 p-4 overflow-y-auto font-sans text-xs text-gray-300 leading-relaxed space-y-4 whitespace-pre-wrap select-text selection:bg-[#D4AF37]/25 selection:text-white">
                  {selectedEmail.body}
                </div>
              </div>

              {/* 2B. AI Strategic Analyst Panel (Span 7) */}
              <div className="md:col-span-7 flex flex-col gap-4 overflow-y-auto h-full pr-1">
                
                {/* Loader state */}
                {analyzingEmail && (
                  <div className="flex-1 min-h-[300px] bg-[#12131a]/50 border border-gray-800/80 rounded-2xl flex flex-col items-center justify-center p-6 text-center">
                    <Sparkles className="w-8 h-8 text-[#D4AF37] animate-pulse mb-3" />
                    <p className="text-xs text-gray-300 font-sans font-extrabold uppercase tracking-widest mb-1">Calculating Strategic Position</p>
                    <p className="text-[10px] font-mono text-[#D4AF37]">ENGAGING MENTOR INTELLIGENCE PIPELINE...</p>
                  </div>
                )}

                {/* Analysis Result */}
                {!analyzingEmail && analysis && (
                  <>
                    {/* Priority & Rationale Card */}
                    <div className={`p-4 rounded-2xl border ${getPriorityColor(analysis.category).bg} flex flex-col gap-2`}>
                      <div className="flex justify-between items-center">
                        <span className="text-[9px] font-mono uppercase tracking-widest text-gray-400">Strategic Classification</span>
                        <span className={`px-2 py-0.5 rounded border text-[9px] font-sans font-bold uppercase tracking-wider ${getPriorityColor(analysis.category).badge}`}>
                          {getPriorityColor(analysis.category).label}
                        </span>
                      </div>
                      <p className="text-xs text-gray-100 font-sans font-bold leading-snug mt-1">
                        "{analysis.summary}"
                      </p>
                      <p className="text-[10px] text-gray-400 leading-relaxed italic border-t border-gray-800/40 pt-2 mt-1">
                        <strong className="text-gray-300 not-italic font-mono uppercase text-[9px] mr-1">RATIONALE:</strong>
                        {analysis.rationale}
                      </p>
                    </div>

                    {/* Action Points Ingestion Card */}
                    <div className="bg-[#12131a]/60 border border-gray-800/80 rounded-2xl p-4 flex flex-col gap-3">
                      <div className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <h4 className="text-[10px] font-sans font-extrabold uppercase tracking-widest text-gray-300">Action Ingress</h4>
                      </div>
                      
                      <div className="flex flex-col gap-2">
                        {analysis.actionPoints.map((action, index) => {
                          const ingested = addedTasks[index];
                          return (
                            <div 
                              key={index} 
                              className="p-3 bg-[#0d0e12] border border-gray-800/80 rounded-xl flex items-center justify-between gap-3 group hover:border-gray-700 transition-all"
                            >
                              <div className="flex flex-col gap-0.5">
                                <span className="text-[9px] font-mono text-[#D4AF37] uppercase">Tactical Move #{index + 1}</span>
                                <p className="text-xs text-gray-200 font-sans font-semibold leading-relaxed">
                                  {action}
                                </p>
                              </div>
                              <button
                                onClick={() => handleIngestTask(action, analysis.category.toUpperCase() as any, index)}
                                disabled={ingested}
                                className={`px-2.5 py-1.5 rounded-lg text-[9px] font-sans font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1 shrink-0 ${
                                  ingested
                                    ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400'
                                    : 'bg-[#D4AF37]/10 hover:bg-[#D4AF37]/20 border border-[#D4AF37]/30 text-[#D4AF37]'
                                }`}
                              >
                                {ingested ? (
                                  <>
                                    <Check className="w-3 h-3" />
                                    Ingested
                                  </>
                                ) : (
                                  <>
                                    <Plus className="w-3 h-3" />
                                    Add Task
                                  </>
                                )}
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* AI Assisted Reply Area */}
                    <div className="bg-[#12131a]/60 border border-gray-800/80 rounded-2xl p-4 flex flex-col gap-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                          <h4 className="text-[10px] font-sans font-extrabold uppercase tracking-widest text-gray-300">Tactical Draft Reply</h4>
                        </div>
                        <span className="text-[9px] font-mono text-gray-500">Editable Response Template</span>
                      </div>

                      <textarea
                        value={draftReply}
                        onChange={(e) => setDraftReply(e.target.value)}
                        className="w-full h-40 p-3 bg-[#0d0e12] border border-gray-800 focus:border-[#D4AF37]/50 rounded-xl text-xs text-gray-300 font-sans leading-relaxed focus:outline-none resize-none"
                        placeholder="Draft reply content..."
                      />

                      {replyStatus?.success && (
                        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-[11px] text-emerald-400 flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 shrink-0" />
                          <span>Transmission Success: Email reply has been delivered to sender.</span>
                        </div>
                      )}

                      {replyStatus?.error && (
                        <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-[11px] text-red-300 flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 shrink-0" />
                          <span>Transmission Aborted: {replyStatus.error}</span>
                        </div>
                      )}

                      <button
                        onClick={initiateSendReply}
                        disabled={isSendingReply || !draftReply.trim()}
                        className="w-full py-2.5 bg-[#D4AF37]/15 hover:bg-[#D4AF37]/25 border border-[#D4AF37]/40 hover:border-[#D4AF37]/60 text-[#D4AF37] font-sans font-bold text-xs uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2 disabled:opacity-40 cursor-pointer"
                      >
                        {isSendingReply ? 'Transmitting Reply...' : 'Transmit Reply to Sender'}
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Safety Gate Confirmation Modal (Workspace Integration Skill Mandated Confirmation) */}
      <AnimatePresence>
        {showConfirmGate && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0f1015] border border-gray-800 max-w-md w-full rounded-2xl overflow-hidden shadow-2xl"
            >
              <div className="p-5 border-b border-gray-900 bg-[#12131a] flex items-center gap-2.5">
                <div className="p-1.5 bg-amber-500/10 border border-amber-500/30 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-amber-500" />
                </div>
                <div>
                  <h4 className="text-xs font-sans font-extrabold uppercase tracking-widest text-gray-200">Verify Transmission</h4>
                  <p className="text-[10px] text-gray-500">Workspace Execution Security Check</p>
                </div>
              </div>

              <div className="p-5 text-xs text-gray-300 leading-relaxed space-y-3">
                <p>
                  You are preparing to send a live email reply on behalf of your Google Workspace account.
                </p>
                <div className="p-3 bg-white/[0.02] border border-gray-800 rounded-lg text-[11px] space-y-1">
                  <div><strong className="text-gray-500 font-mono text-[9px] uppercase">Recipient:</strong> <span className="text-gray-300 font-sans font-bold">{selectedEmail?.from}</span></div>
                  <div className="truncate"><strong className="text-gray-500 font-mono text-[9px] uppercase">Subject:</strong> <span className="text-gray-300 font-sans font-semibold">{selectedEmail?.subject}</span></div>
                </div>
                <p className="text-[10px] text-amber-400 font-medium">
                  This operation is destructive and cannot be undone once transmitted to the SMTP server.
                </p>
              </div>

              <div className="p-4 bg-gray-950 border-t border-gray-900 flex justify-end gap-2">
                <button
                  onClick={() => setShowConfirmGate(false)}
                  className="px-4 py-2 text-xs font-sans font-bold uppercase tracking-wider text-gray-400 hover:text-gray-200 hover:bg-white/[0.02] border border-transparent hover:border-gray-800 rounded-lg transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={executeSendReply}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 border border-emerald-500 hover:border-emerald-400 text-white font-sans font-bold text-xs uppercase tracking-wider rounded-lg transition-all shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  Confirm & Transmit
                  <Send className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
