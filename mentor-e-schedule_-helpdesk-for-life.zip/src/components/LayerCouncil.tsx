import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Swords, AlertCircle, RefreshCw, Send, Compass, MessageSquare, Award, Flame } from 'lucide-react';
import { Task, ChessRank } from '../types';

const coachPortrait = "https://placehold.co/150x150/111/D4AF37?text=COACH";

// Helper to parse streamed discuss responses
function parseDiscussStreamedResponse(text: string) {
  const keys = [
    'SUGGESTED_RANK:',
    'SUGGESTED_INSIGHT:',
    'SUGGESTED_CATEGORY_EXPLANATION:',
    'SUGGESTED_MASTERY_INSIGHT:',
    'SUGGESTED_EXCELLENCE_CHALLENGE:'
  ];

  let minIdx = -1;
  for (const key of keys) {
    const idx = text.indexOf(key);
    if (idx !== -1) {
      if (minIdx === -1 || idx < minIdx) {
        minIdx = idx;
      }
    }
  }

  const cleanText = minIdx !== -1 ? text.substring(0, minIdx).trim() : text.trim();

  // Helper to extract a key's value cleanly
  const extractValue = (key: string) => {
    const idx = text.indexOf(key);
    if (idx === -1) return '';
    const content = text.substring(idx + key.length);
    let nextIdx = -1;
    for (const otherKey of keys) {
      if (otherKey === key) continue;
      const oIdx = content.indexOf(otherKey);
      if (oIdx !== -1) {
        if (nextIdx === -1 || oIdx < nextIdx) {
          nextIdx = oIdx;
        }
      }
    }
    const rawVal = nextIdx !== -1 ? content.substring(0, nextIdx) : content;
    return rawVal.trim().replace(/^["']|["']$/g, '');
  };

  const suggestedRank = extractValue('SUGGESTED_RANK:');
  const suggestedInsight = extractValue('SUGGESTED_INSIGHT:');
  const suggestedCategoryExplanation = extractValue('SUGGESTED_CATEGORY_EXPLANATION:');
  const suggestedMasteryInsight = extractValue('SUGGESTED_MASTERY_INSIGHT:');
  const suggestedExcellenceChallenge = extractValue('SUGGESTED_EXCELLENCE_CHALLENGE:');

  return {
    cleanText,
    suggestedRank: (suggestedRank as ChessRank) || undefined,
    suggestedInsight,
    suggestedCategoryExplanation,
    suggestedMasteryInsight,
    suggestedExcellenceChallenge
  };
}

interface LayerCouncilProps {
  task: Task | null;
  onApprove: (
    id: string,
    rank: ChessRank,
    customInsight?: string,
    customCategoryExplanation?: string,
    customMasteryInsight?: string,
    customExcellenceChallenge?: string
  ) => void;
  onReject: (id: string) => void;
  isAnalyzing: boolean;
}

export const LayerCouncil: React.FC<LayerCouncilProps> = ({ task, onApprove, onReject, isAnalyzing }) => {
  // Local state for rank override/choice
  const [selectedRank, setSelectedRank] = useState<ChessRank>('King');
  const [messages, setMessages] = useState<{ sender: 'user' | 'chanakya'; text: string }[]>([]);
  const [inputText, setInputText] = useState('');
  const [isDiscussing, setIsDiscussing] = useState(false);
  const [currentInsight, setCurrentInsight] = useState('');
  const [currentCategoryExplanation, setCurrentCategoryExplanation] = useState('');
  const [currentMasteryInsight, setCurrentMasteryInsight] = useState('');
  const [currentExcellenceChallenge, setCurrentExcellenceChallenge] = useState('');
  
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (task) {
      const initialRank = task.proposedRank || task.rank || 'King';
      setSelectedRank(initialRank);
      
      const initialInsight = task.insight || 'This move has been analyzed for impact. Let us execute deliberately to protect your key objectives.';
      setCurrentInsight(initialInsight);
      
      const initialExplanation = task.categoryExplanation || 'Priority Alignment Analysis';
      setCurrentCategoryExplanation(initialExplanation);

      const initialMastery = task.masteryInsight || '';
      setCurrentMasteryInsight(initialMastery);

      const initialChallenge = task.excellenceChallenge || '';
      setCurrentExcellenceChallenge(initialChallenge);

      const initialMsgs: { sender: 'user' | 'chanakya'; text: string }[] = [
        { 
          sender: 'chanakya', 
          text: initialInsight
        }
      ];

      if (task.followUpQuestion) {
        initialMsgs.push({
          sender: 'chanakya',
          text: task.followUpQuestion
        });
      }

      setMessages(initialMsgs);
    }
  }, [task]);

  // Autoscroll the chat pane
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isDiscussing]);

  if (!task) {
    return (
      <div className="text-center py-12 text-gray-500 font-serif italic">
        No move selected for Strategic Review.
      </div>
    );
  }

  const rankDefinitions = {
    'King': {
      title: 'CRITICAL PRIORITY',
      desc: 'High-urgency, critical tasks to resolve immediately. Core business-defining actions.',
      badgeColor: 'bg-rose-500/10 border-rose-500/40 text-rose-400',
    },
    'Queen': {
      title: 'HIGH PRIORITY',
      desc: 'Strategic, high-impact tasks. Important milestones to schedule for peak focus.',
      badgeColor: 'bg-amber-500/10 border-amber-500/40 text-amber-400',
    },
    'Rook': {
      title: 'MEDIUM PRIORITY',
      desc: 'Routine operations, communication, and essential maintenance. Best batched together.',
      badgeColor: 'bg-blue-500/10 border-blue-500/40 text-blue-400',
    },
    'Pawn': {
      title: 'LOW PRIORITY',
      desc: 'Personal well-being, skills development, and background tasks. Essential for long-term health.',
      badgeColor: 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400',
    },
  };
  
  const getSuggestedPrompts = (rank: ChessRank) => {
    switch(rank) {
      case 'King':
        return [
          "Why is this critical?",
          "How can I block distractions?",
          "Suggest a focus plan."
        ];
      case 'Queen':
        return [
          "What is the high impact?",
          "Suggest target milestones.",
          "How should I sequence this?"
        ];
      case 'Rook':
        return [
          "How can I batch this?",
          "What processes can I automate?",
          "Can we delegate this?"
        ];
      case 'Pawn':
        return [
          "Why is this vital for balance?",
          "How does this prevent burnout?",
          "Suggest a simple routine."
        ];
      default:
        return [
          "What is the priority?",
          "Suggest next steps."
        ];
    }
  };

  const handleSuggestiveClick = async (promptText: string) => {
    if (isDiscussing || !task) return;

    const updatedMessages = [...messages, { sender: 'user' as const, text: promptText }];
    setMessages(updatedMessages);
    setIsDiscussing(true);

    // Add mentor message placeholder
    const placeholderMessage = { sender: 'chanakya' as const, text: 'Analyzing task context and formulating strategic feedback...' };
    setMessages(prev => [...prev, placeholderMessage]);

    try {
      const response = await fetch('/api/coach/discuss-stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title: task.title,
          description: task.description,
          currentRank: selectedRank,
          userMessage: promptText,
          history: updatedMessages.slice(0, -1),
          primaryGoal: task.primaryGoal
        })
      });

      if (!response.ok) {
        throw new Error('Discussion transmission failed');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder("utf-8");
      let fullText = '';

      if (reader) {
        let isDone = false;
        while (!isDone) {
          const { done, value } = await reader.read();
          if (done) {
            isDone = true;
            break;
          }
          const chunkStr = decoder.decode(value, { stream: true });
          const lines = chunkStr.split('\n');
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const data = JSON.parse(line.substring(6));
                if (data.chunk) {
                  fullText += data.chunk;
                  
                  // Clean text on the fly to avoid flashing tags to the user
                  const cleaned = fullText
                    .replace(/SUGGESTED_RANK:[\s\S]*/, '')
                    .replace(/SUGGESTED_INSIGHT:[\s\S]*/, '')
                    .replace(/SUGGESTED_CATEGORY_EXPLANATION:[\s\S]*/, '')
                    .replace(/SUGGESTED_MASTERY_INSIGHT:[\s\S]*/, '')
                    .replace(/SUGGESTED_EXCELLENCE_CHALLENGE:[\s\S]*/, '')
                    .trim();

                  setMessages((prev) => {
                    const next = [...prev];
                    if (next.length > 0) {
                      next[next.length - 1] = { sender: 'chanakya', text: cleaned || 'Formulating feedback...' };
                    }
                    return next;
                  });
                }
                if (data.done) {
                  isDone = true;
                }
              } catch (e) {
                // partial/malformed chunk, ignore and continue
              }
            }
          }
        }

        // Final parsing of the complete text
        const parsed = parseDiscussStreamedResponse(fullText);
        setMessages((prev) => {
          const next = [...prev];
          if (next.length > 0) {
            next[next.length - 1] = { sender: 'chanakya', text: parsed.cleanText || 'Feedback complete.' };
          }
          return next;
        });

        if (parsed.suggestedRank) {
          setSelectedRank(parsed.suggestedRank);
        }
        if (parsed.suggestedInsight) {
          setCurrentInsight(parsed.suggestedInsight);
        }
        if (parsed.suggestedCategoryExplanation) {
          setCurrentCategoryExplanation(parsed.suggestedCategoryExplanation);
        }
        if (parsed.suggestedMasteryInsight) {
          setCurrentMasteryInsight(parsed.suggestedMasteryInsight);
        }
        if (parsed.suggestedExcellenceChallenge) {
          setCurrentExcellenceChallenge(parsed.suggestedExcellenceChallenge);
        }
      }
    } catch (err) {
      console.warn('API error during discussion fallback:', err);
      setMessages(prev => {
        const next = [...prev];
        if (next.length > 0) {
          next[next.length - 1] = { 
            sender: 'chanakya', 
            text: 'I understand your perspective. Let us align our path to maximize your strategic focus and productivity.' 
          };
        }
        return next;
      });
    } finally {
      setIsDiscussing(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isDiscussing || !task) return;

    const userMsg = inputText.trim();
    setInputText('');

    // Append user's counterargument
    const updatedMessages = [...messages, { sender: 'user' as const, text: userMsg }];
    setMessages(updatedMessages);
    setIsDiscussing(true);

    // Add mentor message placeholder
    const placeholderMessage = { sender: 'chanakya' as const, text: 'Analyzing counterargument and formulating perspective...' };
    setMessages(prev => [...prev, placeholderMessage]);

    try {
      const response = await fetch('/api/coach/discuss-stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title: task.title,
          description: task.description,
          currentRank: selectedRank,
          userMessage: userMsg,
          history: updatedMessages.slice(0, -1),
          primaryGoal: task.primaryGoal
        })
      });

      if (!response.ok) {
        throw new Error('Discussion transmission failed');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder("utf-8");
      let fullText = '';

      if (reader) {
        let isDone = false;
        while (!isDone) {
          const { done, value } = await reader.read();
          if (done) {
            isDone = true;
            break;
          }
          const chunkStr = decoder.decode(value, { stream: true });
          const lines = chunkStr.split('\n');
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const data = JSON.parse(line.substring(6));
                if (data.chunk) {
                  fullText += data.chunk;
                  
                  // Clean text on the fly to avoid flashing tags to the user
                  const cleaned = fullText
                    .replace(/SUGGESTED_RANK:[\s\S]*/, '')
                    .replace(/SUGGESTED_INSIGHT:[\s\S]*/, '')
                    .replace(/SUGGESTED_CATEGORY_EXPLANATION:[\s\S]*/, '')
                    .replace(/SUGGESTED_MASTERY_INSIGHT:[\s\S]*/, '')
                    .replace(/SUGGESTED_EXCELLENCE_CHALLENGE:[\s\S]*/, '')
                    .trim();

                  setMessages((prev) => {
                    const next = [...prev];
                    if (next.length > 0) {
                      next[next.length - 1] = { sender: 'chanakya', text: cleaned || 'Formulating response...' };
                    }
                    return next;
                  });
                }
                if (data.done) {
                  isDone = true;
                }
              } catch (e) {
                // partial/malformed chunk, ignore and continue
              }
            }
          }
        }

        // Final parsing of the complete text
        const parsed = parseDiscussStreamedResponse(fullText);
        setMessages((prev) => {
          const next = [...prev];
          if (next.length > 0) {
            next[next.length - 1] = { sender: 'chanakya', text: parsed.cleanText || 'Feedback complete.' };
          }
          return next;
        });

        if (parsed.suggestedRank) {
          setSelectedRank(parsed.suggestedRank);
        }
        if (parsed.suggestedInsight) {
          setCurrentInsight(parsed.suggestedInsight);
        }
        if (parsed.suggestedCategoryExplanation) {
          setCurrentCategoryExplanation(parsed.suggestedCategoryExplanation);
        }
        if (parsed.suggestedMasteryInsight) {
          setCurrentMasteryInsight(parsed.suggestedMasteryInsight);
        }
        if (parsed.suggestedExcellenceChallenge) {
          setCurrentExcellenceChallenge(parsed.suggestedExcellenceChallenge);
        }
      }
    } catch (err) {
      console.warn('API error during discussion fallback:', err);
      setMessages(prev => {
        const next = [...prev];
        if (next.length > 0) {
          next[next.length - 1] = { 
            sender: 'chanakya', 
            text: 'I understand your perspective. Let us align our path to maximize your strategic focus and productivity.' 
          };
        }
        return next;
      });
    } finally {
      setIsDiscussing(false);
    }
  };

  const currentRankInfo = rankDefinitions[selectedRank];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.1 }}
      className="w-full max-w-2xl mx-auto px-4"
      id="layer-council-container"
    >
      <div className="bg-[#0a0a0a] border-2 border-[#D4AF37]/35 rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(212,175,55,0.12)] relative overflow-hidden flex flex-col">
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/[0.02] rounded-full blur-3xl pointer-events-none"></div>

        {/* Council Title */}
        <div className="flex items-center justify-center gap-1.5 border-b border-amber-500/10 pb-4 mb-6">
          <Sparkles className="w-4 h-4 text-[#D4AF37] animate-pulse" />
          <h3 className="font-serif text-sm font-bold tracking-widest text-[#D4AF37] uppercase text-center">
            Strategic Advisor Consultation
          </h3>
        </div>

        {/* Primary Goal Alignment Reminder */}
        <div className="bg-amber-950/10 border border-amber-500/15 rounded-xl p-3 mb-6 text-center">
          <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest block mb-1">
            Active Primary Strategic Goal
          </span>
          <span className="font-serif text-xs text-[#D4AF37] italic font-semibold">
            "{task.primaryGoal || "Achieve peak professional impact and excel in key milestones"}"
          </span>
        </div>

        {/* Coach Portrait and Task Info */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6 items-center">
          {/* Portrait */}
          <div className="flex flex-col items-center justify-center col-span-1 border-r border-amber-500/5 pr-0 md:pr-4">
            <div className="relative shrink-0">
              <div className="absolute inset-0 bg-amber-500/15 rounded-2xl blur-lg pointer-events-none"></div>
              <img 
                src={coachPortrait} 
                className="w-24 h-24 rounded-2xl border-2 border-[#D4AF37] object-cover shadow-[0_0_20px_rgba(245,158,11,0.3)] relative z-10"
                alt="Professional Mentor" 
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 bg-[#050507] border border-amber-500/50 text-[#D4AF37] text-[8px] font-mono px-3.5 py-1 rounded-full z-20 whitespace-nowrap tracking-wider font-extrabold uppercase shadow-lg">
                MENTOR ADVISOR
              </div>
            </div>
          </div>

          {/* Task Info */}
          <div className="col-span-2 space-y-2 text-left bg-black/40 border border-amber-500/5 rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest">
                Strategic Alignment Evaluation
              </span>
              <span className={`inline-flex items-center text-[8.5px] font-mono font-bold px-2 py-0.5 rounded-md border ${currentRankInfo.badgeColor} uppercase`}>
                {selectedRank === 'King' ? 'Critical' : selectedRank === 'Queen' ? 'High' : selectedRank === 'Rook' ? 'Medium' : 'Low'} Priority
              </span>
            </div>
            <h4 className="font-sans font-bold text-sm text-gray-100 leading-tight">
              {task.title}
            </h4>
            {task.description && (
              <p className="text-[11px] text-gray-500 font-sans italic leading-relaxed line-clamp-2">
                "{task.description}"
              </p>
            )}
            <div className="text-[10px] text-amber-500/60 font-sans italic border-t border-amber-500/5 pt-2 mt-2">
              <span className="font-bold uppercase tracking-widest font-mono text-[8px] mr-1 text-amber-500/40">Evaluation Logic:</span> 
              {currentRankInfo.desc}
            </div>
          </div>
        </div>

        {/* Dynamic Mastery Insight & Excellence Challenge Boxes */}
        {(currentMasteryInsight || currentExcellenceChallenge) && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6">
            {currentMasteryInsight && (
              <div className="bg-[#15110a] border border-[#D4AF37]/20 p-3.5 rounded-xl text-left flex gap-2.5 items-start">
                <Award className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <span className="text-[8px] font-mono text-amber-500 uppercase tracking-wider block font-bold">
                    Mastery Insight
                  </span>
                  <p className="text-[11px] text-amber-100/90 font-serif leading-relaxed mt-1">
                    {currentMasteryInsight}
                  </p>
                </div>
              </div>
            )}

            {currentExcellenceChallenge && (
              <div className="bg-red-950/10 border border-red-500/20 p-3.5 rounded-xl text-left flex gap-2.5 items-start">
                <Flame className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[8px] font-mono text-red-400 uppercase tracking-wider block font-bold">
                    Push For Excellence
                  </span>
                  <p className="text-[11px] text-red-200/90 font-serif leading-relaxed mt-1">
                    {currentExcellenceChallenge}
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* CONSTRUCTIVE DISCUSSION SCROLL */}
        <div className="flex flex-col bg-[#050507] border border-[#D4AF37]/15 rounded-2xl overflow-hidden shadow-inner mb-6">
          <div className="bg-[#15110a] border-b border-[#D4AF37]/15 px-4 py-3 flex items-center justify-between">
            <span className="text-[9px] font-mono text-amber-500/70 tracking-widest uppercase font-bold flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-[#D4AF37]" />
              Strategic Alignment Dialogue
            </span>
            <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest">
              Live Mentor Session
            </span>
          </div>

          {/* Dialogue Log */}
          <div className="p-4 h-[180px] overflow-y-auto space-y-4 font-sans text-xs flex flex-col scrollbar-thin scrollbar-thumb-amber-500/20">
            {messages.map((msg, index) => {
              const isChanakya = msg.sender === 'chanakya';
              return (
                <div 
                  key={index}
                  className={`flex flex-col max-w-[85%] ${isChanakya ? 'self-start text-left' : 'self-end text-right'}`}
                >
                  <span className={`font-mono text-[8px] uppercase tracking-widest mb-1 ${isChanakya ? 'text-amber-500/50' : 'text-gray-500'}`}>
                    {isChanakya ? 'Professional Mentor' : 'User'}
                  </span>
                  <div 
                    className={`rounded-2xl p-3.5 leading-relaxed font-serif ${
                      isChanakya 
                        ? 'bg-[#15110a] border border-[#D4AF37]/10 text-amber-100 rounded-tl-none italic' 
                        : 'bg-[#1a1b23] border border-slate-800 text-gray-200 rounded-tr-none'
                     }`}
                  >
                    "{msg.text}"
                  </div>
                </div>
              );
            })}

            {isDiscussing && (
              <div className="flex flex-col max-w-[85%] self-start text-left">
                <span className="font-mono text-[8px] uppercase tracking-widest mb-1 text-amber-500/50">
                  Mentor
                </span>
                <div className="bg-[#15110a] border border-[#D4AF37]/10 text-amber-500/70 rounded-2xl rounded-tl-none p-3.5 italic flex items-center gap-2">
                  <RefreshCw className="w-4 h-4 text-[#D4AF37] animate-spin" />
                  <span>Mentor is evaluating the task details...</span>
                </div>
              </div>
            )}
            
            <div ref={chatEndRef} />
          </div>

          {/* Suggestive Prompt Chips */}
          <div className="px-4 py-2 border-t border-[#D4AF37]/10 bg-[#070606] flex flex-wrap gap-1.5 items-center">
            <span className="text-[8px] font-mono text-amber-500/40 uppercase tracking-wider mr-1">Recommended Next Steps:</span>
            {getSuggestedPrompts(selectedRank).map((promptText, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSuggestiveClick(promptText)}
                disabled={isDiscussing}
                className="text-[10px] font-sans bg-amber-950/15 hover:bg-[#D4AF37] border border-[#D4AF37]/25 hover:border-[#D4AF37] text-amber-100/90 hover:text-black px-2.5 py-0.5 rounded-full transition-all cursor-pointer disabled:opacity-40 disabled:hover:bg-amber-950/15 disabled:hover:text-amber-100/90 font-semibold"
              >
                {promptText}
              </button>
            ))}
          </div>

          {/* Send Input Panel */}
          <form onSubmit={handleSendMessage} className="border-t border-[#D4AF37]/15 p-2 bg-black flex items-center gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Explain task urgency, clarify goals, or request planning tips..."
              disabled={isDiscussing}
              className="flex-grow bg-[#050507] border border-slate-800 focus:border-[#D4AF37]/50 text-gray-100 rounded-xl px-3.5 py-2 text-xs outline-none transition-all placeholder-gray-600 font-serif"
            />
            <button
              type="submit"
              disabled={isDiscussing || !inputText.trim()}
              className="bg-amber-600/20 hover:bg-[#D4AF37] border border-[#D4AF37]/30 text-[#D4AF37] hover:text-black p-2.5 rounded-xl transition-all disabled:opacity-30 disabled:hover:bg-amber-600/20 disabled:hover:text-[#D4AF37] cursor-pointer flex items-center justify-center"
              title="Send message to mentor"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>

        {/* Override / Approval Controls */}
        <div className="space-y-4">
          {/* Override Controls */}
          <div className="bg-black/40 border border-amber-500/10 p-3 rounded-2xl text-center">
            <span className="block text-[8px] font-mono text-gray-500 uppercase tracking-widest mb-2">
              Adjust Recommended Priority Category:
            </span>
            <div className="grid grid-cols-4 gap-2">
              {(['King', 'Queen', 'Rook', 'Pawn'] as const).map((r) => {
                const isCurrent = r === selectedRank;
                const displayLabel = r === 'King' ? 'Critical' : r === 'Queen' ? 'High' : r === 'Rook' ? 'Medium' : 'Low';
                return (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setSelectedRank(r)}
                    className={`font-sans font-bold text-[9px] py-2 rounded-lg transition-all uppercase cursor-pointer border ${
                      isCurrent
                        ? 'bg-[#D4AF37]/15 border-[#D4AF37] text-[#D4AF37] shadow-[0_0_10px_rgba(212,175,55,0.2)] font-extrabold'
                        : 'bg-[#0a0a0f] hover:bg-[#121319] border-slate-800 text-gray-400 hover:text-white'
                    }`}
                  >
                    {displayLabel}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Accept & Action Buttons */}
          <div className="flex flex-col gap-2">
            <button
              type="button"
              onClick={() => onApprove(task.id, selectedRank, currentInsight, currentCategoryExplanation, currentMasteryInsight, currentExcellenceChallenge)}
              className="w-full bg-gradient-to-r from-amber-600 via-[#D4AF37] to-amber-600 hover:brightness-110 active:scale-[0.99] text-black font-sans font-black text-xs py-3.5 rounded-xl shadow-lg transition-all uppercase tracking-widest cursor-pointer flex items-center justify-center gap-1.5"
              id="council-approve-btn"
            >
              <Sparkles className="w-4 h-4 shrink-0" />
              Approve & Save to Dashboard
            </button>

            <button
              type="button"
              onClick={() => onReject(task.id)}
              className="w-full py-2 bg-red-950/10 hover:bg-red-950/20 border border-red-500/20 text-red-400 hover:text-red-300 font-mono text-[9px] rounded-xl transition-all uppercase tracking-widest cursor-pointer flex items-center justify-center gap-1.5"
              id="council-reject-btn"
            >
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              Discard Task
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
