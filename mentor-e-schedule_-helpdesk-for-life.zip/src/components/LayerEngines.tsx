import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, Zap, Sparkles, RefreshCw, AlertTriangle, CheckCircle, 
  TrendingUp, Gauge, ArrowRight, CornerDownRight, Check, Plus, Languages,
  MessageSquare, Heart, User, Sparkle, Calendar, Brain
} from 'lucide-react';
import { Task, ChessRank } from '../types';
import { MentorPanel } from './MentorPanel';
import { DailyPlanningWizard } from './DailyPlanningWizard';
import { ReflectionPanel } from './ReflectionPanel';

interface LayerEnginesProps {
  primaryGoal: string;
  onDeployTasks: (tasks: Omit<Task, 'id' | 'createdAt' | 'completed'>[]) => void;
  onReturnToBoard: () => void;
}

interface CompilerIssue {
  item: string;
  issue: string;
  reason: string;
}

interface CorrectedCompilerTask {
  task: string;
  category: 'King' | 'Queen' | 'Rook' | 'Pawn' | 'Unknown';
  rationale_for_category: string;
  notes: string;
  deployed?: boolean;
}

interface CompilerResponse {
  detected_issues: CompilerIssue[];
  corrected_tasks: CorrectedCompilerTask[];
  standardization_rules_applied: string[];
  data_quality_score: number;
}

interface RatifierInconsistency {
  item: string;
  strategic_risk: string;
  ratification_strategy: string;
}

interface CorrectedRatifierTask {
  task: string;
  category: 'King' | 'Queen' | 'Rook' | 'Pawn';
  rationale: string;
  priority_score: number;
  deployed?: boolean;
}

interface RatifierResponse {
  grandmaster_assessment: string;
  detected_inconsistencies: RatifierInconsistency[];
  corrected_tasks: CorrectedRatifierTask[];
  tempo_analysis: string;
}

interface LoopholeDetected {
  loophole: string;
  impact: string;
  vulnerability: string;
}

interface PatchFix {
  patch_id: string;
  description: string;
  target_module: string;
}

interface LoopholeResponse {
  loopholes_detected: LoopholeDetected[];
  patch_fixes: PatchFix[];
  enforced_constraints: string[];
}

interface OriginalSentence {
  original: string;
  humanized: string;
  rule_violated: string;
}

interface LanguagePatchResponse {
  assessment_of_original_text: string;
  original_sentences: OriginalSentence[];
  clarified_summary: string;
  actionability_score: number;
}

export const LayerEngines: React.FC<LayerEnginesProps> = ({ 
  primaryGoal, 
  onDeployTasks, 
  onReturnToBoard 
}) => {
  const [activeTab, setActiveTab] = useState<'compiler' | 'ratifier' | 'loophole' | 'language' | 'mentor' | 'planner' | 'reflection'>('compiler');
  const [rawInput, setRawInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  // Compiler results
  const [compilerResults, setCompilerResults] = useState<CompilerResponse | null>(null);
  // Ratifier results
  const [ratifierResults, setRatifierResults] = useState<RatifierResponse | null>(null);
  // Loophole results
  const [loopholeResults, setLoopholeResults] = useState<LoopholeResponse | null>(null);
  // Language results
  const [languageResults, setLanguageResults] = useState<LanguagePatchResponse | null>(null);

  // Track deployed states locally
  const [deployedCompilerIdxs, setDeployedCompilerIdxs] = useState<Record<number, boolean>>({});
  const [deployedRatifierIdxs, setDeployedRatifierIdxs] = useState<Record<number, boolean>>({});

  // Coach Chat State
  const [coachInput, setCoachInput] = useState('');
  const [coachHistory, setCoachHistory] = useState<Array<{ sender: 'user' | 'coach', text: string, time: string, insights?: string, suggestedNextSteps?: string[] }>>([
    {
      sender: 'coach',
      text: "Hello! I'm your supportive senior mentor. Whether you're feeling overwhelmed by your current scope, wondering if you are learning while working, trying to make career decisions, or just want to outline a daily strategy, I'm here to listen calmly and help you organize your thoughts. What's on your mind today?",
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [isCoachLoading, setIsCoachLoading] = useState(false);
  const [rememberGoals, setRememberGoals] = useState(true);
  const [rememberProjects, setRememberProjects] = useState(true);
  const [rememberDiscussions, setRememberDiscussions] = useState(true);
  const [rememberStyle, setRememberStyle] = useState(true);

  const handleSendCoachMessage = async () => {
    if (!coachInput.trim()) return;

    const userMsg = coachInput.trim();
    setCoachInput('');
    const newHistory = [
      ...coachHistory,
      { sender: 'user' as const, text: userMsg, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }
    ];
    setCoachHistory(newHistory);
    setIsCoachLoading(true);

    try {
      const response = await fetch('/api/coach/free-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userMessage: userMsg,
          history: newHistory.map(h => ({ sender: h.sender, text: h.text })),
          primaryGoal: primaryGoal,
          memory: {
            rememberGoals,
            rememberProjects,
            rememberDiscussions,
            rememberStyle
          }
        })
      });

      if (!response.ok) {
        throw new Error('Coach channel had a transient error');
      }

      const data = await response.json();
      setCoachHistory(prev => [
        ...prev,
        {
          sender: 'coach',
          text: data.coachResponse,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          insights: data.insights,
          suggestedNextSteps: data.suggestedNextSteps
        }
      ]);
    } catch (err: any) {
      console.error(err);
      setCoachHistory(prev => [
        ...prev,
        {
          sender: 'coach',
          text: "I want to make sure I support you fully, but I had a small connection issue with my strategizing core. Take a deep breath. Let's look at what we can control right now: Can we break down what's feeling heavy into a smaller list?",
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          suggestedNextSteps: ["Write down the single blocker", "Focus on a 2-minute action item"]
        }
      ]);
    } finally {
      setIsCoachLoading(false);
    }
  };

  const handleProcessCompiler = async () => {
    if (!rawInput.trim()) {
      setError('Please provide raw tactical input first.');
      return;
    }
    
    setIsLoading(true);
    setError('');
    setCompilerResults(null);
    setDeployedCompilerIdxs({});

    try {
      const response = await fetch('/api/coach/standardize-compiler', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawInput })
      });

      if (!response.ok) {
        throw new Error('Data compiler failed to analyze the tactical dataset.');
      }

      const data = await response.json();
      setCompilerResults(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Transmission failure on the compiler channel.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleProcessRatifier = async () => {
    if (!rawInput.trim()) {
      setError('Please provide raw strategic input first.');
      return;
    }

    setIsLoading(true);
    setError('');
    setRatifierResults(null);
    setDeployedRatifierIdxs({});

    try {
      const response = await fetch('/api/coach/ratify-engine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawInput })
      });

      if (!response.ok) {
        throw new Error('Strategic ratification engine failed to compute.');
      }

      const data = await response.json();
      setRatifierResults(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Transmission failure on the ratification channel.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleProcessLoophole = async () => {
    if (!rawInput.trim()) {
      setError('Please provide system strategy details to analyze for loopholes.');
      return;
    }

    setIsLoading(true);
    setError('');
    setLoopholeResults(null);

    try {
      const response = await fetch('/api/coach/loophole-patch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawInput })
      });

      if (!response.ok) {
        throw new Error('Loophole Patch Module failed to compute.');
      }

      const data = await response.json();
      setLoopholeResults(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Transmission failure on the loophole-patch channel.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleProcessLanguage = async () => {
    if (!rawInput.trim()) {
      setError('Please provide system statements to stabilize.');
      return;
    }

    setIsLoading(true);
    setError('');
    setLanguageResults(null);

    try {
      const response = await fetch('/api/coach/language-patch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawInput })
      });

      if (!response.ok) {
        throw new Error('Language Stabilization Module failed to compute.');
      }

      const data = await response.json();
      setLanguageResults(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Transmission failure on the language-patch channel.');
    } finally {
      setIsLoading(false);
    }
  };

  const deploySingleCompilerTask = (idx: number, taskObj: CorrectedCompilerTask) => {
    if (deployedCompilerIdxs[idx]) return;

    const rank: ChessRank = taskObj.category === 'Unknown' ? 'Queen' : taskObj.category;
    onDeployTasks([{
      title: taskObj.task,
      description: `${taskObj.notes}\n(Standardized from Compiler)`,
      rank: rank,
      primaryGoal: primaryGoal,
      categoryExplanation: taskObj.rationale_for_category,
      insight: 'Compiled and verified by the Strategic Task Engine.',
      masteryInsight: 'Maintain this structured pace to optimize your daily progress.'
    }]);

    setDeployedCompilerIdxs(prev => ({ ...prev, [idx]: true }));
  };

  const deployAllCompilerTasks = () => {
    if (!compilerResults) return;

    const toDeploy = compilerResults.corrected_tasks
      .map((t, idx) => ({ t, idx }))
      .filter(({ idx }) => !deployedCompilerIdxs[idx]);

    if (toDeploy.length === 0) return;

    const formatted = toDeploy.map(({ t }) => {
      const rank: ChessRank = t.category === 'Unknown' ? 'Queen' : t.category;
      return {
        title: t.task,
        description: `${t.notes}\n(Standardized from Compiler)`,
        rank: rank,
        primaryGoal: primaryGoal,
        categoryExplanation: t.rationale_for_category,
        insight: 'Compiled and verified by the Strategic Task Engine.',
        masteryInsight: 'Maintain this structured pace to optimize your daily progress.'
      };
    });

    onDeployTasks(formatted);

    const updatedIdxs = { ...deployedCompilerIdxs };
    toDeploy.forEach(({ idx }) => {
      updatedIdxs[idx] = true;
    });
    setDeployedCompilerIdxs(updatedIdxs);
  };

  const deploySingleRatifierTask = (idx: number, taskObj: CorrectedRatifierTask) => {
    if (deployedRatifierIdxs[idx]) return;

    onDeployTasks([{
      title: taskObj.task,
      description: `${taskObj.rationale}\nPriority Rating: ${taskObj.priority_score}/10\n(Ratified by Strategic Advisor)`,
      rank: taskObj.category,
      primaryGoal: primaryGoal,
      categoryExplanation: `Ratified task matching category: ${taskObj.category === 'King' ? 'Critical' : taskObj.category === 'Queen' ? 'High' : taskObj.category === 'Rook' ? 'Medium' : 'Low'}`,
      insight: 'This objective has been fortified to secure consistent focus and protect key goals.',
      masteryInsight: 'Focus intensely on this primary objective to drive significant progress.'
    }]);

    setDeployedRatifierIdxs(prev => ({ ...prev, [idx]: true }));
  };

  const deployAllRatifierTasks = () => {
    if (!ratifierResults) return;

    const toDeploy = ratifierResults.corrected_tasks
      .map((t, idx) => ({ t, idx }))
      .filter(({ idx }) => !deployedRatifierIdxs[idx]);

    if (toDeploy.length === 0) return;

    const formatted = toDeploy.map(({ t }) => {
      return {
        title: t.task,
        description: `${t.rationale}\nPriority Rating: ${t.priority_score}/10\n(Ratified by Strategic Advisor)`,
        rank: t.category,
        primaryGoal: primaryGoal,
        categoryExplanation: `Ratified task matching category: ${t.category === 'King' ? 'Critical' : t.category === 'Queen' ? 'High' : t.category === 'Rook' ? 'Medium' : 'Low'}`,
        insight: 'This objective has been fortified to secure consistent focus and protect key goals.',
        masteryInsight: 'Focus intensely on this primary objective to drive significant progress.'
      };
    });

    onDeployTasks(formatted);

    const updatedIdxs = { ...deployedRatifierIdxs };
    toDeploy.forEach(({ idx }) => {
      updatedIdxs[idx] = true;
    });
    setDeployedRatifierIdxs(updatedIdxs);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 15 }}
      transition={{ duration: 0.3 }}
      className="w-full max-w-5xl mx-auto px-4 py-6"
      id="layer-engines-container"
    >
      <div className="bg-[#0b0c10] border border-gray-800 rounded-3xl p-6 md:p-8 shadow-[0_0_40px_rgba(212,175,55,0.03)] relative overflow-hidden flex flex-col gap-8">
        
        {/* Glow Effects */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/[0.02] rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-500/[0.02] rounded-full blur-3xl pointer-events-none"></div>

        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-800 pb-5">
          <div>
            <div className="flex items-center gap-2 text-[#d4af37] font-sans text-xs font-bold uppercase tracking-wider mb-1">
              <Sparkle className="w-4 h-4 text-[#d4af37]" />
              <span>Helpful Tools</span>
            </div>
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-gray-100 tracking-tight">
              Productivity Tools
            </h2>
            <p className="text-[12px] text-gray-400 font-sans mt-1">
              Helpful tools to organize, improve, and review your work.
            </p>
          </div>

          <button
            onClick={onReturnToBoard}
            className="self-start md:self-auto bg-gray-900/60 hover:bg-gray-900 border border-gray-800 hover:border-gray-700 text-gray-400 hover:text-gray-200 font-sans text-xs px-4 py-2.5 rounded-xl uppercase tracking-wider transition-all cursor-pointer"
            id="engines-return-btn"
          >
            ← Return to Board
          </button>
        </div>

        {/* Primary Engine Toggles (Cards-style Grid of 7) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 bg-black/60 p-2 rounded-2xl border border-gray-800/80 gap-2">
          <button
            onClick={() => {
              setActiveTab('compiler');
              setError('');
            }}
            className={`p-3 rounded-xl font-sans text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 min-h-[90px] ${
              activeTab === 'compiler'
                ? 'bg-amber-500/10 border border-amber-500/40 text-amber-200'
                : 'border border-transparent text-gray-400 hover:bg-white/[0.02] hover:text-gray-200'
            }`}
            id="tab-compiler-toggle"
          >
            <div className="flex items-center gap-2">
              <Gauge className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="font-bold text-xs">Organize Tasks</span>
            </div>
            <span className="text-[10px] text-gray-500 leading-tight">Clean up messy streams of work.</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('ratifier');
              setError('');
            }}
            className={`p-3 rounded-xl font-sans text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 min-h-[90px] ${
              activeTab === 'ratifier'
                ? 'bg-amber-500/10 border border-amber-500/40 text-amber-200'
                : 'border border-transparent text-gray-400 hover:bg-white/[0.02] hover:text-gray-200'
            }`}
            id="tab-ratifier-toggle"
          >
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="font-bold text-xs">Priority Assistant</span>
            </div>
            <span className="text-[10px] text-gray-500 leading-tight">Refine and set priorities.</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('loophole');
              setError('');
            }}
            className={`p-3 rounded-xl font-sans text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 min-h-[90px] ${
              activeTab === 'loophole'
                ? 'bg-amber-500/10 border border-amber-500/40 text-amber-200'
                : 'border border-transparent text-gray-400 hover:bg-white/[0.02] hover:text-gray-200'
            }`}
            id="tab-loophole-toggle"
          >
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="font-bold text-xs">Review My Plan</span>
            </div>
            <span className="text-[10px] text-gray-500 leading-tight">Check for schedule holes or risks.</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('language');
              setError('');
            }}
            className={`p-3 rounded-xl font-sans text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 min-h-[90px] ${
              activeTab === 'language'
                ? 'bg-amber-500/10 border border-amber-500/40 text-amber-200'
                : 'border border-transparent text-gray-400 hover:bg-white/[0.02] hover:text-gray-200'
            }`}
            id="tab-language-toggle"
          >
            <div className="flex items-center gap-2">
              <Languages className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="font-bold text-xs">Improve Task Wording</span>
            </div>
            <span className="text-[10px] text-gray-500 leading-tight">Convert jargon into simple actions.</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('planner');
              setError('');
            }}
            className={`p-3 rounded-xl font-sans text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 min-h-[90px] ${
              activeTab === 'planner'
                ? 'bg-amber-500/10 border border-amber-500/40 text-amber-200'
                : 'border border-transparent text-gray-400 hover:bg-white/[0.02] hover:text-gray-200'
            }`}
            id="tab-planner-toggle"
          >
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="font-bold text-xs">Daily Planner</span>
            </div>
            <span className="text-[10px] text-gray-500 leading-tight">Sequence day by available hours & energy.</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('reflection');
              setError('');
            }}
            className={`p-3 rounded-xl font-sans text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 min-h-[90px] ${
              activeTab === 'reflection'
                ? 'bg-amber-500/10 border border-amber-500/40 text-amber-200'
                : 'border border-transparent text-gray-400 hover:bg-white/[0.02] hover:text-gray-200'
            }`}
            id="tab-reflection-toggle"
          >
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="font-bold text-xs">Recovery Reflection</span>
            </div>
            <span className="text-[10px] text-gray-500 leading-tight">Turn missed tasks into strong next steps.</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('mentor');
              setError('');
            }}
            className={`p-3 rounded-xl font-sans text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 min-h-[90px] ${
              activeTab === 'mentor'
                ? 'bg-amber-500/10 border border-amber-500/40 text-amber-200'
                : 'border border-transparent text-gray-400 hover:bg-white/[0.02] hover:text-gray-200'
            }`}
            id="tab-mentor-toggle"
          >
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="font-bold text-xs">Talk to Mentor</span>
            </div>
            <span className="text-[10px] text-gray-500 leading-tight">Supportive mentoring discussion.</span>
          </button>
        </div>

        {/* WORKSPACE AREA: CONDITIONAL FOR CHAT VS PLANNER VS RAW INPUT */}
        {activeTab === 'mentor' ? (
          <MentorPanel />
        ) : activeTab === 'planner' ? (
          <DailyPlanningWizard />
        ) : activeTab === 'reflection' ? (
          <ReflectionPanel />
        ) : (
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <label className="font-mono text-[10px] uppercase tracking-widest text-gray-400 font-bold">
                {activeTab === 'compiler' 
                  ? 'Raw Task List (Enter messy tasks, rough notes, or ideas)'
                  : activeTab === 'ratifier'
                  ? 'Strategic Plans (Enter tasks to review and prioritize)'
                  : activeTab === 'loophole'
                  ? 'Weekly Plan or Schedule (Analyze for scheduling gaps or risks)'
                  : 'Abstract/Complex Wording (Enter wordy sentences to simplify)'}
              </label>
              <button
                onClick={() => {
                  setRawInput(
                    activeTab === 'compiler'
                      ? "draft report by friday afternoon\nreplying to clients emails is taking too long\nspend 2 hours practicing coding algorithms\ngo to gym for health"
                      : activeTab === 'ratifier'
                      ? "i will probably try to fix the codebase sometime next week if i have energy\nlook at marketing data when not busy\nwrite a post for social media later"
                      : activeTab === 'loophole'
                      ? "Working 8 hours straight without a single break scheduled, and listing gym under critical focus instead of finishing the presentation report."
                      : "Foundational growth ensures long-term capabilities. We must make sure to optimize resource allocation so we don't experience high-intensity burnout. This task helps stay consistent."
                  );
                }}
                className="text-[#d4af37]/60 hover:text-[#d4af37] font-mono text-[9px] uppercase tracking-widest transition-all"
                id="load-sample-btn"
              >
                [ Load Sample ]
              </button>
            </div>

            <textarea
              value={rawInput}
              onChange={(e) => setRawInput(e.target.value)}
              placeholder={
                activeTab === 'compiler'
                  ? "Example:\n- finish presentation slides\n- reply to team regarding feedback\n- schedule exercise sessions\n- learn coding concepts"
                  : activeTab === 'ratifier'
                  ? "Example:\n- read books randomly\n- sort out the backend soon\n- build the app when i have time"
                  : activeTab === 'loophole'
                  ? "Example:\n- packed schedule from 9 AM to 6 PM with zero rest blocks\n- gym and emails taking up all morning hours"
                  : "Example:\n- Focus on skill-building tasks. They improve long-term performance."
              }
              className="w-full h-36 bg-black/60 border border-gray-800 focus:border-[#d4af37]/60 rounded-2xl p-4 font-mono text-xs text-gray-300 placeholder-gray-600 focus:outline-none resize-none transition-all shadow-inner"
              id="engine-raw-textarea"
            />

            <button
              onClick={
                activeTab === 'compiler' 
                  ? handleProcessCompiler 
                  : activeTab === 'ratifier' 
                  ? handleProcessRatifier 
                  : activeTab === 'loophole'
                  ? handleProcessLoophole
                  : handleProcessLanguage
              }
              disabled={isLoading || !rawInput.trim()}
              className="bg-[#d4af37] hover:brightness-110 disabled:opacity-50 text-black font-sans font-extrabold text-xs py-4 rounded-xl uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-[#d4af37]/10"
              id="engine-process-btn"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Analyzing...</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  <span>
                    {activeTab === 'compiler' 
                      ? 'Organize Tasks' 
                      : activeTab === 'ratifier' 
                      ? 'Priority Assistant'
                      : activeTab === 'loophole'
                      ? 'Review My Plan'
                      : 'Improve Task Wording'}
                  </span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Error Notice */}
        {error && (
          <div className="bg-red-950/20 border border-red-500/30 p-4 rounded-xl flex items-center gap-2 text-red-400 font-sans text-xs">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Results Area */}
        <AnimatePresence mode="wait">
          {/* TAB 1 RESULTS: ORGANIZE TASKS */}
          {activeTab === 'compiler' && compilerResults && (
            <motion.div
              key="compiler-results"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              {/* Clarity & Rules Banner */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-[#0e0f14] border border-gray-800 p-4 rounded-2xl flex flex-col justify-center items-center text-center relative">
                  <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest block mb-2 font-bold">
                    PLAN CLARITY RATING
                  </span>
                  
                  <div className="relative flex items-center justify-center">
                    <svg className="w-24 h-24">
                      <circle
                        className="text-gray-800"
                        strokeWidth="6"
                        stroke="currentColor"
                        fill="transparent"
                        r="38"
                        cx="48"
                        cy="48"
                      />
                      <circle
                        className="text-[#d4af37] transition-all duration-500"
                        strokeWidth="6"
                        strokeDasharray={2 * Math.PI * 38}
                        strokeDashoffset={2 * Math.PI * 38 * (1 - compilerResults.data_quality_score / 100)}
                        strokeLinecap="round"
                        stroke="currentColor"
                        fill="transparent"
                        r="38"
                        cx="48"
                        cy="48"
                      />
                    </svg>
                    <span className="absolute font-mono text-xl font-bold text-gray-200">
                      {compilerResults.data_quality_score}%
                    </span>
                  </div>

                  <span className="text-[9px] font-sans text-[#d4af37] font-semibold mt-2 uppercase tracking-wide">
                    {compilerResults.data_quality_score >= 80 ? 'Clear & Actionable' : 'Slightly Ambiguous'}
                  </span>
                </div>

                <div className="md:col-span-2 bg-[#0e0f14] border border-gray-800 p-5 rounded-2xl flex flex-col justify-between">
                  <div>
                    <h4 className="font-mono text-[10px] text-gray-400 uppercase tracking-widest font-black mb-2 flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5 text-green-500" />
                      Task Formatting Complete
                    </h4>
                    <p className="text-[10px] text-gray-500 font-sans mb-3 leading-relaxed">
                      We've analyzed your notes and expanded them into standard, clear action items with estimated time commitments and suggestions.
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {compilerResults.standardization_rules_applied.map((rule, idx) => (
                      <span
                        key={idx}
                        className="bg-[#d4af37]/5 border border-[#d4af37]/25 text-[#d4af37] font-mono text-[9px] px-2.5 py-1 rounded-md"
                      >
                        {rule}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Detected Planning Bottlenecks */}
              {compilerResults.detected_issues && compilerResults.detected_issues.length > 0 && (
                <div className="bg-[#0f0a0c] border border-red-950/60 p-5 rounded-2xl">
                  <h4 className="font-mono text-[10px] text-red-400 uppercase tracking-widest font-black mb-3 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-red-500 animate-pulse" />
                    Planning Challenges Identified ({compilerResults.detected_issues.length})
                  </h4>

                  <div className="divide-y divide-red-950/30 space-y-3.5">
                    {compilerResults.detected_issues.map((issue, idx) => (
                      <div key={idx} className="pt-3 first:pt-0 flex flex-col md:flex-row md:items-start gap-3">
                        <div className="md:w-1/3">
                          <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block">Your Note</span>
                          <span className="font-mono text-xs text-gray-400 line-through decoration-red-900/50 block font-semibold truncate">
                            {issue.item}
                          </span>
                        </div>
                        <div className="md:w-1/4">
                          <span className="text-[9px] font-mono text-red-400/80 uppercase tracking-wider block font-bold">Identified Issue</span>
                          <span className="text-[11px] text-red-200/90 font-sans font-medium">{issue.issue}</span>
                        </div>
                        <div className="md:w-5/12">
                          <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block">Why It Matters</span>
                          <p className="text-[10.5px] text-gray-400 font-sans leading-relaxed italic">
                            {issue.reason}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Suggested Actionable Tasks */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-mono text-[10px] text-gray-400 uppercase tracking-widest font-black flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                    Suggested Actionable Tasks ({compilerResults.corrected_tasks.length})
                  </h4>
                  
                  <button
                    onClick={deployAllCompilerTasks}
                    className="bg-gray-900 hover:bg-gray-850 text-[#d4af37] border border-[#d4af37]/30 hover:border-[#d4af37]/60 font-mono text-[9px] uppercase tracking-widest px-3 py-1.5 rounded-lg transition-all"
                    id="compiler-deploy-all-btn"
                  >
                    Add All Tasks
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {compilerResults.corrected_tasks.map((taskObj, idx) => (
                    <div 
                      key={idx}
                      className={`border p-4.5 rounded-2xl relative flex flex-col justify-between h-full transition-all ${
                        deployedCompilerIdxs[idx]
                          ? 'bg-green-950/10 border-green-900/30 opacity-70'
                          : 'bg-black/40 hover:bg-black/60 border-gray-850'
                      }`}
                    >
                      <div className="space-y-3 mb-4">
                        <div className="flex items-center justify-between gap-2">
                          <span className={`font-mono text-[8px] uppercase tracking-widest px-2 py-0.5 rounded-full font-bold ${
                            taskObj.category === 'King' ? 'bg-red-500/10 text-red-400 border border-red-500/25' :
                            taskObj.category === 'Queen' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/25' :
                            taskObj.category === 'Rook' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/25' :
                            taskObj.category === 'Pawn' ? 'bg-green-500/10 text-green-400 border border-green-500/25' :
                            'bg-gray-800 text-gray-400'
                          }`}>
                            {taskObj.category === 'King' ? 'Critical Focus' :
                             taskObj.category === 'Queen' ? 'High Priority' :
                             taskObj.category === 'Rook' ? 'Medium Priority' :
                             'Low Priority'}
                          </span>
                          
                          {deployedCompilerIdxs[idx] && (
                            <span className="flex items-center gap-1 font-mono text-[8.5px] uppercase tracking-widest text-green-400 font-extrabold">
                              <Check className="w-3 h-3" /> Added to list
                            </span>
                          )}
                        </div>

                        <div className="space-y-1">
                          <h5 className="font-sans font-bold text-xs text-gray-200">
                            {taskObj.task}
                          </h5>
                          <p className="text-[10.5px] text-gray-400 font-sans leading-relaxed">
                            {taskObj.notes}
                          </p>
                        </div>

                        <div className="bg-black/60 p-2.5 rounded-xl border border-gray-900 flex items-start gap-1.5">
                          <CornerDownRight className="w-3 h-3 text-[#d4af37] shrink-0 mt-0.5" />
                          <p className="text-[9.5px] text-gray-500 font-sans italic leading-tight">
                            {taskObj.rationale_for_category}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => deploySingleCompilerTask(idx, taskObj)}
                        disabled={deployedCompilerIdxs[idx]}
                        className={`w-full font-mono text-[9px] uppercase tracking-widest py-2 rounded-xl border flex items-center justify-center gap-1.5 transition-all ${
                          deployedCompilerIdxs[idx]
                            ? 'bg-transparent border-green-900/30 text-green-500/50 cursor-default'
                            : 'bg-gradient-to-r from-amber-950/40 to-black hover:border-[#d4af37]/50 border-gray-800 hover:text-[#d4af37] text-gray-400 cursor-pointer'
                        }`}
                      >
                        {deployedCompilerIdxs[idx] ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>In active list</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5 text-[#d4af37]" />
                            <span>Add task</span>
                          </>
                        )}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}          {/* TAB 2 RESULTS: PRIORITY ASSISTANT */}
          {activeTab === 'ratifier' && ratifierResults && (
            <motion.div
              key="ratifier-results"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              {/* Coach Feedback & Momentum */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2 bg-[#0b0c10] border border-[#d4af37]/20 p-5 rounded-2xl relative">
                  <div className="absolute top-2 right-4 text-[8px] font-mono text-[#d4af37]/30 uppercase tracking-widest font-black">
                    COACH FEEDBACK
                  </div>
                  <div className="flex items-start gap-3 mt-2">
                    <Shield className="w-5 h-5 text-[#d4af37] shrink-0 mt-0.5 animate-pulse" />
                    <div>
                      <p className="font-serif text-xs md:text-sm text-gray-300 font-medium italic leading-relaxed">
                        "{ratifierResults.grandmaster_assessment}"
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-[#0e0f14] border border-gray-800 p-5 rounded-2xl flex flex-col justify-between">
                  <div className="flex items-center gap-1.5 mb-2">
                    <TrendingUp className="w-4 h-4 text-amber-500" />
                    <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest font-bold block">
                      PACING & MOMENTUM
                    </span>
                  </div>

                  <p className="font-sans text-[11px] text-[#d4af37] font-semibold leading-relaxed bg-[#d4af37]/5 border border-[#d4af37]/15 p-3 rounded-xl italic">
                    {ratifierResults.tempo_analysis}
                  </p>
                </div>
              </div>

              {/* Detected Planning Bottlenecks */}
              {ratifierResults.detected_inconsistencies && ratifierResults.detected_inconsistencies.length > 0 && (
                <div className="bg-[#110d0a] border border-amber-950/60 p-5 rounded-2xl">
                  <h4 className="font-mono text-[10px] text-amber-400 uppercase tracking-widest font-black mb-3 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                    Planning Challenges & Conflicts ({ratifierResults.detected_inconsistencies.length})
                  </h4>

                  <div className="divide-y divide-amber-950/20 space-y-3.5">
                    {ratifierResults.detected_inconsistencies.map((inc, idx) => (
                      <div key={idx} className="pt-3 first:pt-0 flex flex-col md:flex-row md:items-start gap-4">
                        <div className="md:w-1/3">
                          <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block">Planning Concern</span>
                          <span className="font-mono text-xs text-gray-400 line-through decoration-amber-900/50 block font-semibold truncate">
                            {inc.item}
                          </span>
                        </div>
                        <div className="md:w-1/3">
                          <span className="text-[9px] font-mono text-red-400/80 uppercase tracking-wider block font-bold">Potential Blocker Risk</span>
                          <span className="text-[10.5px] text-red-200/90 font-sans leading-relaxed block">{inc.strategic_risk}</span>
                        </div>
                        <div className="md:w-1/3">
                          <span className="text-[9px] font-mono text-green-400/80 uppercase tracking-wider block font-bold">Recommended Adjustment</span>
                          <p className="text-[10.5px] text-gray-300 font-sans leading-relaxed italic">
                            {inc.ratification_strategy}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Corrected Tasks / Core Priorities */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-mono text-[10px] text-gray-400 uppercase tracking-widest font-black flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-[#d4af37]" />
                    Recommended Core Priorities ({ratifierResults.corrected_tasks.length})
                  </h4>
                  
                  <button
                    onClick={deployAllRatifierTasks}
                    className="bg-gray-900 hover:bg-gray-850 text-[#d4af37] border border-[#d4af37]/30 hover:border-[#d4af37]/60 font-mono text-[9px] uppercase tracking-widest px-3 py-1.5 rounded-lg transition-all"
                    id="ratifier-deploy-all-btn"
                  >
                    Add All Priorities
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {ratifierResults.corrected_tasks.map((taskObj, idx) => (
                    <div 
                      key={idx}
                      className={`border p-4.5 rounded-2xl relative flex flex-col justify-between h-full transition-all ${
                        deployedRatifierIdxs[idx]
                          ? 'bg-green-950/10 border-green-900/30 opacity-70'
                          : 'bg-black/40 hover:bg-black/60 border-gray-850'
                      }`}
                    >
                      <div className="space-y-3.5 mb-4">
                        <div className="flex items-center justify-between gap-2">
                          <span className={`font-mono text-[8px] uppercase tracking-widest px-2 py-0.5 rounded-full font-bold ${
                            taskObj.category === 'King' ? 'bg-red-500/10 text-red-400 border border-red-500/25' :
                            taskObj.category === 'Queen' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/25' :
                            taskObj.category === 'Rook' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/25' :
                            'bg-green-500/10 text-green-400 border border-green-500/25'
                          }`}>
                            {taskObj.category === 'King' ? 'Critical Focus' :
                             taskObj.category === 'Queen' ? 'High Priority' :
                             taskObj.category === 'Rook' ? 'Medium Priority' :
                             'Low Priority'}
                          </span>

                          <div className="flex items-center gap-2">
                            <span className="font-mono text-[9px] text-[#d4af37] font-bold">
                              Priority Score: {taskObj.priority_score}/10
                            </span>
                            {deployedRatifierIdxs[idx] && (
                              <span className="flex items-center gap-1 font-mono text-[8.5px] uppercase tracking-widest text-green-400 font-extrabold">
                                <Check className="w-3 h-3" /> Added
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="space-y-1">
                          <h5 className="font-sans font-black text-xs text-gray-200 tracking-wide">
                            {taskObj.task}
                          </h5>
                          <p className="text-[10.5px] text-gray-400 font-sans leading-relaxed">
                            {taskObj.rationale}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => deploySingleRatifierTask(idx, taskObj)}
                        disabled={deployedRatifierIdxs[idx]}
                        className={`w-full font-mono text-[9px] uppercase tracking-widest py-2 rounded-xl border flex items-center justify-center gap-1.5 transition-all ${
                          deployedRatifierIdxs[idx]
                            ? 'bg-transparent border-green-900/30 text-green-500/50 cursor-default'
                            : 'bg-gradient-to-r from-amber-950/40 to-black hover:border-[#d4af37]/50 border-gray-800 hover:text-[#d4af37] text-gray-400 cursor-pointer'
                        }`}
                      >
                        {deployedRatifierIdxs[idx] ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>In active list</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5 text-[#d4af37]" />
                            <span>Add priority task</span>
                          </>
                        )}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 3 RESULTS: REVIEW MY PLAN */}
          {activeTab === 'loophole' && loopholeResults && (
            <motion.div
              key="loophole-results"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              {/* Scheduling Risks & Gaps */}
              <div className="bg-[#0f0c0c] border border-red-950/60 p-5 rounded-2xl">
                <h4 className="font-mono text-[10px] text-red-400 uppercase tracking-widest font-black mb-3 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
                  Scheduling Risks & Planning Gaps ({loopholeResults.loopholes_detected.length})
                </h4>

                <div className="divide-y divide-red-950/20 space-y-3.5">
                  {loopholeResults.loopholes_detected.map((lh, idx) => (
                    <div key={idx} className="pt-3 first:pt-0 flex flex-col md:flex-row md:items-start gap-4">
                      <div className="md:w-1/3">
                        <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block font-bold">Identified Risk or Gap</span>
                        <span className="font-mono text-xs text-red-400 font-semibold block">
                          {lh.loophole}
                        </span>
                      </div>
                      <div className="md:w-1/3">
                        <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block font-bold">Potential Problem</span>
                        <span className="text-[10.5px] text-gray-400 font-sans leading-relaxed block">{lh.vulnerability}</span>
                      </div>
                      <div className="md:w-1/3">
                        <span className="text-[9px] font-mono text-[#d4af37] uppercase tracking-wider block font-bold">Impact on Your Day</span>
                        <p className="text-[10.5px] text-gray-300 font-sans leading-relaxed italic">
                          {lh.impact}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommended Action Items & Tips */}
              <div className="space-y-4">
                <h4 className="font-mono text-[10px] text-gray-400 uppercase tracking-widest font-black flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                  Recommended Action Items & Tips
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {loopholeResults.patch_fixes.map((patch, idx) => (
                    <div 
                      key={idx}
                      className="border p-4.5 rounded-2xl bg-black/40 border-gray-850 relative flex flex-col justify-between h-full"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <span className="bg-[#d4af37]/10 text-[#d4af37] border border-[#d4af37]/25 font-mono text-[8px] uppercase tracking-widest px-2.5 py-0.5 rounded-full font-bold">
                            {patch.patch_id}
                          </span>
                          <span className="font-mono text-[8.5px] uppercase tracking-widest text-gray-500 font-extrabold">
                            Category: {patch.target_module}
                          </span>
                        </div>

                        <p className="text-[11px] text-gray-300 font-sans leading-relaxed">
                          {patch.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Daily Planning Principles */}
              <div className="bg-[#0b0c10] border border-[#d4af37]/20 p-5 rounded-2xl relative">
                <div className="absolute top-2 right-4 text-[8px] font-mono text-[#d4af37]/30 uppercase tracking-widest font-black">
                  DAILY PLANNING PRINCIPLES
                </div>
                <div className="space-y-3">
                  <span className="text-[9px] font-mono text-[#d4af37] uppercase tracking-wider block font-bold">
                    🛡️ Protective Planning Habits
                  </span>
                  <ul className="space-y-2">
                    {loopholeResults.enforced_constraints.map((constraint, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-gray-400 font-sans">
                        <span className="text-[#d4af37] mt-0.5 font-bold">▪</span>
                        <span>{constraint}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 4 RESULTS: IMPROVE TASK WORDING */}
          {activeTab === 'language' && languageResults && (
            <motion.div
              key="language-results"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              {/* Assessment and Actionability Score */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {/* Critique Card */}
                <div className="md:col-span-2 bg-[#0c0a0a] border border-gray-900 p-5 rounded-2xl flex flex-col justify-between">
                  <div className="space-y-2">
                    <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block font-bold">
                      Task Wording Audit
                    </span>
                    <p className="text-xs text-gray-300 font-sans leading-relaxed">
                      {languageResults.assessment_of_original_text}
                    </p>
                  </div>
                  <div className="pt-3 border-t border-gray-900/40 mt-3 text-[9.5px] font-mono text-gray-500 uppercase">
                    Status: <span className="text-green-500 font-bold">Simplified & Clear</span>
                  </div>
                </div>

                {/* Score Card */}
                <div className="bg-[#0f0c0c] border border-gray-950 p-5 rounded-2xl flex flex-col items-center justify-center text-center relative overflow-hidden">
                  <div className="absolute -top-10 -right-10 w-24 h-24 bg-[#d4af37]/5 rounded-full blur-xl" />
                  <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider font-bold mb-1">
                    Clarity & Simplicity Rating
                  </span>
                  <div className="text-4xl font-mono font-black text-[#d4af37] tracking-tight">
                    {languageResults.actionability_score}%
                  </div>
                  <div className="w-full bg-gray-900 h-1.5 rounded-full mt-3 overflow-hidden max-w-[120px]">
                    <div 
                      className="bg-gradient-to-r from-amber-600 to-[#d4af37] h-full rounded-full" 
                      style={{ width: `${languageResults.actionability_score}%` }}
                    />
                  </div>
                  <span className="text-[8px] font-mono text-gray-400 uppercase tracking-widest mt-2">
                    Easy to Execute
                  </span>
                </div>
              </div>

              {/* Phrase Transformations */}
              <div className="bg-[#0a0808] border border-gray-900 rounded-2xl p-5 space-y-4">
                <h4 className="font-mono text-[10px] text-gray-400 uppercase tracking-widest font-black flex items-center gap-1.5">
                  <Languages className="w-3.5 h-3.5 text-[#d4af37]" />
                  Simplified Task Descriptions ({languageResults.original_sentences.length})
                </h4>

                <div className="divide-y divide-gray-900 space-y-4">
                  {languageResults.original_sentences.map((item, idx) => (
                    <div key={idx} className="pt-4 first:pt-0 space-y-2.5">
                      <div className="flex items-center justify-between gap-3 flex-wrap">
                        <span className="bg-red-950/20 text-red-400 border border-red-950/60 font-mono text-[8px] uppercase tracking-widest px-2.5 py-0.5 rounded-full font-bold">
                          {item.rule_violated}
                        </span>
                        <span className="text-[9px] font-mono text-gray-500">
                          IMPROVEMENT #{idx + 1}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Original sentence */}
                        <div className="bg-red-950/5 border border-red-950/20 rounded-xl p-3.5 space-y-1">
                          <span className="text-[8px] font-mono text-red-500 uppercase font-black tracking-wider block">
                            Original Wording
                          </span>
                          <p className="text-[11px] text-gray-400 font-sans leading-relaxed italic">
                            "{item.original}"
                          </p>
                        </div>

                        {/* Humanized sentence */}
                        <div className="bg-emerald-950/5 border border-emerald-950/20 rounded-xl p-3.5 space-y-1">
                          <span className="text-[8px] font-mono text-emerald-400 uppercase font-black tracking-wider block">
                            Action-First Rewrite
                          </span>
                          <p className="text-xs text-gray-200 font-sans leading-relaxed font-medium">
                            "{item.humanized}"
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Clarified Summary Card */}
              <div className="bg-gradient-to-br from-[#121110] to-[#0a0808] border border-[#d4af37]/25 p-5 rounded-2xl relative">
                <div className="absolute top-2 right-4 text-[8px] font-mono text-[#d4af37]/30 uppercase tracking-widest font-black">
                  SIMPLIFIED SUMMARY
                </div>
                <div className="space-y-2">
                  <span className="text-[9px] font-mono text-[#d4af37] uppercase tracking-wider block font-bold">
                    📝 Unified Task List
                  </span>
                  <p className="text-[12.5px] text-gray-200 font-sans leading-relaxed font-semibold">
                    {languageResults.clarified_summary}
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </motion.div>
  );
};
