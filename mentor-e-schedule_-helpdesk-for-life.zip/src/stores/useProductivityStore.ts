import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

// Define the exact Task Schema requested
export interface StoreTask {
  id: string;
  title: string;
  description?: string;
  priority: 'KING' | 'QUEEN' | 'ROOK' | 'PAWN';
  dueDate?: string;     // YYYY-MM-DD
  startTime?: string;   // HH:MM
  durationMinutes?: number;
  completed: boolean;
  createdAt: string;    // ISO timestamp

  // Chess metadata for seamless compatibility with Board components
  rank?: 'King' | 'Queen' | 'Rook' | 'Pawn';
  pieceName?: string;
  insight?: string;
  categoryExplanation?: string;
  primaryGoal?: string;
  masteryInsight?: string;
  excellenceChallenge?: string;
  analyzing?: boolean;
  isProposed?: boolean;
  proposedRank?: 'King' | 'Queen' | 'Rook' | 'Pawn';
  followUpQuestion?: string;
}

export interface UserProfile {
  name: string;
  email: string;
  role: string;
  purpose: string;
  primaryGoal: string;
  eloScore: number; // Internal momentum/focus score
  level: string;    // Internal performance tier
  onboarded: boolean;
  age?: string;
}

export interface CoachMemorySettings {
  rememberGoals: boolean;
  rememberProjects: boolean;
  rememberDiscussions: boolean;
  rememberStyle: boolean;
}

export interface ProductivityAnalytics {
  tasksCompletedCount: number;
  completionRate: number;
  totalFocusMinutes: number;
  eloHistory: { date: string; elo: number }[];
  streakDays: number;
}

export interface Deadline {
  id: string;
  taskId: string;
  title: string;
  dueDate: string;
  priority: 'KING' | 'QUEEN' | 'ROOK' | 'PAWN';
}

export interface ReflectionRecord {
  id: string;
  taskId?: string;
  taskTitle: string;
  blocker: 'Lack of Time' | 'Low Energy' | 'Missing Information' | 'Priority Changed' | 'Unexpected Event';
  recoveryInsight: string;
  recommendedNextStep: string;
  suggestedAction: string;
  createdAt: string; // ISO String
}

export interface StoreHabit {
  id: string;
  title: string;
  streakDays: number;
  history: string[]; // array of ISO date strings (YYYY-MM-DD) when completed
  createdAt: string;
}

export interface StoreReminder {
  id: string;
  taskId: string;
  taskTitle: string;
  triggerTime: string; // HH:MM
  notified: boolean;
  createdAt: string;
}

// Full State and Actions representation
export interface CurrentUser {
  email: string;
  name: string;
  profilePicture?: string;
  onboarded: boolean;
}

export interface ProductivityState {
  currentUser: CurrentUser | null;
  tasks: StoreTask[];
  completedTasks: StoreTask[];
  userProfile: UserProfile;
  coachMemorySettings: CoachMemorySettings;
  analytics: ProductivityAnalytics;
  deadlines: Deadline[];
  reflections?: ReflectionRecord[];
  habits: StoreHabit[];
  reminders: StoreReminder[];

  isSyncing?: boolean;
  lastSyncedAt?: string | null;
  autoSyncEnabled?: boolean;
  toggleAutoSync?: () => void;
  authInitialized?: boolean;
  setAuthInitialized?: (initialized: boolean) => void;

  // Actions
  setCurrentUser: (
    user: CurrentUser | null, 
    profile: Partial<UserProfile> | null, 
    workspace: any | null
  ) => void;
  logout: () => void;
  syncWorkspace: () => Promise<void>;
  addTask: (task: Omit<StoreTask, 'id' | 'completed' | 'createdAt'>) => void;
  updateTask: (id: string, updates: Partial<StoreTask>) => void;
  deleteTask: (id: string) => void;
  completeTask: (id: string) => void;
  deferTask: (id: string, daysToDefer?: number) => void;
  getTodaysTasks: () => StoreTask[];
  getUpcomingDeadlines: () => Deadline[];
  updateUserProfile: (profile: Partial<UserProfile>) => void;
  updateCoachMemorySettings: (settings: Partial<CoachMemorySettings>) => void;
  resetStore: () => void;
  addReflection: (reflection: Omit<ReflectionRecord, 'id' | 'createdAt'>) => void;
  deleteReflection: (id: string) => void;

  // Habit Actions
  addHabit: (title: string) => void;
  toggleHabit: (id: string, date: string) => void;
  deleteHabit: (id: string) => void;

  // Reminder Actions
  addReminder: (taskId: string, taskTitle: string, triggerTime: string) => void;
  deleteReminder: (id: string) => void;
  markReminderNotified: (id: string) => void;
}

// Initial state constants
const initialUserProfile: UserProfile = {
  name: "New Professional",
  email: "",
  role: "",
  purpose: "",
  primaryGoal: "",
  eloScore: 100,
  level: "Professional Tier",
  onboarded: false,
  age: ""
};

const initialCoachMemorySettings: CoachMemorySettings = {
  rememberGoals: true,
  rememberProjects: true,
  rememberDiscussions: true,
  rememberStyle: true
};

const initialAnalytics: ProductivityAnalytics = {
  tasksCompletedCount: 0,
  completionRate: 0,
  totalFocusMinutes: 0,
  eloHistory: [{ date: new Date().toISOString().split('T')[0], elo: 100 }],
  streakDays: 0
};

// Custom safe storage that handles exceptions and corruption gracefully
const safeLocalStorage = {
  getItem: (key: string): string | null => {
    try {
      return localStorage.getItem(key);
    } catch (error) {
      console.error("Zustand Persistence: Safe localStorage failed to read.", error);
      return null;
    }
  },
  setItem: (key: string, value: string): void => {
    try {
      localStorage.setItem(key, value);
    } catch (error) {
      console.error("Zustand Persistence: Safe localStorage failed to write.", error);
    }
  },
  removeItem: (key: string): void => {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error("Zustand Persistence: Safe localStorage failed to remove.", error);
    }
  }
};

export const useProductivityStore = create<ProductivityState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      tasks: [],
      completedTasks: [],
      userProfile: initialUserProfile,
      coachMemorySettings: initialCoachMemorySettings,
      analytics: initialAnalytics,
      deadlines: [],
      reflections: [],
      habits: [],
      reminders: [],

      isSyncing: false,
      lastSyncedAt: null,
      autoSyncEnabled: true,
      toggleAutoSync: () => {
        set((state) => ({ autoSyncEnabled: !state.autoSyncEnabled }));
      },
      authInitialized: false,
      setAuthInitialized: (initialized) => {
        set({ authInitialized: initialized });
      },

      setCurrentUser: (user, profile, workspace) => {
        set((state) => {
          const nextState: any = { currentUser: user };
          if (profile) {
            nextState.userProfile = {
              ...state.userProfile,
              ...profile
            };
          }
          if (workspace) {
            nextState.tasks = workspace.tasks || [];
            nextState.completedTasks = workspace.completedTasks || [];
            nextState.habits = workspace.habits || [];
            nextState.reminders = workspace.reminders || [];
            nextState.deadlines = workspace.deadlines || [];
            nextState.reflections = workspace.reflections || [];
            nextState.analytics = workspace.analytics || state.analytics;
          }
          return nextState;
        });
      },

      logout: () => {
        set({
          currentUser: null,
          tasks: [],
          completedTasks: [],
          userProfile: initialUserProfile,
          coachMemorySettings: initialCoachMemorySettings,
          analytics: initialAnalytics,
          deadlines: [],
          reflections: [],
          habits: [],
          reminders: []
        });
      },

      syncWorkspace: async () => {
        const { currentUser, tasks, completedTasks, habits, reminders, deadlines, reflections, analytics, userProfile } = get();
        if (!currentUser) return;

        set({ isSyncing: true });
        try {
          await fetch('/api/user/save-workspace', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email: currentUser.email,
              workspace: {
                tasks,
                completedTasks,
                habits,
                reminders,
                deadlines,
                reflections,
                analytics
              },
              userProfile
            })
          });
          set({ isSyncing: false, lastSyncedAt: new Date().toLocaleTimeString() });
        } catch (error) {
          console.error("Workspace sync failed", error);
          set({ isSyncing: false });
        }
      },

      // Add a task
      addTask: (taskData) => {
        const id = `task-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
        
        // Map priority to standard chess metadata for backward-compatibility
        const rankMap: Record<'KING' | 'QUEEN' | 'ROOK' | 'PAWN', 'King' | 'Queen' | 'Rook' | 'Pawn'> = {
          'KING': 'King',
          'QUEEN': 'Queen',
          'ROOK': 'Rook',
          'PAWN': 'Pawn'
        };
        const pieceNameMap: Record<'KING' | 'QUEEN' | 'ROOK' | 'PAWN', string> = {
          'KING': 'King (Critical Priority)',
          'QUEEN': 'Queen (High Impact)',
          'ROOK': 'Rook (Tactical Operations)',
          'PAWN': 'Pawn (Foundational Growth)'
        };

        const newTask: StoreTask = {
          ...taskData,
          id,
          completed: false,
          createdAt: new Date().toISOString(),
          rank: rankMap[taskData.priority],
          pieceName: pieceNameMap[taskData.priority]
        };

        set((state) => {
          const updatedTasks = [newTask, ...state.tasks];
          const updatedDeadlines = [...state.deadlines];

          if (newTask.dueDate) {
            updatedDeadlines.push({
              id: `deadline-${id}`,
              taskId: id,
              title: newTask.title,
              dueDate: newTask.dueDate,
              priority: newTask.priority
            });
          }

          return {
            tasks: updatedTasks,
            deadlines: updatedDeadlines
          };
        });
      },

      // Update a task
      updateTask: (id, updates) => {
        set((state) => {
          // Check active tasks
          const activeIndex = state.tasks.findIndex(t => t.id === id);
          let updatedTasks = [...state.tasks];
          let updatedCompletedTasks = [...state.completedTasks];

          if (activeIndex > -1) {
            updatedTasks[activeIndex] = { ...updatedTasks[activeIndex], ...updates };
          } else {
            // Check completed tasks
            const completedIndex = state.completedTasks.findIndex(t => t.id === id);
            if (completedIndex > -1) {
              updatedCompletedTasks[completedIndex] = { ...updatedCompletedTasks[completedIndex], ...updates };
            }
          }

          // Update deadlines list
          let updatedDeadlines = state.deadlines.map(d => {
            if (d.taskId === id) {
              return {
                ...d,
                title: updates.title !== undefined ? updates.title : d.title,
                dueDate: updates.dueDate !== undefined ? (updates.dueDate || '') : d.dueDate,
                priority: updates.priority !== undefined ? updates.priority : d.priority
              };
            }
            return d;
          });

          // If a task added a due date, or removed a due date
          const targetTask = updatedTasks.find(t => t.id === id) || updatedCompletedTasks.find(t => t.id === id);
          if (targetTask) {
            const hasDeadline = updatedDeadlines.some(d => d.taskId === id);
            if (targetTask.dueDate && !hasDeadline) {
              updatedDeadlines.push({
                id: `deadline-${id}`,
                taskId: id,
                title: targetTask.title,
                dueDate: targetTask.dueDate,
                priority: targetTask.priority
              });
            } else if (!targetTask.dueDate && hasDeadline) {
              updatedDeadlines = updatedDeadlines.filter(d => d.taskId !== id);
            }
          }

          return {
            tasks: updatedTasks,
            completedTasks: updatedCompletedTasks,
            deadlines: updatedDeadlines
          };
        });
      },

      // Delete a task
      deleteTask: (id) => {
        set((state) => ({
          tasks: state.tasks.filter(t => t.id !== id),
          completedTasks: state.completedTasks.filter(t => t.id !== id),
          deadlines: state.deadlines.filter(d => d.taskId !== id)
        }));
      },

      // Complete a task with focus score system integration
      completeTask: (id) => {
        const state = get();
        const targetTask = state.tasks.find(t => t.id === id);
        if (!targetTask) return;

        const completedAtTimestamp = new Date().toISOString();
        const completedTask: StoreTask = {
          ...targetTask,
          completed: true
        };

        // Determine score reward based on priority level of the task
        let scoreReward = 5; // Default Low Priority reward
        if (targetTask.priority === 'KING') scoreReward = 15;
        else if (targetTask.priority === 'QUEEN') scoreReward = 10;
        else if (targetTask.priority === 'ROOK') scoreReward = 8;

        const newScore = state.userProfile.eloScore + scoreReward;
        
        let newLevel = state.userProfile.level;
        if (newScore >= 300) newLevel = "Elite Executive";
        else if (newScore >= 250) newLevel = "Senior Advisor";
        else if (newScore >= 180) newLevel = "Strategy Lead";
        else if (newScore >= 120) newLevel = "High Performer";
        else newLevel = "Professional Tier";

        const todayStr = completedAtTimestamp.split('T')[0];
        
        set((state) => {
          const updatedTasks = state.tasks.filter(t => t.id !== id);
          const updatedCompleted = [completedTask, ...state.completedTasks];
          
          const totalCompleted = updatedCompleted.length;
          const totalActive = updatedTasks.length;
          const totalCount = totalCompleted + totalActive;
          const rate = totalCount > 0 ? Math.round((totalCompleted / totalCount) * 100) : 100;
          
          const focusMinutesAdded = targetTask.durationMinutes || 0;

          // Update Score history
          let updatedEloHistory = [...state.analytics.eloHistory];
          const hasTodayIndex = updatedEloHistory.findIndex(h => h.date === todayStr);
          if (hasTodayIndex > -1) {
            updatedEloHistory[hasTodayIndex].elo = newScore;
          } else {
            updatedEloHistory.push({ date: todayStr, elo: newScore });
          }

          const updatedAnalytics: ProductivityAnalytics = {
            ...state.analytics,
            tasksCompletedCount: totalCompleted,
            completionRate: rate,
            totalFocusMinutes: state.analytics.totalFocusMinutes + focusMinutesAdded,
            eloHistory: updatedEloHistory
          };

          return {
            tasks: updatedTasks,
            completedTasks: updatedCompleted,
            userProfile: {
              ...state.userProfile,
              eloScore: newScore,
              level: newLevel
            },
            analytics: updatedAnalytics,
            deadlines: state.deadlines.filter(d => d.taskId !== id) // Remove completed deadlines
          };
        });
      },

      // Defer a task with practical guidance
      deferTask: (id, daysToDefer = 1) => {
        const state = get();
        const targetTask = state.tasks.find(t => t.id === id);
        if (!targetTask) return;

        // Push dueDate out
        let updatedDueDate = targetTask.dueDate;
        if (targetTask.dueDate) {
          try {
            const currentDate = new Date(targetTask.dueDate);
            currentDate.setDate(currentDate.getDate() + daysToDefer);
            updatedDueDate = currentDate.toISOString().split('T')[0];
          } catch (e) {
            console.warn("Could not calculate deferred date:", e);
          }
        } else {
          // If no dueDate, assign tomorrow
          const tomorrow = new Date();
          tomorrow.setDate(tomorrow.getDate() + daysToDefer);
          updatedDueDate = tomorrow.toISOString().split('T')[0];
        }

        // Deferral has a slight score adjustment to reflect momentum shift (-2 focus score)
        const newScore = Math.max(0, state.userProfile.eloScore - 2);

        set((state) => {
          const updatedTasks = state.tasks.map(t => {
            if (t.id === id) {
              return {
                ...t,
                dueDate: updatedDueDate
              };
            }
            return t;
          });

          const updatedDeadlines = state.deadlines.map(d => {
            if (d.taskId === id) {
              return {
                ...d,
                dueDate: updatedDueDate || ''
              };
            }
            return d;
          });

          return {
            tasks: updatedTasks,
            deadlines: updatedDeadlines,
            userProfile: {
              ...state.userProfile,
              eloScore: newScore
            }
          };
        });
      },

      // Fetch today's tasks
      getTodaysTasks: () => {
        const todayStr = new Date().toISOString().split('T')[0];
        return get().tasks.filter(t => t.dueDate === todayStr || !t.dueDate);
      },

      // Fetch upcoming deadlines sorted chronologically
      getUpcomingDeadlines: () => {
        return [...get().deadlines].sort((a, b) => a.dueDate.localeCompare(b.dueDate));
      },

      // Update User Profile
      updateUserProfile: (profileUpdates) => {
        set((state) => ({
          userProfile: {
            ...state.userProfile,
            ...profileUpdates
          }
        }));
      },

      // Update Coach Memory settings
      updateCoachMemorySettings: (settingsUpdates) => {
        set((state) => ({
          coachMemorySettings: {
            ...state.coachMemorySettings,
            ...settingsUpdates
          }
        }));
      },

      // Total factory reset option for state recovery
      resetStore: () => {
        set({
          tasks: [],
          completedTasks: [],
          userProfile: initialUserProfile,
          coachMemorySettings: initialCoachMemorySettings,
          analytics: initialAnalytics,
          deadlines: [],
          reflections: [],
          habits: [],
          reminders: []
        });
      },

      // Add reflection
      addReflection: (reflectionData) => {
        const id = `reflection-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
        set((state) => ({
          reflections: [
            {
              ...reflectionData,
              id,
              createdAt: new Date().toISOString()
            },
            ...(state.reflections || [])
          ]
        }));
      },

      // Delete reflection
      deleteReflection: (id) => {
        set((state) => ({
          reflections: (state.reflections || []).filter(r => r.id !== id)
        }));
      },

      // Habit Actions
      addHabit: (title) => {
        const id = `habit-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
        set((state) => ({
          habits: [
            ...(state.habits || []),
            {
              id,
              title,
              streakDays: 0,
              history: [],
              createdAt: new Date().toISOString()
            }
          ]
        }));
      },

      toggleHabit: (id, date) => {
        set((state) => {
          const updatedHabits = (state.habits || []).map((h) => {
            if (h.id !== id) return h;
            const history = h.history || [];
            const isCompleted = history.includes(date);
            let nextHistory = [];
            if (isCompleted) {
              nextHistory = history.filter(d => d !== date);
            } else {
              nextHistory = [...history, date];
            }
            
            // Calculate streak based on consecutive days
            let streak = 0;
            const sortedDates = [...nextHistory].sort((a, b) => b.localeCompare(a));
            if (sortedDates.length > 0) {
              const today = new Date().toISOString().split('T')[0];
              const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
              
              // If completed today or yesterday, check streak backwards
              if (sortedDates[0] === today || sortedDates[0] === yesterday) {
                streak = 1;
                let currentCheck = new Date(sortedDates[0]);
                for (let i = 1; i < sortedDates.length; i++) {
                  const prevDay = new Date(currentCheck.getTime() - 86400000).toISOString().split('T')[0];
                  if (sortedDates[i] === prevDay) {
                    streak++;
                    currentCheck = new Date(prevDay);
                  } else {
                    break;
                  }
                }
              }
            }

            return {
              ...h,
              history: nextHistory,
              streakDays: streak
            };
          });

          // Reward +3 ELO on completing a habit
          const oldHabit = (state.habits || []).find(h => h.id === id);
          const wasCompleted = oldHabit?.history.includes(date);
          const eloDelta = wasCompleted ? -3 : 3;
          const newElo = Math.max(0, state.userProfile.eloScore + eloDelta);

          return {
            habits: updatedHabits,
            userProfile: {
              ...state.userProfile,
              eloScore: newElo
            }
          };
        });
      },

      deleteHabit: (id) => {
        set((state) => ({
          habits: (state.habits || []).filter(h => h.id !== id)
        }));
      },

      // Reminder Actions
      addReminder: (taskId, taskTitle, triggerTime) => {
        const id = `reminder-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
        set((state) => ({
          reminders: [
            ...(state.reminders || []),
            {
              id,
              taskId,
              taskTitle,
              triggerTime,
              notified: false,
              createdAt: new Date().toISOString()
            }
          ]
        }));
      },

      deleteReminder: (id) => {
        set((state) => ({
          reminders: (state.reminders || []).filter(r => r.id !== id)
        }));
      },

      markReminderNotified: (id) => {
        set((state) => ({
          reminders: (state.reminders || []).map(r => r.id === id ? { ...r, notified: true } : r)
        }));
      }
    }),
    {
      name: 'mentor-e-schedule-productivity-store',
      storage: createJSONStorage(() => safeLocalStorage),
      // Validate the state on hydration to recover gracefully from state mutations or corruptions
      onRehydrateStorage: (state) => {
        return (hydratedState, error) => {
          if (error) {
            console.error("Hydration error occurred, applying fallback correction:", error);
          }
          if (hydratedState) {
            // Guarantee arrays are present
            if (!Array.isArray(hydratedState.tasks)) hydratedState.tasks = [];
            if (!Array.isArray(hydratedState.completedTasks)) hydratedState.completedTasks = [];
            if (!Array.isArray(hydratedState.deadlines)) hydratedState.deadlines = [];
            if (!Array.isArray(hydratedState.reflections)) hydratedState.reflections = [];
            if (!Array.isArray(hydratedState.habits)) hydratedState.habits = [];
            if (!Array.isArray(hydratedState.reminders)) hydratedState.reminders = [];
            
            // Validate userProfile
            if (!hydratedState.userProfile || typeof hydratedState.userProfile.eloScore !== 'number') {
              hydratedState.userProfile = initialUserProfile;
            }

            // Validate coachMemorySettings
            if (!hydratedState.coachMemorySettings) {
              hydratedState.coachMemorySettings = initialCoachMemorySettings;
            }

            // Validate analytics
            if (!hydratedState.analytics) {
              hydratedState.analytics = initialAnalytics;
            }
          }
        };
      }
    }
  )
);
