// Under the hood, these values map directly to:
// 'King' -> Critical Priority
// 'Queen' -> High Priority
// 'Rook' -> Medium Priority
// 'Pawn' -> Low Priority
export type ChessRank = 'King' | 'Queen' | 'Rook' | 'Pawn';

export interface Task {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  rank?: ChessRank;
  pieceName?: string;
  insight?: string;
  categoryExplanation?: string;
  primaryGoal?: string;
  masteryInsight?: string;
  excellenceChallenge?: string;
  createdAt?: number;
  analyzing?: boolean;
  row?: number;
  col?: number;
  isFading?: boolean;
  isProposed?: boolean;
  proposedRank?: ChessRank;
  followUpQuestion?: string;
}

