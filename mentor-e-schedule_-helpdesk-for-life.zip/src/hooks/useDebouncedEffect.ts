import { useEffect, useRef, DependencyList } from 'react';

/**
 * A custom hook that runs an effect only after a specified delay has elapsed
 * since the last time any dependency in the dependency list changed.
 * This is perfect for reducing disk I/O during rapid state updates.
 */
export function useDebouncedEffect(
  effect: () => void,
  delay: number,
  deps: DependencyList
): void {
  const callback = useRef(effect);

  // Keep callback reference updated with latest closure values
  useEffect(() => {
    callback.current = effect;
  }, [effect]);

  useEffect(() => {
    const handler = setTimeout(() => {
      callback.current();
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [...deps, delay]);
}
