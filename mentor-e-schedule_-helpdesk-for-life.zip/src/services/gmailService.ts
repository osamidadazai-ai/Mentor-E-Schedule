import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { auth } from '../lib/firebase';

// Keep the token strictly in-memory for security compliance
let cachedToken: string | null = null;

export interface GmailEmail {
  id: string;
  threadId: string;
  from: string;
  subject: string;
  snippet: string;
  date: string;
  body: string;
}

export interface EmailAnalysis {
  category: 'King' | 'Queen' | 'Rook' | 'Pawn';
  pieceName: string;
  summary: string;
  actionPoints: string[];
  proposedReply: string;
  rationale: string;
}

/**
 * Connect to Gmail by opening a Google OAuth popup requesting Gmail scopes
 */
export const connectGmail = async (): Promise<string> => {
  try {
    const provider = new GoogleAuthProvider();
    
    // Add specific Gmail scopes
    provider.addScope('https://www.googleapis.com/auth/gmail.readonly');
    provider.addScope('https://www.googleapis.com/auth/gmail.modify');
    provider.addScope('https://www.googleapis.com/auth/gmail.send');
    
    provider.setCustomParameters({ 
      prompt: 'select_account',
      access_type: 'offline'
    });

    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const token = credential?.accessToken;

    if (!token) {
      throw new Error('Failed to retrieve Google OAuth access token from authentication result.');
    }

    cachedToken = token;
    return token;
  } catch (error: any) {
    console.error('Gmail OAuth Connection Error:', error);
    throw error;
  }
};

/**
 * Check if the user is connected to Gmail in this session
 */
export const isGmailConnected = (): boolean => {
  return cachedToken !== null;
};

/**
 * Disconnect/wipe Gmail token from memory
 */
export const disconnectGmail = (): void => {
  cachedToken = null;
};

/**
 * Retrieve the current access token
 */
export const getGmailToken = (): string | null => {
  return cachedToken;
};

/**
 * Utility: Decode Base64 encoded bodies from Gmail API
 */
const decodeBase64Url = (data: string): string => {
  if (!data) return '';
  const base64 = data.replace(/-/g, '+').replace(/_/g, '/');
  try {
    return decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
  } catch (e) {
    try {
      return atob(base64);
    } catch {
      return '';
    }
  }
};

/**
 * Recursively parse parts to extract text/plain or text/html body content
 */
const extractBody = (payload: any): string => {
  if (!payload) return '';
  
  if (payload.body?.data) {
    return decodeBase64Url(payload.body.data);
  }

  if (payload.parts) {
    // Look for text/plain first, then text/html
    const plainPart = payload.parts.find((p: any) => p.mimeType === 'text/plain');
    if (plainPart && plainPart.body?.data) {
      return decodeBase64Url(plainPart.body.data);
    }

    const htmlPart = payload.parts.find((p: any) => p.mimeType === 'text/html');
    if (htmlPart && htmlPart.body?.data) {
      // Return HTML or stripped content
      return decodeBase64Url(htmlPart.body.data);
    }

    // Recurse on remaining parts
    for (const part of payload.parts) {
      const parsed = extractBody(part);
      if (parsed) return parsed;
    }
  }

  return '';
};

/**
 * Extract specific header value
 */
const getHeaderValue = (headers: { name: string; value: string }[], name: string): string => {
  if (!headers) return '';
  return headers.find((h) => h.name.toLowerCase() === name.toLowerCase())?.value || '';
};

/**
 * List the latest emails from the connected inbox
 */
export const fetchLatestEmails = async (maxResults: number = 10): Promise<GmailEmail[]> => {
  const token = getGmailToken();
  if (!token) {
    throw new Error('Gmail integration is not authorized. Please connect your Gmail account.');
  }

  try {
    // Step 1: List message IDs
    const listRes = await fetch(
      `https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=${maxResults}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/json',
        },
      }
    );

    if (!listRes.ok) {
      if (listRes.status === 401) {
        disconnectGmail(); // token expired
      }
      throw new Error(`Gmail API listed failed: ${listRes.statusText}`);
    }

    const listData = await listRes.json();
    const messages = listData.messages || [];

    if (messages.length === 0) {
      return [];
    }

    // Step 2: Fetch message details in parallel (max 10 to keep it highly performant)
    const emailPromises = messages.map(async (msg: { id: string }) => {
      const detailRes = await fetch(
        `https://gmail.googleapis.com/gmail/v1/users/me/messages/${msg.id}?format=full`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: 'application/json',
          },
        }
      );

      if (!detailRes.ok) {
        return null;
      }

      const detail = await detailRes.json();
      const headers = detail.payload?.headers || [];
      const from = getHeaderValue(headers, 'From');
      const subject = getHeaderValue(headers, 'Subject') || '(No Subject)';
      const date = getHeaderValue(headers, 'Date');
      const body = extractBody(detail.payload);

      return {
        id: detail.id,
        threadId: detail.threadId,
        from,
        subject,
        snippet: detail.snippet || '',
        date,
        body: body || detail.snippet || '',
      } as GmailEmail;
    });

    const results = await Promise.all(emailPromises);
    return results.filter((email): email is GmailEmail => email !== null);
  } catch (error: any) {
    console.error('Fetch Emails Error:', error);
    throw error;
  }
};

/**
 * Analyze an email strategically using the server-side Performance Mentor
 */
export const analyzeEmailWithMentor = async (
  email: GmailEmail,
  userEmail: string
): Promise<EmailAnalysis> => {
  try {
    const res = await fetch('/api/coach/analyze-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        subject: email.subject,
        from: email.from,
        body: email.body || email.snippet,
        email: userEmail,
      }),
    });

    if (!res.ok) {
      const errData = await res.json();
      throw new Error(errData.error || 'Failed to analyze email strategically.');
    }

    return await res.json() as EmailAnalysis;
  } catch (error: any) {
    console.error('Email analysis failed:', error);
    throw error;
  }
};

/**
 * Send an email reply. Mime message generated client-side.
 * REQUIRES EXPLICIT USER CONFIRMATION (Handled in React Component).
 */
export const sendGmailReply = async (
  toEmail: string,
  subject: string,
  replyBody: string,
  threadId?: string,
  originalMessageId?: string
): Promise<boolean> => {
  const token = getGmailToken();
  if (!token) {
    throw new Error('Gmail integration is not authorized. Please connect your Gmail account.');
  }

  try {
    // Construct clean headers
    const headers: string[] = [];
    headers.push(`To: ${toEmail}`);
    headers.push(`Subject: ${subject.startsWith('Re:') ? subject : 'Re: ' + subject}`);
    
    if (originalMessageId) {
      headers.push(`In-Reply-To: ${originalMessageId}`);
      headers.push(`References: ${originalMessageId}`);
    }
    
    headers.push('Content-Type: text/plain; charset=utf-8');
    headers.push('MIME-Version: 1.0');
    headers.push('');
    headers.push(replyBody);

    const emailContent = headers.join('\r\n');
    
    // Base64url encode compliance
    const encodedEmail = btoa(unescape(encodeURIComponent(emailContent)))
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');

    const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        raw: encodedEmail,
        threadId: threadId,
      }),
    });

    if (!res.ok) {
      const errData = await res.json();
      throw new Error(errData.error?.message || `Failed to send reply: ${res.statusText}`);
    }

    return true;
  } catch (error: any) {
    console.error('Send Reply Error:', error);
    throw error;
  }
};
