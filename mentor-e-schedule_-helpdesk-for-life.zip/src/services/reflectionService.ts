import { db, auth } from '../lib/firebase';
import { doc, getDoc, setDoc, collection, getDocs, query, orderBy, limit, where } from 'firebase/firestore';

export interface DailyLog {
  date: string; // YYYY-MM-DD
  completedTasks: { id: string; title: string; priority: string }[];
  pendingTasks: { id: string; title: string; priority: string }[];
  missedTasks: { id: string; title: string; priority: string }[];
  completionPercentage: number;
  studyTime: number; // focus minutes
  createdPlans: number;
  deadlines: { id: string; title: string; priority: string }[];
  mood?: string;
  energyLevel?: number; // 1-10
  oneLineReflection: string;
  aiReflection: string;
  aiRecommendation: string;
  timestamp: string;
  lastUpdated: string;
}

export interface WeeklyReport {
  weekId: string; // YYYY-Www
  tasksCompleted: number;
  completionRate: number;
  mostProductiveDay: string;
  leastProductiveDay: string;
  bestSubject: string;
  weakestSubject: string;
  averageProductivity: number;
  studyConsistency: number;
  weeklyAiInsights: string;
  recommendations: string;
  createdAt: string;
}

export interface MonthlyReport {
  monthId: string; // YYYY-MM
  hoursInvested: number;
  tasksCompleted: number;
  streaks: number;
  goalCompletion: number;
  activeCategories: Record<string, number>;
  personalGrowth: string;
  biggestImprovements: string;
  recurringBottlenecks: string;
  aiRecommendations: string;
  createdAt: string;
}

export interface UserStreaks {
  currentStreak: number;
  longestStreak: number;
  consecutiveProductiveDays: number;
  consecutivePlannerUsage: number;
  consecutiveAiMentorUsage: number;
  lastActiveDate?: string; // YYYY-MM-DD
}

class ReflectionService {
  private getUserId(): string | null {
    return auth.currentUser?.uid || null;
  }

  private getFallbackStorageKey(type: string): string {
    const userEmail = auth.currentUser?.email || 'anonymous';
    return `mentoreschedule_${userEmail}_${type}`;
  }

  // Helper to load/save offline fallback state
  private getLocalData<T>(key: string): T[] {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  private saveLocalData<T>(key: string, data: T[]) {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (err) {
      console.error('Error saving local data fallback:', err);
    }
  }

  /**
   * Fetch a specific Daily Log by date (YYYY-MM-DD)
   */
  async getDailyLog(date: string): Promise<DailyLog | null> {
    const uid = this.getUserId();
    if (uid) {
      try {
        const logRef = doc(db, 'users', uid, 'dailyLogs', date);
        const logSnap = await getDoc(logRef);
        if (logSnap.exists()) {
          return logSnap.data() as DailyLog;
        }
      } catch (err) {
        console.error('Firestore getDailyLog error, fallback to local:', err);
      }
    }

    // Local Storage fallback
    const localLogs = this.getLocalData<DailyLog>(this.getFallbackStorageKey('dailyLogs'));
    return localLogs.find(l => l.date === date) || null;
  }

  /**
   * Save or Update Daily Log
   */
  async saveDailyLog(log: DailyLog): Promise<void> {
    const uid = this.getUserId();
    if (uid) {
      try {
        const logRef = doc(db, 'users', uid, 'dailyLogs', log.date);
        await setDoc(logRef, log, { merge: true });
      } catch (err) {
        console.error('Firestore saveDailyLog error, saving to local fallback:', err);
      }
    }

    // Always update local storage for offline resiliency
    const key = this.getFallbackStorageKey('dailyLogs');
    const localLogs = this.getLocalData<DailyLog>(key);
    const existingIdx = localLogs.findIndex(l => l.date === log.date);
    if (existingIdx > -1) {
      localLogs[existingIdx] = { ...localLogs[existingIdx], ...log };
    } else {
      localLogs.push(log);
    }
    this.saveLocalData(key, localLogs);

    // Automatically trigger streaks update
    await this.updateStreaks(log.date);
  }

  /**
   * Get all Daily Logs for historical view
   */
  async getDailyLogsHistory(): Promise<DailyLog[]> {
    const uid = this.getUserId();
    if (uid) {
      try {
        const logsCol = collection(db, 'users', uid, 'dailyLogs');
        const q = query(logsCol, orderBy('date', 'desc'));
        const querySnap = await getDocs(q);
        const logs: DailyLog[] = [];
        querySnap.forEach((docSnap) => {
          logs.push(docSnap.data() as DailyLog);
        });
        if (logs.length > 0) {
          // Sync to local
          this.saveLocalData(this.getFallbackStorageKey('dailyLogs'), logs);
          return logs;
        }
      } catch (err) {
        console.error('Firestore getDailyLogsHistory error, fallback to local:', err);
      }
    }

    const localLogs = this.getLocalData<DailyLog>(this.getFallbackStorageKey('dailyLogs'));
    return localLogs.sort((a, b) => b.date.localeCompare(a.date));
  }

  /**
   * Generate AI summary & recommendations for a Daily Log via server proxy
   */
  async generateDailyAISummary(logData: Partial<DailyLog>, userProfile: any): Promise<{ aiReflection: string; aiRecommendation: string }> {
    try {
      const response = await fetch('/api/coach/generate-daily-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: logData.date,
          completedTasks: logData.completedTasks,
          pendingTasks: logData.pendingTasks,
          missedTasks: logData.missedTasks,
          oneLineReflection: logData.oneLineReflection,
          mood: logData.mood,
          energyLevel: logData.energyLevel,
          userProfile
        })
      });
      if (response.ok) {
        return await response.json();
      }
    } catch (err) {
      console.error('Failed to generate AI summary via backend:', err);
    }
    return {
      aiReflection: "You maintain a solid baseline of tactical discipline today. By logging your strategic reflection, you protect your momentum against future bottlenecks.",
      aiRecommendation: "Establish tomorrow's high-leverage King-rank schedule block first thing in the morning to bypass peak energy fatigue."
    };
  }

  /**
   * Get User Streaks
   */
  async getStreaks(): Promise<UserStreaks> {
    const defaultStreaks: UserStreaks = {
      currentStreak: 0,
      longestStreak: 0,
      consecutiveProductiveDays: 0,
      consecutivePlannerUsage: 0,
      consecutiveAiMentorUsage: 0
    };

    const uid = this.getUserId();
    if (uid) {
      try {
        const streakRef = doc(db, 'users', uid, 'streaks', 'main');
        const streakSnap = await getDoc(streakRef);
        if (streakSnap.exists()) {
          return streakSnap.data() as UserStreaks;
        }
      } catch (err) {
        console.error('Firestore getStreaks error:', err);
      }
    }

    try {
      const data = localStorage.getItem(this.getFallbackStorageKey('streaks'));
      return data ? JSON.parse(data) : defaultStreaks;
    } catch {
      return defaultStreaks;
    }
  }

  /**
   * Recalculate and update streaks based on daily logs
   */
  async updateStreaks(todayDateStr: string): Promise<UserStreaks> {
    const streaks = await this.getStreaks();
    const logs = await this.getDailyLogsHistory();
    
    if (logs.length === 0) return streaks;
    
    // Sort logs chronologically to compute streaks
    const sortedLogs = [...logs].sort((a, b) => a.date.localeCompare(b.date));
    
    let currentStreak = 0;
    let longestStreak = 0;
    let consecutiveProductive = 0;
    let consecutivePlanner = 0;
    
    let lastDate: Date | null = null;
    
    for (const log of sortedLogs) {
      const logDate = new Date(log.date);
      if (log.completionPercentage >= 50) {
        if (!lastDate) {
          currentStreak = 1;
          consecutiveProductive = 1;
        } else {
          const diffDays = Math.floor((logDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
          if (diffDays === 1) {
            currentStreak += 1;
            consecutiveProductive += 1;
          } else if (diffDays > 1) {
            currentStreak = 1;
            consecutiveProductive = 1;
          }
        }
        if (currentStreak > longestStreak) {
          longestStreak = currentStreak;
        }
      } else {
        // Did not meet productivity threshold of 50%
        currentStreak = 0;
      }
      
      // Planner usage consecutive
      if (!lastDate) {
        consecutivePlanner = 1;
      } else {
        const diffDays = Math.floor((logDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
        if (diffDays === 1) {
          consecutivePlanner += 1;
        } else if (diffDays > 1) {
          consecutivePlanner = 1;
        }
      }
      
      lastDate = logDate;
    }

    const updatedStreaks: UserStreaks = {
      currentStreak,
      longestStreak: Math.max(longestStreak, streaks.longestStreak),
      consecutiveProductiveDays: consecutiveProductive,
      consecutivePlannerUsage: consecutivePlanner,
      consecutiveAiMentorUsage: streaks.consecutiveAiMentorUsage || 1,
      lastActiveDate: todayDateStr
    };

    const uid = this.getUserId();
    if (uid) {
      try {
        const streakRef = doc(db, 'users', uid, 'streaks', 'main');
        await setDoc(streakRef, updatedStreaks, { merge: true });
      } catch (err) {
        console.error('Firestore save streaks error:', err);
      }
    }

    localStorage.setItem(this.getFallbackStorageKey('streaks'), JSON.stringify(updatedStreaks));
    return updatedStreaks;
  }

  /**
   * Weekly Reports
   */
  async getWeeklyReport(weekId: string): Promise<WeeklyReport | null> {
    const uid = this.getUserId();
    if (uid) {
      try {
        const ref = doc(db, 'users', uid, 'weeklyReports', weekId);
        const snap = await getDoc(ref);
        if (snap.exists()) {
          return snap.data() as WeeklyReport;
        }
      } catch (err) {
        console.error('Firestore getWeeklyReport error:', err);
      }
    }

    const locals = this.getLocalData<WeeklyReport>(this.getFallbackStorageKey('weeklyReports'));
    return locals.find(r => r.weekId === weekId) || null;
  }

  async saveWeeklyReport(report: WeeklyReport): Promise<void> {
    const uid = this.getUserId();
    if (uid) {
      try {
        const ref = doc(db, 'users', uid, 'weeklyReports', report.weekId);
        await setDoc(ref, report, { merge: true });
      } catch (err) {
        console.error('Firestore saveWeeklyReport error:', err);
      }
    }

    const key = this.getFallbackStorageKey('weeklyReports');
    const locals = this.getLocalData<WeeklyReport>(key);
    const idx = locals.findIndex(r => r.weekId === report.weekId);
    if (idx > -1) {
      locals[idx] = report;
    } else {
      locals.push(report);
    }
    this.saveLocalData(key, locals);
  }

  async getWeeklyReportsHistory(): Promise<WeeklyReport[]> {
    const uid = this.getUserId();
    if (uid) {
      try {
        const col = collection(db, 'users', uid, 'weeklyReports');
        const q = query(col, orderBy('weekId', 'desc'));
        const snap = await getDocs(q);
        const list: WeeklyReport[] = [];
        snap.forEach(d => list.push(d.data() as WeeklyReport));
        if (list.length > 0) {
          this.saveLocalData(this.getFallbackStorageKey('weeklyReports'), list);
          return list;
        }
      } catch (err) {
        console.error('Firestore getWeeklyReportsHistory error:', err);
      }
    }
    return this.getLocalData<WeeklyReport>(this.getFallbackStorageKey('weeklyReports'))
      .sort((a, b) => b.weekId.localeCompare(a.weekId));
  }

  async generateWeeklyReport(weekId: string, daysData: DailyLog[], userProfile: any): Promise<WeeklyReport> {
    const totalCompleted = daysData.reduce((acc, d) => acc + d.completedTasks.length, 0);
    const avgPercentage = daysData.length > 0 
      ? Math.round(daysData.reduce((acc, d) => acc + d.completionPercentage, 0) / daysData.length)
      : 0;

    let mostProductiveDay = 'N/A';
    let maxCompletions = -1;
    for (const d of daysData) {
      if (d.completedTasks.length > maxCompletions) {
        maxCompletions = d.completedTasks.length;
        mostProductiveDay = d.date;
      }
    }

    // Try AI generation
    let weeklyAiInsights = "• Maintained structured pacing across all primary priorities.\n• Highly efficient execution block observed mid-week.";
    let recommendations = "• Buffer upcoming schedule slots against external disruptions.\n• Align complex technical study with high-energy morning windows.";

    try {
      const response = await fetch('/api/coach/generate-weekly-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ weekId, daysData, userProfile })
      });
      if (response.ok) {
        const aiData = await response.json();
        weeklyAiInsights = aiData.weeklyAiInsights;
        recommendations = aiData.recommendations;
      }
    } catch (err) {
      console.error('Weekly AI generation failed, using fallback:', err);
    }

    const report: WeeklyReport = {
      weekId,
      tasksCompleted: totalCompleted,
      completionRate: avgPercentage,
      mostProductiveDay,
      leastProductiveDay: daysData.find(d => d.completedTasks.length === 0)?.date || 'N/A',
      bestSubject: 'Strategic Priorities',
      weakestSubject: 'Friction Contexts',
      averageProductivity: avgPercentage,
      studyConsistency: daysData.length > 0 
        ? Math.round((daysData.filter(d => d.completedTasks.length > 0).length / daysData.length) * 100) 
        : 0,
      weeklyAiInsights,
      recommendations,
      createdAt: new Date().toISOString()
    };

    await this.saveWeeklyReport(report);
    return report;
  }

  /**
   * Monthly Reports
   */
  async getMonthlyReport(monthId: string): Promise<MonthlyReport | null> {
    const uid = this.getUserId();
    if (uid) {
      try {
        const ref = doc(db, 'users', uid, 'monthlyReports', monthId);
        const snap = await getDoc(ref);
        if (snap.exists()) {
          return snap.data() as MonthlyReport;
        }
      } catch (err) {
        console.error('Firestore getMonthlyReport error:', err);
      }
    }

    const locals = this.getLocalData<MonthlyReport>(this.getFallbackStorageKey('monthlyReports'));
    return locals.find(r => r.monthId === monthId) || null;
  }

  async saveMonthlyReport(report: MonthlyReport): Promise<void> {
    const uid = this.getUserId();
    if (uid) {
      try {
        const ref = doc(db, 'users', uid, 'monthlyReports', report.monthId);
        await setDoc(ref, report, { merge: true });
      } catch (err) {
        console.error('Firestore saveMonthlyReport error:', err);
      }
    }

    const key = this.getFallbackStorageKey('monthlyReports');
    const locals = this.getLocalData<MonthlyReport>(key);
    const idx = locals.findIndex(r => r.monthId === report.monthId);
    if (idx > -1) {
      locals[idx] = report;
    } else {
      locals.push(report);
    }
    this.saveLocalData(key, locals);
  }

  async getMonthlyReportsHistory(): Promise<MonthlyReport[]> {
    const uid = this.getUserId();
    if (uid) {
      try {
        const col = collection(db, 'users', uid, 'monthlyReports');
        const q = query(col, orderBy('monthId', 'desc'));
        const snap = await getDocs(q);
        const list: MonthlyReport[] = [];
        snap.forEach(d => list.push(d.data() as MonthlyReport));
        if (list.length > 0) {
          this.saveLocalData(this.getFallbackStorageKey('monthlyReports'), list);
          return list;
        }
      } catch (err) {
        console.error('Firestore getMonthlyReportsHistory error:', err);
      }
    }
    return this.getLocalData<MonthlyReport>(this.getFallbackStorageKey('monthlyReports'))
      .sort((a, b) => b.monthId.localeCompare(a.monthId));
  }

  async generateMonthlyReport(monthId: string, weeksData: WeeklyReport[], userProfile: any): Promise<MonthlyReport> {
    const totalCompleted = weeksData.reduce((acc, w) => acc + w.tasksCompleted, 0);
    const totalFocusMinutes = weeksData.reduce((acc, w) => acc + (w.tasksCompleted * 30), 0); // approximation or sum from logs
    const avgRate = weeksData.length > 0 
      ? Math.round(weeksData.reduce((acc, w) => acc + w.completionRate, 0) / weeksData.length)
      : 0;

    let personalGrowth = "Continuous dedication to building focus routines has created a very sturdy momentum index.";
    let biggestImprovements = "Better categorization of Critical 'King' and High 'Queen' tasks, ensuring daily goals are met consistently.";
    let recurringBottlenecks = "Scheduling fatigue on late afternoons leading to cognitive friction.";
    let aiRecommendations = "Integrate a deliberate 30-minute buffer window daily at 3 PM to reset and recharge your baseline motivation index.";

    try {
      const response = await fetch('/api/coach/generate-monthly-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ monthId, weeksData, userProfile })
      });
      if (response.ok) {
        const aiData = await response.json();
        personalGrowth = aiData.personalGrowth;
        biggestImprovements = aiData.biggestImprovements;
        recurringBottlenecks = aiData.recurringBottlenecks;
        aiRecommendations = aiData.aiRecommendations;
      }
    } catch (err) {
      console.error('Monthly AI generation failed, using fallback:', err);
    }

    const report: MonthlyReport = {
      monthId,
      hoursInvested: Math.round(totalFocusMinutes / 60),
      tasksCompleted: totalCompleted,
      streaks: weeksData.length,
      goalCompletion: avgRate,
      activeCategories: { 'Strategic Projects': totalCompleted },
      personalGrowth,
      biggestImprovements,
      recurringBottlenecks,
      aiRecommendations,
      createdAt: new Date().toISOString()
    };

    await this.saveMonthlyReport(report);
    return report;
  }
}

export const reflectionService = new ReflectionService();
