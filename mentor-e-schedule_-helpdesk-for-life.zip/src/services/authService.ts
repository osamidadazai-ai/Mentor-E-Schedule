import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  signInWithPopup, 
  GoogleAuthProvider, 
  updateProfile,
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';
import { auth } from '../lib/firebase';

export interface FirebaseSyncResponse {
  message: string;
  user: {
    email: string;
    fullName: string;
    profilePicture: string;
    onboarded: boolean;
    profile: any;
    workspace: any;
  };
}

class FirebaseAuthService {
  /**
   * Log in a user with email and password
   */
  async loginWithEmail(email: string, password: string): Promise<FirebaseSyncResponse> {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      return await this.syncUserWithBackend(user);
    } catch (error: any) {
      console.error('Firebase Email Login Error:', error);
      throw new Error(this.getReadableErrorMessage(error));
    }
  }

  /**
   * Register a new user with email, password, full name, and avatar preference
   */
  async registerWithEmail(
    email: string, 
    password: string, 
    fullName: string, 
    profilePicture: string = 'slate'
  ): Promise<FirebaseSyncResponse> {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      
      // Update profile in Firebase
      await updateProfile(user, {
        displayName: fullName
      });

      return await this.syncUserWithBackend(user, fullName, profilePicture);
    } catch (error: any) {
      console.error('Firebase Email Registration Error:', error);
      throw new Error(this.getReadableErrorMessage(error));
    }
  }

  /**
   * Log in or sign up a user using Google Sign-In
   */
  async loginWithGoogle(): Promise<FirebaseSyncResponse> {
    try {
      const provider = new GoogleAuthProvider();
      // Configure Custom Parameters for Google Provider if needed
      provider.setCustomParameters({ prompt: 'select_account' });
      
      const userCredential = await signInWithPopup(auth, provider);
      const user = userCredential.user;
      
      return await this.syncUserWithBackend(
        user, 
        user.displayName || user.email?.split('@')[0] || 'Google User',
        'royal' // Default to royal for google users
      );
    } catch (error: any) {
      console.error('Firebase Google Login Error:', error);
      throw new Error(this.getReadableErrorMessage(error));
    }
  }

  /**
   * Log out the current user
   */
  async logout(): Promise<void> {
    try {
      await signOut(auth);
    } catch (error: any) {
      console.error('Firebase Sign-Out Error:', error);
      throw new Error(this.getReadableErrorMessage(error));
    }
  }

  /**
   * Listen to Firebase Auth state changes
   */
  subscribeToAuth(callback: (user: FirebaseUser | null) => void) {
    return onAuthStateChanged(auth, callback);
  }

  /**
   * Sync user state and load workspace/profile from backend
   */
  private async syncUserWithBackend(
    firebaseUser: FirebaseUser, 
    fallbackName?: string, 
    fallbackAvatar?: string
  ): Promise<FirebaseSyncResponse> {
    const email = firebaseUser.email;
    if (!email) {
      throw new Error('No email associated with authenticated user.');
    }

    const response = await fetch('/api/auth/firebase-sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email,
        fullName: firebaseUser.displayName || fallbackName || email.split('@')[0],
        profilePicture: fallbackAvatar || 'slate'
      })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Failed to synchronize workspace session with server.');
    }

    return data as FirebaseSyncResponse;
  }

  /**
   * Map standard Firebase error codes to human-readable error messages
   */
  private getReadableErrorMessage(error: any): string {
    const code = error.code;
    switch (code) {
      case 'auth/invalid-credential':
      case 'auth/wrong-password':
        return 'Incorrect password or email address.';
      case 'auth/user-not-found':
        return 'No user registered under this email address.';
      case 'auth/email-already-in-use':
        return 'This email address is already in use by another account.';
      case 'auth/weak-password':
        return 'The password must be at least 6 characters.';
      case 'auth/invalid-email':
        return 'Please enter a valid email address.';
      case 'auth/popup-closed-by-user':
        return 'Sign-in window closed before authentication completed.';
      case 'auth/network-request-failed':
        return 'Connection error. Please check your internet connectivity.';
      default:
        return error.message || 'Authentication failed. Please try again.';
    }
  }
}

export const authService = new FirebaseAuthService();
